#include <jni.h>
#include <stdio.h>
#include "ru_ispras_softfloat_jni_CSoftFloat.h"

extern "C" {
#include "softfloat.h"
}

void static throw_IllegalArgumentException(JNIEnv *env, const char* exception_string)
{
    jclass newExcCls = (env)->FindClass("java/lang/IllegalArgumentException");
   
    if (newExcCls == NULL) 
    {
        /* Unable to find the exception class, give up. */
        return;
    }

    (env)->ThrowNew(newExcCls, exception_string);
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE floating-point underflow tininess-detection mode.
*----------------------------------------------------------------------------*/
JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_get_1float_1detect_1tininess
  (JNIEnv *env, jclass j_class)
{
    return (jchar)float_detect_tininess;
}

JNIEXPORT void JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_set_1float_1detect_1tininess
  (JNIEnv *env, jclass j_class, jchar arg0)
{
   switch( (signed char)arg0 )
   {
       case float_tininess_after_rounding :
       case float_tininess_before_rounding:
       
       float_detect_tininess = arg0;
           break;
     
       default: throw_IllegalArgumentException(env, "float_detect_tininess should be 0 or 1");
   }
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE floating-point rounding mode.
*----------------------------------------------------------------------------*/
JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_get_1floating_1rounding_1mode
  (JNIEnv *env, jclass j_class)
{
   return (jchar)float_rounding_mode;
}

JNIEXPORT void JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_set_1floating_1rounding_1mode
  (JNIEnv *env, jclass j_class, jchar arg0)
{
    switch( (signed char)arg0 )
    {
       case float_round_nearest_even:
       case float_round_down        :
       case float_round_up          :
       case float_round_to_zero     :
 
       float_rounding_mode = arg0;
           break;

       default: throw_IllegalArgumentException(env, "float_rounding_mode should be 0 - 3");
    }
}
	
/*----------------------------------------------------------------------------
| Software IEC/IEEE floating-point exception flags.
*----------------------------------------------------------------------------*/
JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_get_1float_1exception_1flags
  (JNIEnv *env, jclass j_class)
{
    return (jchar)float_exception_flags;
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE integer-to-floating-point conversion routines.
*----------------------------------------------------------------------------*/

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_int32_1to_1float32
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jint)int32_to_float32( (int)arg0 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_int32_1to_1float64
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jlong)int32_to_float64( (int)arg0 );
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_int64_1to_1float32
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jint)int64_to_float32( (long long)arg0 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_int64_1to_1float64
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jlong)int64_to_float64( (long long)arg0 );
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE single-precision conversion routines.
*----------------------------------------------------------------------------*/

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1to_1int32
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jint)float32_to_int32( (float32)arg0 );
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1to_1int32_1round_1to_1zero
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jint)float32_to_int32_round_to_zero( (float32)arg0 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1to_1int64
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jlong)float32_to_int64( (float32)arg0 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1to_1int64_1round_1to_1zero
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jlong)float32_to_int64_round_to_zero( (float32)arg0 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1to_1float64
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jlong)float32_to_float64( (float32)arg0 );
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE single-precision operations.
*----------------------------------------------------------------------------*/

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1round_1to_1int
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jint)float32_round_to_int( (float32)arg0);
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1add
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jint)float32_add( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1sub
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jint)float32_sub( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1mul
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jint)float32_mul( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1div
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jint)float32_div( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1rem
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jint)float32_rem( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1sqrt
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jint)float32_sqrt( (float32)arg0);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1eq
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jchar)float32_eq( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1le
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jchar)float32_le( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1lt
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jchar)float32_lt( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1eq_1signaling
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jchar)float32_eq_signaling( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1le_1quiet
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jchar)float32_le_quiet( (float32)arg0, (float32)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1lt_1quiet
  (JNIEnv *env, jclass j_class, jint arg0, jint arg1)
{
    return (jchar)float32_lt_quiet( (float32)arg0, (float32)arg1 );

}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float32_1is_1signaling_1nan
  (JNIEnv *env, jclass j_class, jint arg0)
{
    return (jchar)float32_is_signaling_nan( (float32)arg0 );
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE double-precision conversion routines.
*----------------------------------------------------------------------------*/

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1to_1int32
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jint)float64_to_int32( (float64)arg0);
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1to_1int32_1round_1to_1zero
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jint)float64_to_int32_round_to_zero( (float64)arg0 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1to_1int64
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jlong)float64_to_int64( (float64)arg0 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1to_1int64_1round_1to_1zero
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jlong)float64_to_int64_round_to_zero((float64)arg0 );
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1to_1float32
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jint)float64_to_float32((float64)arg0 );
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE double-precision operations.
*----------------------------------------------------------------------------*/

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1round_1to_1int
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jint)float64_round_to_int( (float64)arg0 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1add
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jlong)float64_add( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1sub
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jlong)float64_sub( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1mul
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jlong)float64_mul( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1div
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jlong)float64_div( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1rem
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jlong)float64_rem( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1sqrt
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jlong)float64_sqrt( (float64)arg0 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1eq
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jchar)float64_eq( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1le
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jchar)float64_le( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1lt
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jchar)float64_lt( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1eq_1signaling
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jchar)float64_eq_signaling( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1le_1quiet
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jchar)float64_le_quiet( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1lt_1quiet
  (JNIEnv *env, jclass j_class, jlong arg0, jlong arg1)
{
    return (jchar)float64_lt_quiet( (float64)arg0, (float64)arg1 );
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float64_1is_1signaling_1nan
  (JNIEnv *env, jclass j_class, jlong arg0)
{
    return (jchar)float64_is_signaling_nan( (float64)arg0 );
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE extended double-precision conversion routines.
*----------------------------------------------------------------------------*/

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1to_1int32
  (JNIEnv *env, jclass j_class, jobject obj)
{
    floatx80 input;

    jclass jfloatx80 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jshort arg2 = env->GetShortField(obj, high);
    input.high = arg2;

    return (jint)floatx80_to_int32( (floatx80) input);
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1to_1int32_1round_1to_1zero
  (JNIEnv *env, jclass j_class, jobject obj)
{
    floatx80 input;

    jclass jfloatx80 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jshort arg2 = env->GetShortField(obj, high);
    input.high = arg2;

    return (jint)floatx80_to_int32_round_to_zero( (floatx80) input);
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1to_1int64
  (JNIEnv *env, jclass j_class, jobject obj)
{
    floatx80 input;

    jclass jfloatx80 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jshort arg2 = env->GetShortField(obj, high);
    input.high = arg2;

    return (jlong)floatx80_to_int64( (floatx80) input);
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1to_1int64_1round_1to_1zero
  (JNIEnv *env, jclass j_class, jobject obj)
{
    floatx80 input;

    jclass jfloatx80 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jshort arg2 = env->GetShortField(obj, high);
    input.high = arg2;

    return (jlong)floatx80_to_int64_round_to_zero( (floatx80) input);
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1to_1float32
  (JNIEnv *env, jclass j_class, jobject obj)
{
    floatx80 input;

    jclass jfloatx80 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jshort arg2 = env->GetShortField(obj, high);
    input.high = arg2;

    return (jint)floatx80_to_float32( (floatx80) input);
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1to_1float64
  (JNIEnv *env, jclass j_class, jobject obj)
{
    floatx80 input;
    
    jclass jfloatx80 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jshort arg2 = env->GetShortField(obj, high);
    input.high = arg2;

    return (jlong)floatx80_to_float64( (floatx80) input);
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1to_1float128
  (JNIEnv *env, jclass j_class, jobject obj)
{
    floatx80 input;
    
    jclass jfloatx80 = env->GetObjectClass(obj);
 
    jfieldID low = env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;
   
    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jshort arg2 = env->GetShortField(obj, high);
    input.high = arg2;

    float128 output = floatx80_to_float128( (floatx80) input);

    jclass cls = env->FindClass("ru/ispras/softfloat/Float128");
    if (NULL == cls) {
      printf("FloatX80 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(JJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject float128Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == float128Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return float128Obj;
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE extended double-precision operations.
*----------------------------------------------------------------------------*/

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1round_1to_1int
  (JNIEnv *env, jclass, jobject obj)
{
    floatx80 input;

    jclass jfloatx80 = env->GetObjectClass(obj);

    jfieldID low= env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) return NULL;
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;
    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) return NULL;
    jshort arg2 = env->GetShortField(obj, high);
    input.high = arg2;

    floatx80 output = floatx80_round_to_int( (floatx80) input);

    jclass cls = env->FindClass("ru/ispras/softfloat/FloatX80");
    if (NULL == cls) {
      printf("FloatX80 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(SJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject floatx80Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == floatx80Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return floatx80Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1add
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    floatx80 output = floatx80_add( (floatx80) input0, (floatx80) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/FloatX80");
    if (NULL == cls) {
      printf("FloatX80 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(SJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject floatx80Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == floatx80Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return floatx80Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1sub
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    floatx80 output = floatx80_sub( (floatx80) input0, (floatx80) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/FloatX80");
    if (NULL == cls) {
      printf("FloatX80 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(SJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject floatx80Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == floatx80Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return floatx80Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1mul
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    floatx80 output = floatx80_mul( (floatx80) input0, (floatx80) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/FloatX80");
    if (NULL == cls) {
      printf("FloatX80 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(SJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject floatx80Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == floatx80Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return floatx80Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1div
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    floatx80 output = floatx80_div( (floatx80) input0, (floatx80) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/FloatX80");
    if (NULL == cls) {
      printf("FloatX80 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(SJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject floatx80Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == floatx80Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return floatx80Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1rem
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    floatx80 output = floatx80_rem( (floatx80) input0, (floatx80) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/FloatX80");
    if (NULL == cls) {
      printf("FloatX80 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(SJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    
    jobject floatx80Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == floatx80Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return floatx80Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1sqrt
  (JNIEnv *env, jclass, jobject obj)
{
    floatx80 input;

    jclass jfloatx80 = env->GetObjectClass(obj);

    jfieldID low= env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) return NULL;
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;
    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) return NULL;
    jshort arg2 = env->GetShortField(obj, high);
    input.high = arg2;

    floatx80 output = floatx80_sqrt( (floatx80) input);

    jclass cls = env->FindClass("ru/ispras/softfloat/FloatX80");
    if (NULL == cls) {
      printf("FloatX80 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(SJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject floatx80Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == floatx80Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return floatx80Obj;
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1eq
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    return (jchar)floatx80_eq( (floatx80) input0, (floatx80) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1le
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    return (jchar)floatx80_le( (floatx80) input0, (floatx80) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1lt
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    return (jchar)floatx80_lt( (floatx80) input0, (floatx80) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1eq_1signaling
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    return (jchar)floatx80_eq_signaling( (floatx80) input0, (floatx80) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1le_1quiet
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    return (jchar)floatx80_le_quiet( (floatx80) input0, (floatx80) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1lt_1quiet
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    floatx80 input0, input1;

    jclass jfloatx80_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloatx80_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloatx80_0, "high", "S");
    if (NULL == high0) return NULL;
    jshort arg2 = env->GetShortField(obj0, high0);
    input0.high = arg2;

    jclass jfloatx80_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloatx80_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloatx80_1, "high", "S");
    if (NULL == high1) return NULL;
    arg2 = env->GetShortField(obj1, high1);
    input1.high = arg2;

    return (jchar)floatx80_lt_quiet( (floatx80) input0, (floatx80) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_floatx80_1is_1signaling_1nan
  (JNIEnv *env, jclass, jobject obj0)
{
    floatx80 input;

    jclass jfloatx80 = env->GetObjectClass(obj0);

    jfieldID low = env->GetFieldID( jfloatx80, "low", "J");
    if (NULL == low) return NULL;
    jlong arg1 = env->GetLongField(obj0, low);
    input.low = arg1;
    jfieldID high = env->GetFieldID( jfloatx80, "high", "S");
    if (NULL == high) return NULL;
    jshort arg2 = env->GetShortField(obj0, high);
    input.high = arg2;

    return (jchar)floatx80_is_signaling_nan( (floatx80) input);
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE quadruple-precision conversion routines.
*----------------------------------------------------------------------------*/

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1to_1int32
  (JNIEnv *env, jclass j_class, jobject obj)
{
    float128 input;

    jclass jfloat128 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg2 = env->GetLongField(obj, high);
    input.high = arg2;

    return (jint)float128_to_int32( (float128) input);
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1to_1int32_1round_1to_1zero
  (JNIEnv *env, jclass j_class, jobject obj)
{
    float128 input;

    jclass jfloat128 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg2 = env->GetLongField(obj, high);
    input.high = arg2;

    return (jint)float128_to_int32_round_to_zero( (float128) input);
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1to_1int64
  (JNIEnv *env, jclass j_class, jobject obj)
{
    float128 input;

    jclass jfloat128 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg2 = env->GetLongField(obj, high);
    input.high = arg2;

    return (jlong)float128_to_int64( (float128) input);
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1to_1int64_1round_1to_1zero
  (JNIEnv *env, jclass j_class, jobject obj)
{
    float128 input;

    jclass jfloat128 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg2 = env->GetLongField(obj, high);
    input.high = arg2;

    return (jlong)float128_to_int64_round_to_zero( (float128) input);
}

JNIEXPORT jint JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1to_1float32
  (JNIEnv *env, jclass j_class, jobject obj)
{
    float128 input;

    jclass jfloat128 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg2 = env->GetLongField(obj, high);
    input.high = arg2;

    return (jint)float128_to_float32( (float128) input);
}

JNIEXPORT jlong JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1to_1float64
  (JNIEnv *env, jclass j_class, jobject obj)
{
    float128 input;

    jclass jfloat128 = env->GetObjectClass(obj);

    jfieldID low = env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;

    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) {
      printf("The operation GetFieldID fails.");
      return NULL;
    }
    jlong arg2 = env->GetLongField(obj, high);
    input.high = arg2;

    return (jlong)float128_to_float64( (float128) input);
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1to_1floatx80
  (JNIEnv *env, jclass, jobject obj)
{
    float128 input;

    jclass jfloat128 = env->GetObjectClass(obj);

    jfieldID low= env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) return NULL;
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;
    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) return NULL;
    jlong arg2 = env->GetLongField(obj, high);
    input.high = arg2;

    floatx80 output = float128_to_floatx80( (float128) input);

    jclass cls = env->FindClass("ru/ispras/softfloat/FloatX80");
    if (NULL == cls) {
      printf("FloatX80 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(SJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject floatx80Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == floatx80Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return floatx80Obj;
}

/*----------------------------------------------------------------------------
| Software IEC/IEEE quadruple-precision operations.
*----------------------------------------------------------------------------*/

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1round_1to_1int
  (JNIEnv *env, jclass, jobject obj)
{
    float128 input;

    jclass jfloat128 = env->GetObjectClass(obj);

    jfieldID low= env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) return NULL;
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;
    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) return NULL;
    jlong arg2 = env->GetLongField(obj, high);
    input.high = arg2;

    float128 output = float128_round_to_int( (float128) input);

    jclass cls = env->FindClass("ru/ispras/softfloat/Float128");
    if (NULL == cls) {
      printf("Float128 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(JJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject float128Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == float128Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return float128Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1add
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    float128 output = float128_add( (float128) input0, (float128) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/Float128");
    if (NULL == cls) {
      printf("Float128 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(JJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject float128Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == float128Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return float128Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1sub
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    float128 output = float128_sub( (float128) input0, (float128) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/Float128");
    if (NULL == cls) {
      printf("Float128 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(JJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject float128Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == float128Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return float128Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1mul
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    float128 output = float128_mul( (float128) input0, (float128) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/Float128");
    if (NULL == cls) {
      printf("Float128 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(JJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject float128Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == float128Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return float128Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1div
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    float128 output = float128_div( (float128) input0, (float128) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/Float128");
    if (NULL == cls) {
      printf("Float128 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(JJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject float128Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == float128Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return float128Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1rem
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    float128 output = float128_rem( (float128) input0, (float128) input1);

    jclass cls = env->FindClass("ru/ispras/softfloat/Float128");
    if (NULL == cls) {
      printf("Float128 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(JJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject float128Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == float128Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return float128Obj;
}

JNIEXPORT jobject JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1sqrt
  (JNIEnv *env, jclass, jobject obj)
{
    float128 input;

    jclass jfloat128 = env->GetObjectClass(obj);

    jfieldID low= env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) return NULL;
    jlong arg1 = env->GetLongField(obj, low);
    input.low = arg1;
    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) return NULL;
    jlong arg2 = env->GetLongField(obj, high);
    input.high = arg2;

    float128 output = float128_sqrt( (float128) input);

    jclass cls = env->FindClass("ru/ispras/softfloat/Float128");
    if (NULL == cls) {
      printf("Float128 class cannot be found.");
      return NULL;
    }
    jmethodID methodid = env->GetMethodID(cls, "<init>", "(JJ)V");
    if (NULL == methodid) {
      printf("The specified java method cannot be found.");
      return NULL;
    }
    jobject float128Obj = env->NewObject(cls, methodid, output.high, output.low);
    if (NULL == float128Obj) {
      printf("Java Object cannot be constructed.");
      return NULL;
    }

    return float128Obj;
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1eq
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    return (jchar)float128_eq( (float128) input0, (float128) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1le
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    return (jchar)float128_le( (float128) input0, (float128) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1lt
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    return (jchar)float128_lt( (float128) input0, (float128) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1eq_1signaling
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    return (jchar)float128_eq_signaling( (float128) input0, (float128) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1le_1quiet
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    return (jchar)float128_le_quiet( (float128) input0, (float128) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1lt_1quiet
  (JNIEnv *env, jclass, jobject obj0, jobject obj1)
{
    float128 input0, input1;

    jclass jfloat128_0 = env->GetObjectClass(obj0);

    jfieldID low0 = env->GetFieldID( jfloat128_0, "low", "J");
    if (NULL == low0) return NULL;
    jlong arg1 = env->GetLongField(obj0, low0);
    input0.low = arg1;
    jfieldID high0 = env->GetFieldID( jfloat128_0, "high", "J");
    if (NULL == high0) return NULL;
    jlong arg2 = env->GetLongField(obj0, high0);
    input0.high = arg2;

    jclass jfloat128_1 = env->GetObjectClass(obj1);

    jfieldID low1 = env->GetFieldID( jfloat128_1, "low", "J");
    if (NULL == low1) return NULL;
    arg1 = env->GetLongField(obj1, low1);
    input1.low = arg1;
    jfieldID high1 = env->GetFieldID( jfloat128_1, "high", "J");
    if (NULL == high1) return NULL;
    arg2 = env->GetLongField(obj1, high1);
    input1.high = arg2;

    return (jchar)float128_lt_quiet( (float128) input0, (float128) input1);
}

JNIEXPORT jchar JNICALL Java_ru_ispras_softfloat_jni_CSoftFloat_float128_1is_1signaling_1nan
  (JNIEnv *env, jclass, jobject obj0)
{
    float128 input, input1;

    jclass jfloat128 = env->GetObjectClass(obj0);

    jfieldID low = env->GetFieldID( jfloat128, "low", "J");
    if (NULL == low) return NULL;
    jlong arg1 = env->GetLongField(obj0, low);
    input.low = arg1;
    jfieldID high = env->GetFieldID( jfloat128, "high", "J");
    if (NULL == high) return NULL;
    jlong arg2 = env->GetLongField(obj0, high);
    input.high = arg2;

    return (jchar)float128_is_signaling_nan( (float128) input);
}
