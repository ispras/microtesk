/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.softfloat;

import java.math.BigInteger;

/**
 * Utils for JSoftFloat.
 * 
 * Some utils for unsigned operations.
 * 
 * @author <a href="mailto:protsenko@ispras.ru">Alexander Protsenko</a>
 */
public class Utils {
  /* A constant holding the signed bit for Integer.*/
  public static final BigInteger SIGNED_BIT_32 = BigInteger.ONE.shiftLeft(31);
  /* A constant holding the signed bit for Long.*/
  private static final BigInteger SIGNED_BIT_64 = BigInteger.ONE.shiftLeft(63);
  
  /**
   * Compares two int values by bits.
   * 
   * @param a the first int to compare.
   * @param b the second int to compare.
   * @return {@code true} if a < b, {@code false} if a >= b.
   */
  public static boolean compareUnsigned(int a, int b) {
    if ((a & 0x80000000) == (b & 0x80000000))
      return (a ^ 0x80000000) < (b ^ 0x80000000);
    else
      return ((a & 0x80000000) == 0) ? true : false;
  }

  /**
   * Compares two long values by bits.
   * 
   * @param a the first long to compare.
   * @param b the second long to compare.
   * @return {@code true} if a < b, {@code false} if a >= b.
   */
  public static boolean compareUnsigned(long a, long b) {
    if ((a & 0x8000000000000000L) == (b & 0x8000000000000000L))
      return (a ^ 0x8000000000000000L) < (b ^ 0x8000000000000000L);
    else
      return ((a & 0x8000000000000000L) == 0) ? true : false;
  }

  /**
   * Returns the value of this {@link Integer} as an unsigned {@link BigInteger}.
   * 
   * @param i - an integer to be converted to a {@link BigInteger}.
   * @return the {@link BigInteger} representation of the unsigned integer value.
   */
  public static BigInteger getUnsignedBigInteger(int i) {
    if (i < 0) {
      return BigInteger.valueOf(Integer.MAX_VALUE & i).or(SIGNED_BIT_32);
    } else {
      return BigInteger.valueOf(i);
    }
  }

  /**
   * Returns the value of this {@link Long} as an unsigned {@link BigInteger}.
   * 
   * @param i an long to be converted to a {@link BigInteger}.
   * @return the {@link BigInteger} representation of the unsigned long value.
   */
  public static BigInteger getUnsignedBigInteger(long i) {
    if (i < 0) {
      return BigInteger.valueOf(Long.MAX_VALUE & i).or(SIGNED_BIT_64);
    } else {
      return BigInteger.valueOf(i);
    }
  }
}
