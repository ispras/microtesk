/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.softfloat;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import ru.ispras.softfloat.JSoftFloatUtils.FloatDetectTininess;
import ru.ispras.softfloat.JSoftFloatUtils.FloatExceptionFlags;
import ru.ispras.softfloat.JSoftFloatUtils.FloatRoundingMode;

/**
 * Softfloat from project http://www.jhauser.us/arithmetic/SoftFloat.html
 * 
 * @author <a href="mailto:protsenko@ispras.ru">Alexander Protsenko</a>
 */
public class JSoftFloat {
  // The number of bytes used to represent a long value in two's complement binary form.
  public static final int LONG_BYTES = Long.SIZE / 8;
  
  /**
   * The pattern for a default generated quadruple-precision NaN. The `high' and `low' values hold
   * the most- and least-significant bits, respectively.
   */
  public static final long float128_default_nan_high = 0xFFFF800000000000L;
  public static final long float128_default_nan_low = 0x0000000000000000L;

  /**
   * The pattern for a default generated extended double-precision NaN. The `high' and `low' values
   * hold the most- and least-significant bits, respectively.
   */
  public static final short floatx80_default_nan_high = (short) 0xFFFF;
  public static final long floatx80_default_nan_low = 0xC000000000000000L;

  /**
   * Software IEC/IEEE extended double-precision rounding precision. Valid values are 32, 64, and
   * 80.
   */
  public static byte floatx80_rounding_precision = 80;

  /**
   * The pattern for a default generated single-precision NaN.
   */
  public static final float float32_default_nan = Float.intBitsToFloat(0xFFC00000);

  /**
   * The pattern for a default generated double-precision NaN.
   */
  public static final double float64_default_nan = Double.longBitsToDouble(0xFFF8000000000000L);

  static FloatDetectTininess float_detect_tininess;

  /**
   * Floating-point rounding mode, extended double-precision rounding precision, and exception
   * flags.
   */
  static FloatRoundingMode float_rounding_mode = FloatRoundingMode.float_round_nearest_even; //int8
  public static byte float_exception_flags = 0; //int8

  /**
   * Takes a 64-bit fixed-point value `absZ' with binary point between bits 6 and 7, and returns the
   * properly rounded 32-bit integer corresponding to the input. If `zSign' is 1, the input is
   * negated before being converted to an integer. Bit 63 of `absZ' must be zero. Ordinarily, the
   * fixed-point input is simply rounded to an integer, with the inexact exception raised if the
   * input cannot be represented exactly as an integer. However, if the fixed- point input is too
   * large, the invalid exception is raised and the largest positive or negative integer is
   * returned.
   * 
   * @param zSign if {@code true} then the input is negated
   * @param absZ - fixed-point value (bits64)
   * 
   * @return z - the properly rounded 32-bit integer
   */
  public static int roundAndPackInt32(final boolean zSign, long absZ) {
    FloatRoundingMode roundingMode; // int8
    boolean roundNearestEven; // flag
    byte roundIncrement, roundBits; // int8
    int z = 0; // int 32
    roundingMode = float_rounding_mode;
    roundNearestEven = (roundingMode == FloatRoundingMode.float_round_nearest_even);
    roundIncrement = 0x40;
    if (!roundNearestEven) {
      if (roundingMode == FloatRoundingMode.float_round_to_zero) {
        roundIncrement = 0;
      } else {
        roundIncrement = 0x7F;
        if (zSign) {
          if (roundingMode == FloatRoundingMode.float_round_up)
            roundIncrement = 0;
        } else {
          if (roundingMode == FloatRoundingMode.float_round_down)
            roundIncrement = 0;
        }
      }
    }
    roundBits = (byte) (absZ & 0x7F);
    absZ = (absZ + roundIncrement) >>> 7;
    absZ &= ~((((roundBits ^ 0x40) == 0) & roundNearestEven) ? 1 : 0);
    z = (int) absZ & 0xffffffff;
    if (zSign) {
      z = -z;
    }

    if (((absZ >>> 32) | (((z != 0) && ((z < 0) ^ zSign)) ? 1 : 0)) != 0) {
      float_exception_flags |= FloatExceptionFlags.float_flag_invalid.getValue();
      return zSign ? 0x80000000 : 0x7FFFFFFF; // sbits32
    }
    if (roundBits != 0) {
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    }
    return z;
  }

  /**
   * Updates the exception flag.
   * 
   * @param i
   * */
  static void float_raise(final int i) {
    float_exception_flags |= i;
  }

  /**
   * Takes the 128-bit fixed-point value formed by concatenating `absZ0' and `absZ1', with binary
   * point between bits 63 and 64 (between the input words), and returns the properly rounded 64-bit
   * integer corresponding to the input. If `zSign' is 1, the input is negated before being
   * converted to an integer. Ordinarily, the fixed-point input is simply rounded to an integer,
   * with the inexact exception raised if the input cannot be represented exactly as an integer.
   * However, if the fixed-point input is too large, the invalid exception is raised and the largest
   * positive or negative integer is returned.
   * 
   * @param zSign zSign if {@code true} then the input is negated
   * @param absZ0 1st part of the 128-bit fixed-point value (bits64)
   * @param absZ1 2nd part of the 128-bit fixed-point value (bits64)
   * 
   * @return the properly rounded 64-bit integer (int64)
   */
  public static long roundAndPackInt64(final boolean zSign, long absZ0, long absZ1) {
    FloatRoundingMode roundingMode; // int8
    boolean roundNearestEven, increment; // flag
    long z; // int64

    roundingMode = float_rounding_mode;
    roundNearestEven = (roundingMode == FloatRoundingMode.float_round_nearest_even);
    increment = (absZ1 < 0);
    if (!roundNearestEven) {
      if (roundingMode == FloatRoundingMode.float_round_to_zero) {
        increment = false;
      } else {
        if (zSign) {
          increment = (roundingMode == FloatRoundingMode.float_round_down) && absZ1 != 0;
        } else {
          increment = (roundingMode == FloatRoundingMode.float_round_up) && absZ1 != 0;
        }
      }
    }
    if (increment) {
      ++absZ0;
      if (absZ0 == 0) {
        float_exception_flags |= (byte) FloatExceptionFlags.float_flag_invalid.getValue();
        return zSign ? 0x8000000000000000L : 0x7FFFFFFFFFFFFFFFL;
      }
      absZ0 &= ~((((absZ1 << 1) == 0) & roundNearestEven) ? 1 : 0);
    }
    z = absZ0;
    if (zSign)
      z = -z;

    if ((((z != 0) && ((z < 0) ^ zSign) ? 1 : 0)) != 0) {
      // overflow:
      float_exception_flags |= (byte) FloatExceptionFlags.float_flag_invalid.getValue();
      return zSign ? 0x8000000000000000L : 0x7FFFFFFFFFFFFFFFL;
    }
    if (absZ1 != 0)
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    return z;
  }

  /**
   * Returns the fraction bits of the single-precision floating-point value 'a'.
   * 
   * @param a the single-precision floating-point value (float32)
   * 
   * @return the fraction bits
   */
  public static int extractFloat32Frac(final float a) {
    return Float.floatToRawIntBits(a) & 0x007FFFFF;
  }

  /**
   * Returns the exponent bits of the single-precision floating-point value `a'.
   * 
   * @param a the single-precision floating-point value (float32)
   * 
   * @return the exponent bits
   */
  public static short extractFloat32Exp(final float a) {
    return (short) ((Float.floatToRawIntBits(a) >>> 23) & 0xFF);
  }

  /**
   * Returns the sign bit of the single-precision floating-point value `a'.
   * 
   * @param a the single-precision floating-point value (float32)
   * 
   * @return the sign bit (flag)
   */
  public static boolean extractFloat32Sign(final float a) {
    return Float.floatToRawIntBits(a) >>> 31 != 0;
  }

  /**
   * Normalizes the subnormal single-precision floating-point value represented by the denormalized
   * significand `aSig'. The normalized exponent and significand are stored at the locations pointed
   * to by `zExpPtr' and `zSigPtr', respectively.
   * 
   * @param aSig the subnormal single-precision floating-point value (bits32)
   * 
   * @return the normalized exponent and significand (zExpPtr, zSigPtr)
   */
  public static List<Number> normalizeFloat32Subnormal(final int aSig) {
    byte shiftCount; // int8
    short zExpPtr; // int16
    int zSigPtr; // bit32

    shiftCount = (byte) (JSoftFloatUtils.countLeadingZeros32(aSig) - 8);
    zSigPtr = aSig << shiftCount;
    zExpPtr = (short) (1 - shiftCount);

    List<Number> list = new ArrayList<Number>();
    list.add(zExpPtr);
    list.add(zSigPtr);

    return list;
  }

  /**
   * Packs the sign `zSign', exponent `zExp', and significand `zSig' into a single-precision
   * floating-point value, returning the result. After being shifted into the proper positions, the
   * three fields are simply added together to form the result. This means that any integer portion
   * of `zSig' will be added into the exponent. Since a properly normalized significand will have an
   * integer portion equal to 1, the `zExp' input should be 1 less than the desired result exponent
   * whenever `zSig' is a complete, normalized significand.
   * 
   * @param zSign the sign.
   * @param zExp the exponent.
   * @param zSig the significand.
   * 
   * @retun a single-precision floating-point value.
   */
  public static float packFloat32(final boolean zSign, final short zExp, final int zSig) {
    return Float.intBitsToFloat(((zSign ? 1 : 0) << 31) + (((int) zExp) << 23) + zSig);
  }

  /**
   * Takes an abstract floating-point value having sign `zSign', exponent `zExp', and significand
   * `zSig', and returns the proper single-precision floating- point value corresponding to the
   * abstract input. Ordinarily, the abstract value is simply rounded and packed into the
   * single-precision format, with the inexact exception raised if the abstract input cannot be
   * represented exactly. However, if the abstract value is too large, the overflow and inexact
   * exceptions are raised and an infinity or maximal finite value is returned. If the abstract
   * value is too small, the input value is rounded to a subnormal number, and the underflow and
   * inexact exceptions are raised if the abstract input cannot be represented exactly as a
   * subnormal single- precision floating-point number. The input significand `zSig' has its binary
   * point between bits 30 and 29, which is 7 bits to the left of the usual location. This shifted
   * significand must be normalized or smaller. If `zSig' is not normalized, `zExp' must be 0; in
   * that case, the result returned is a subnormal number, and it must not require rounding. In the
   * usual case that `zSig' is normalized, `zExp' must be 1 less than the ``true'' floating-point
   * exponent. The handling of underflow and overflow follows the IEC/IEEE Standard for Binary
   * Floating-Point Arithmetic.
   * 
   * @param zSign the sign.
   * @param zExp the exponent.
   * @param zSig the significand.
   * 
   * @return an abstract floating-point value (float32)
   */
  static float roundAndPackFloat32(final boolean zSign, short zExp, int zSig) {

    FloatRoundingMode roundingMode; // int8
    boolean roundNearestEven; // flag
    byte roundIncrement, roundBits; // int8
    boolean isTiny; // flag

    roundingMode = float_rounding_mode;
    roundNearestEven = (roundingMode == FloatRoundingMode.float_round_nearest_even);
    roundIncrement = 0x40;
    if (!roundNearestEven) {
      if (roundingMode == FloatRoundingMode.float_round_to_zero) {
        roundIncrement = 0;
      } else {
        roundIncrement = 0x7F;
        if (zSign) {
          if (roundingMode == FloatRoundingMode.float_round_up)
            roundIncrement = 0;
        } else {
          if (roundingMode == FloatRoundingMode.float_round_down)
            roundIncrement = 0;
        }
      }
    }
    roundBits = (byte) (zSig & 0x7F);

    if (0xFD <= (((int) zExp) & 0x0000FFFF)) { // (bits16) zExp
      if ((0xFD < zExp) || ((zExp == 0xFD) && ((int) (zSig + roundIncrement) < 0))) {
        float_raise(FloatExceptionFlags.float_flag_overflow.getValue()
            | FloatExceptionFlags.float_flag_inexact.getValue());
        return packFloat32(zSign, (short) 0xFF, 0) - ((roundIncrement == 0) ? 1 : 0);
      }
      if (zExp < 0) {
        isTiny =
            (float_detect_tininess == FloatDetectTininess.float_tininess_before_rounding)
                || (zExp < -1) || (zSig + roundIncrement < 0x80000000);
        zSig = JSoftFloatUtils.shift32RightJamming(zSig, (short) -zExp);//, zSig);
        zExp = 0;
        roundBits = (byte) (zSig & 0x7F);
        if (isTiny & roundBits != 0)
          float_raise(FloatExceptionFlags.float_flag_underflow.getValue());
      }
    }
    if (roundBits != 0)
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();

    zSig = (zSig + roundIncrement) >>> 7;
    zSig &= ~((((roundBits ^ 0x40) == 0) & roundNearestEven) ? 1 : 0);
    if (zSig == 0)
      zExp = 0;

    return packFloat32(zSign, zExp, zSig);
  }

  /**
   * Takes an abstract floating-point value having sign `zSign', exponent `zExp', and significand
   * `zSig', and returns the proper single-precision floating- point value corresponding to the
   * abstract input. This routine is just like `roundAndPackFloat32' except that `zSig' does not
   * have to be normalized. Bit 31 of `zSig' must be zero, and `zExp' must be 1 less than the
   * ``true'' floating-point exponent.
   * 
   * @param zSign sign of abstract floating-point value (flag)
   * @param zExp exponent of abstract floating-point value (int16)
   * @param zSig significand of abstract floating-point value (bits32)
   * 
   * @return floating-point value (float32)
   */
  public static float normalizeRoundAndPackFloat32(boolean zSign, short zExp, int zSig) {
    byte shiftCount; // int8

    shiftCount = (byte) (JSoftFloatUtils.countLeadingZeros32(zSig) - 1);

    return roundAndPackFloat32(zSign, (short) (zExp - shiftCount), zSig << shiftCount);

  }

  /**
   * Returns the fraction bits of the double-precision floating-point value `a'.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return float64
   */
  public static long extractFloat64Frac(double a) {
    return Double.doubleToRawLongBits(a) & 0x000FFFFFFFFFFFFFL;
  }

  /**
   * Returns the exponent bits of the double-precision floating-point value `a'.
   * 
   * @param a float64
   * 
   * @return int16
   */
  public static short extractFloat64Exp(double a) {
    return (short) ((Double.doubleToRawLongBits(a) >>> 52) & 0x7FF);
  }

  /**
   * Returns the sign bit of the double-precision floating-point value `a'.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return sign bit
   */
  public static boolean extractFloat64Sign(double a) {
    return Double.doubleToRawLongBits(a) >> 63 != 0;
  }

  /**
   * Normalizes the subnormal double-precision floating-point value represented by the denormalized
   * significand `aSig'. The normalized exponent and significand are stored at the locations pointed
   * to by `zExpPtr' and `zSigPtr', respectively.
   * 
   * @param aSig double-precision floating-point value (bits64)
   * 
   * @return list{zExpPtr, zSigPtr}
   */
  static List<Number> normalizeFloat64Subnormal(final long aSig) {
    byte shiftCount; // int8
    short zExpPtr; // int16
    long zSigPtr; // bits64

    shiftCount = (byte) (JSoftFloatUtils.countLeadingZeros64(aSig) - 11);
    zSigPtr = aSig << shiftCount;
    zExpPtr = (short) (1 - shiftCount);

    List<Number> list = new ArrayList<Number>();
    list.add(zExpPtr);
    list.add(zSigPtr);

    return list;
  }

  /**
   * Packs the sign `zSign', exponent `zExp', and significand `zSig' into a double-precision
   * floating-point value, returning the result. After being shifted into the proper positions, the
   * three fields are simply added together to form the result. This means that any integer portion
   * of `zSig' will be added into the exponent. Since a properly normalized significand will have an
   * integer portion equal to 1, the `zExp' input should be 1 less than the desired result exponent
   * whenever `zSig' is a complete, normalized significand.
   * 
   * @param zSign sign of a double-precision floating-point value.
   * @param zExp exponent of a double-precision floating-point value.
   * @param zSig significand of a double-precision floating-point value.
   * 
   * @return float64
   */
  public static double packFloat64(boolean zSign, short zExp, long zSig) {
    return Double.longBitsToDouble((((long) (zSign ? 1 : 0)) << 63) + (((long) zExp) << 52) + zSig);
  }

  /**
   * Takes an abstract floating-point value having sign `zSign', exponent `zExp', and significand
   * `zSig', and returns the proper double-precision floating- point value corresponding to the
   * abstract input. Ordinarily, the abstract value is simply rounded and packed into the
   * double-precision format, with the inexact exception raised if the abstract input cannot be
   * represented exactly. However, if the abstract value is too large, the overflow and inexact
   * exceptions are raised and an infinity or maximal finite value is returned. If the abstract
   * value is too small, the input value is rounded to a subnormal number, and the underflow and
   * inexact exceptions are raised if the abstract input cannot be represented exactly as a
   * subnormal double- precision floating-point number. The input significand `zSig' has its binary
   * point between bits 62 and 61, which is 10 bits to the left of the usual location. This shifted
   * significand must be normalized or smaller. If `zSig' is not normalized, `zExp' must be 0; in
   * that case, the result returned is a subnormal number, and it must not require rounding. In the
   * usual case that `zSig' is normalized, `zExp' must be 1 less than the ``true'' floating-point
   * exponent. The handling of underflow and overflow follows the IEC/IEEE Standard for Binary
   * Floating-Point Arithmetic.
   * 
   * @param zSign flag
   * @param zExp int16
   * @param zSig bits64
   * 
   * @return float64
   */
  static double roundAndPackFloat64(final boolean zSign, short zExp, long zSig) {
    FloatRoundingMode roundingMode; // int8
    boolean roundNearestEven; // flag
    short roundIncrement, roundBits; // int16
    boolean isTiny; // flag

    roundingMode = float_rounding_mode;
    roundNearestEven = (roundingMode == FloatRoundingMode.float_round_nearest_even);
    roundIncrement = 0x200;
    if (!roundNearestEven) {
      if (roundingMode == FloatRoundingMode.float_round_to_zero) {
        roundIncrement = 0;
      } else {
        roundIncrement = 0x3FF;
        if (zSign) {
          if (roundingMode == FloatRoundingMode.float_round_up)
            roundIncrement = 0;
        } else {
          if (roundingMode == FloatRoundingMode.float_round_down)
            roundIncrement = 0;
        }
      }
    }
    roundBits = (short) (zSig & 0x3FF);
    if (0x7FD <= (zExp & 0xffff)) {
      if ((0x7FD < zExp) || ((zExp == 0x7FD) && ((zSig + roundIncrement) < 0))) {
        float_raise(FloatExceptionFlags.float_flag_overflow.getValue()
            | FloatExceptionFlags.float_flag_inexact.getValue());
        return packFloat64(zSign, (short) 0x7FF, 0) - (roundIncrement == 0 ? 1 : 0);
      }
      if (zExp < 0) {
        isTiny =
            (float_detect_tininess == FloatDetectTininess.float_tininess_before_rounding)
                || (zExp < -1) || (zSig + roundIncrement < 0x8000000000000000L);
        zSig = JSoftFloatUtils.shift64RightJamming(zSig, (short) -zExp);//, zSig);
        zExp = 0;
        roundBits = (short) (zSig & 0x3FF);
        if (isTiny && roundBits != 0)
          float_raise(FloatExceptionFlags.float_flag_underflow.getValue());
      }
    }
    if (roundBits != 0) {
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    }

    zSig = (zSig + roundIncrement) >>> 10;
    zSig &= ~(((roundBits ^ 0x200) == 0) & roundNearestEven ? 1 : 0);
    if (zSig == 0)
      zExp = 0;

    return packFloat64(zSign, zExp, zSig);
  }

  /**
   * Takes an abstract floating-point value having sign `zSign', exponent `zExp', and significand
   * `zSig', and returns the proper double-precision floating- point value corresponding to the
   * abstract input. This routine is just like `roundAndPackFloat64' except that `zSig' does not
   * have to be normalized. Bit 63 of `zSig' must be zero, and `zExp' must be 1 less than the
   * ``true'' floating-point exponent.
   * 
   * @param zSign flag
   * @param zExp int16
   * @param zSig bits64
   * 
   * @return float64
   */
  public static double normalizeRoundAndPackFloat64(boolean zSign, short zExp, long zSig) {
    byte shiftCount;

    shiftCount = (byte) (JSoftFloatUtils.countLeadingZeros64(zSig) - 1);
    return roundAndPackFloat64(zSign, (short) (zExp - shiftCount), zSig << shiftCount);
  }

  /**
   * Returns the fraction bits of the extended double-precision floating-point value `a'.
   * 
   * @param a floatx80
   * 
   * @return bits64
   */
  public static long extractFloatx80Frac(FloatX80 a) {
    return a.low;
  }

  /**
   * Returns the exponent bits of the extended double-precision floating-point value `a'.
   * 
   * @param a floatx80
   * 
   * @return int32
   */
  public static int extractFloatx80Exp(FloatX80 a) {
    return a.high & 0x7FFF;
  }

  /**
   * Returns the sign bit of the extended double-precision floating-point value | `a'.
   * 
   * @param a floatx80
   * 
   * @return flag
   */
  public static boolean extractFloatx80Sign(FloatX80 a) {
    return a.high >>> 15 != 0;
  }

  /**
   * Normalizes the subnormal extended double-precision floating-point value represented by the
   * denormalized significand `aSig'. The normalized exponent and significand are stored at the
   * locations pointed to by `zExpPtr' and `zSigPtr', respectively.
   * 
   * @param aSig bits64
   * @param zExpPtr int32
   * @param zSigPtr bits64
   * 
   * @return zExpPtr, zSigPtr
   */
  public static List<Number> normalizeFloatx80Subnormal(final long aSig) {
    byte shiftCount; // int8

    int zExpPtr;
    long zSigPtr;

    shiftCount = JSoftFloatUtils.countLeadingZeros64(aSig);

    zSigPtr = aSig << shiftCount;
    zExpPtr = 1 - shiftCount;

    List<Number> list = new ArrayList<Number>();
    list.add(zExpPtr);
    list.add(zSigPtr);

    return list;
  }

  /**
   * Packs the sign `zSign', exponent `zExp', and significand `zSig' into an extended
   * double-precision floating-point value, returning the result.
   * 
   * @param zSign flag
   * @param zExp int32
   * @param zSig bits64
   * 
   * @return zExpPtr, zSigPtr
   */
  public static FloatX80 packFloatx80(boolean zSign, int zExp, long zSig) {
    FloatX80 z = new FloatX80();
    z.low = zSig;
    z.high = (short) (((zSign ? 1 : 0) << 15) + zExp);

    return z;
  }

  /**
   * Takes an abstract floating-point value having sign `zSign', exponent `zExp', and extended
   * significand formed by the concatenation of `zSig0' and `zSig1', and returns the proper extended
   * double-precision floating-point value corresponding to the abstract input. Ordinarily, the
   * abstract value is rounded and packed into the extended double-precision format, with the
   * inexact exception raised if the abstract input cannot be represented exactly. However, if the
   * abstract value is too large, the overflow and inexact exceptions are raised and an infinity or
   * maximal finite value is returned. If the abstract value is too small, the input value is
   * rounded to a subnormal number, and the underflow and inexact exceptions are raised if the
   * abstract input cannot be represented exactly as a subnormal extended double-precision
   * floating-point number. If `roundingPrecision' is 32 or 64, the result is rounded to the same
   * number of bits as single or double precision, respectively. Otherwise, the result is rounded to
   * the full precision of the extended double-precision format. The input significand must be
   * normalized or smaller. If the input significand is not normalized, `zExp' must be 0; in that
   * case, the result returned is a subnormal number, and it must not require rounding. The handling
   * of underflow and overflow follows the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param roundingPrecision int8
   * @param zSign flag
   * @param zExp int32
   * @param zSig0 bits64
   * @param zSig1 bits64
   * 
   * @return Floatx80
   */
  static FloatX80 roundAndPackFloatx80(byte roundingPrecision, boolean zSign, int zExp, long zSig0,
      long zSig1) {
    FloatRoundingMode roundingMode; // int8
    boolean roundNearestEven, isTiny; // flag
    long roundIncrement, roundMask, roundBits; // int64

    roundingMode = float_rounding_mode;
    roundNearestEven = (roundingMode == FloatRoundingMode.float_round_nearest_even);
    if (roundingPrecision == 80) {
      // goto precision80;
      return roundAndPackFloatx80p2(roundingPrecision, zSign, zExp, zSig0, zSig1, roundNearestEven,
          roundingMode);
    }
    if (roundingPrecision == 64) {
      roundIncrement = 0x0000000000000400L;
      roundMask = 0x00000000000007FFL;
    } else if (roundingPrecision == 32) {
      roundIncrement = 0x0000008000000000L;
      roundMask = 0x000000FFFFFFFFFFL;
    } else {
      // goto precision80;
      return roundAndPackFloatx80p2(roundingPrecision, zSign, zExp, zSig0, zSig1, roundNearestEven,
          roundingMode);
    }
    zSig0 |= (zSig1 != 0 ? 1 : 0);
    if (!roundNearestEven) {
      if (roundingMode == FloatRoundingMode.float_round_to_zero) {
        roundIncrement = 0;
      } else {
        roundIncrement = roundMask;
        if (zSign) {
          if (roundingMode == FloatRoundingMode.float_round_up)
            roundIncrement = 0;
        } else {
          if (roundingMode == FloatRoundingMode.float_round_down)
            roundIncrement = 0;
        }
      }
    }
    roundBits = zSig0 & roundMask;
    if (0x7FFD <= (int) (zExp - 1)) { // bits32
      if ((0x7FFE < zExp) || ((zExp == 0x7FFE) && (zSig0 + roundIncrement < zSig0))) {
        // goto overflow;

        float_raise(FloatExceptionFlags.float_flag_overflow.getValue()
            | FloatExceptionFlags.float_flag_inexact.getValue());
        if ((roundingMode == FloatRoundingMode.float_round_to_zero)
            || (zSign && (roundingMode == FloatRoundingMode.float_round_up))
            || (!zSign && (roundingMode == FloatRoundingMode.float_round_down))) {
          return packFloatx80(zSign, 0x7FFE, ~roundMask);
        }
        return packFloatx80(zSign, 0x7FFF, 0x8000000000000000L);

      }
      if (zExp <= 0) {
        isTiny =
            (float_detect_tininess == FloatDetectTininess.float_tininess_before_rounding)
                || (zExp < 0) || (zSig0 <= zSig0 + roundIncrement);
        zSig0 = JSoftFloatUtils.shift64RightJamming(zSig0, (short) (1 - zExp));//, zSig0);

        zExp = 0;
        roundBits = zSig0 & roundMask;
        if (isTiny && roundBits != 0)
          float_raise(FloatExceptionFlags.float_flag_underflow.getValue());
        if (roundBits != 0)
          float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
        zSig0 += roundIncrement;
        if (zSig0 < 0)
          zExp = 1; // sbits64
        roundIncrement = roundMask + 1;
        if (roundNearestEven && (roundBits << 1 == roundIncrement)) {
          roundMask |= roundIncrement;
        }
        zSig0 &= ~roundMask;
        return packFloatx80(zSign, zExp, zSig0);
      }
    }
    if (roundBits != 0)
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    zSig0 += roundIncrement;
    if (zSig0 < roundIncrement) {
      ++zExp;
      zSig0 = 0x8000000000000000L;
    }
    roundIncrement = roundMask + 1;
    if (roundNearestEven && (roundBits << 1 == roundIncrement)) {
      roundMask |= roundIncrement;
    }
    zSig0 &= ~roundMask;
    if (zSig0 == 0)
      zExp = 0;
    return packFloatx80(zSign, zExp, zSig0);
  }

  /**
   * Second part of roundAndPackFloatx80
   */
  // precision80:
  static FloatX80 roundAndPackFloatx80p2(byte roundingPrecision, boolean zSign, int zExp,
      long zSig0, long zSig1, boolean roundNearestEven, FloatRoundingMode roundingMode) {
    boolean increment, isTiny; // flag
    long roundMask; // int64

    increment = ((long) zSig1 < 0); // sbits64
    if (!roundNearestEven) {
      if (roundingMode == FloatRoundingMode.float_round_to_zero) {
        increment = false;
      } else {
        if (zSign) {
          increment = (roundingMode == FloatRoundingMode.float_round_down) && zSig1 != 0;
        } else {
          increment = (roundingMode == FloatRoundingMode.float_round_up) && zSig1 != 0;
        }
      }
    }
    // if (0x7FFD <= (int) (zExp - 1)) { // bits32
    if (Utils.compareUnsigned(0x7FFD, (int) (zExp - 1)) || (0x7FFD == (zExp - 1))) { // bits32
      if ((0x7FFE < zExp) || ((zExp == 0x7FFE) && (zSig0 == 0xFFFFFFFFFFFFFFFFL) && increment)) {
        roundMask = 0;
        // overflow:
        float_raise(FloatExceptionFlags.float_flag_overflow.getValue()
            | FloatExceptionFlags.float_flag_inexact.getValue());
        if ((roundingMode == FloatRoundingMode.float_round_to_zero)
            || (zSign && (roundingMode == FloatRoundingMode.float_round_up))
            || (!zSign && (roundingMode == FloatRoundingMode.float_round_down))) {
          return packFloatx80(zSign, 0x7FFE, ~roundMask);
        }
        return packFloatx80(zSign, 0x7FFF, 0x8000000000000000L);
      }
      if (zExp <= 0) {
        isTiny =
            (float_detect_tininess == FloatDetectTininess.float_tininess_before_rounding)
                || (zExp < 0) || !increment || (zSig0 < 0xFFFFFFFFFFFFFFFFL);
        List<Long> list =
            JSoftFloatUtils.shift64ExtraRightJamming(zSig0, zSig1, 1 - zExp); //, zSig0, zSig1);
        zSig0 = list.get(0);
        zSig1 = list.get(1);

        zExp = 0;
        if (isTiny && zSig1 != 0)
          float_raise(FloatExceptionFlags.float_flag_underflow.getValue());
        if (zSig1 != 0)
          float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
        if (roundNearestEven) {
          increment = ((long) zSig1 < 0); // sbits64
        } else {
          if (zSign) {
            increment = (roundingMode == FloatRoundingMode.float_round_down) && zSig1 != 0;
          } else {
            increment = (roundingMode == FloatRoundingMode.float_round_up) && zSig1 != 0;
          }
        }
        if (increment) {
          ++zSig0;
          zSig0 &= ~(((zSig1 << 1) == 0) & roundNearestEven ? 1 : 0); // bits64
          if ((long) zSig0 < 0)
            zExp = 1; // bits64
        }
        return packFloatx80(zSign, zExp, zSig0);
      }
    }
    if (zSig1 != 0)
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    if (increment) {
      ++zSig0;
      if (zSig0 == 0) {
        ++zExp;
        zSig0 = 0x8000000000000000L; // LIT64
      } else {
        zSig0 &= ~(((zSig1 << 1) == 0) & roundNearestEven ? 1 : 0);
      }
    } else {
      if (zSig0 == 0)
        zExp = 0;
    }
    return packFloatx80(zSign, zExp, zSig0);
  }

  /**
   * Takes an abstract floating-point value having sign `zSign', exponent `zExp', and significand
   * formed by the concatenation of `zSig0' and `zSig1', and returns the proper extended
   * double-precision floating-point value corresponding to the abstract input. This routine is just
   * like `roundAndPackFloatx80' except that the input significand does not have to be normalized.
   * 
   * @param roundingPrecision int8
   * @param zSign flag
   * @param zExp int32
   * @param zSig0 bits64
   * @param zSig1 bits64
   * 
   * @return Floatx80
   */
  static FloatX80 normalizeRoundAndPackFloatx80(byte roundingPrecision, boolean zSign, int zExp,
      long zSig0, long zSig1) {
    byte shiftCount; // int8

    if (zSig0 == 0) {
      zSig0 = zSig1;
      zSig1 = 0;
      zExp -= 64;
    }
    shiftCount = JSoftFloatUtils.countLeadingZeros64(zSig0);
    List<Long> list = JSoftFloatUtils.shortShift128Left(zSig0, zSig1, shiftCount);//, zSig0, zSig1);
    zSig0 = list.get(0);
    zSig1 = list.get(1);

    zExp -= shiftCount;
    return roundAndPackFloatx80(roundingPrecision, zSign, zExp, zSig0, zSig1);
  }

  /**
   * Returns the least-significant 64 fraction bits of the quadruple-precision floating-point value
   * `a'.
   * 
   * @param a float128
   * 
   * @return bits64
   */
  public static long extractFloat128Frac1(Float128 a) {
    return a.low;
  }

  /**
   * Returns the most-significant 48 fraction bits of the quadruple-precision floating-point value
   * `a'.
   * 
   * @param a float128
   * 
   * @return bits64
   */
  public static long extractFloat128Frac0(Float128 a) {
    return a.high & 0x0000FFFFFFFFFFFFL;
  }

  /**
   * Returns the exponent bits of the quadruple-precision floating-point value `a'.
   * 
   * @param a float128
   * 
   * @return int32
   */
  public static int extractFloat128Exp(Float128 a) {
    return (int) ((a.high >>> 48) & 0x7FFF);
  }

  /**
   * Returns the sign bit of the quadruple-precision floating-point value `a'.
   * 
   * @param a float128
   * 
   * @return flag
   */
  public static boolean extractFloat128Sign(Float128 a) {
    return a.high >>> 63 != 0;
  }

  /**
   * Normalizes the subnormal quadruple-precision floating-point value represented by the
   * denormalized significand formed by the concatenation of `aSig0' and `aSig1'. The normalized
   * exponent is stored at the location pointed to by `zExpPtr'. The most significant 49 bits of the
   * normalized significand are stored at the location pointed to by `zSig0Ptr', and the least
   * significant 64 bits of the normalized significand are stored at the location pointed to by
   * `zSig1Ptr'.
   * 
   * @param aSig0 float128
   * @param aSig1 float128
   * @param zExpPtr 1int32
   * @param zSig0Ptr float128
   * @param zSig1Ptr float128
   * 
   * @return zExpPtr, zSig0Ptr, zSig1Ptr
   */
  public static List<Number> normalizeFloat128Subnormal(long aSig0, long aSig1, int zExpPtr,
      long zSig0Ptr, long zSig1Ptr) {
    byte shiftCount; // int8

    if (aSig0 == 0) {
      shiftCount = (byte) (JSoftFloatUtils.countLeadingZeros64(aSig1) - 15);
      if (shiftCount < 0) {
        zSig0Ptr = aSig1 >>> (-shiftCount);
        zSig1Ptr = aSig1 << (shiftCount & 63);
      } else {
        zSig0Ptr = aSig1 << shiftCount;
        zSig1Ptr = 0;
      }
      zExpPtr = -shiftCount - 63;
    } else {
      shiftCount = (byte) (JSoftFloatUtils.countLeadingZeros64(aSig0) - 15);
      List<Long> list =
          JSoftFloatUtils.shortShift128Left(aSig0, aSig1, shiftCount);//, zSig0Ptr, zSig1Ptr);
      zSig0Ptr = list.get(0);
      zSig1Ptr = list.get(1);

      zExpPtr = 1 - shiftCount;
    }
    List<Number> list = new ArrayList<Number>();
    list.add(zExpPtr);
    list.add(zSig0Ptr);
    list.add(zSig1Ptr);
    return list;
  }

  /**
   * Packs the sign `zSign', the exponent `zExp', and the significand formed by the concatenation of
   * `zSig0' and `zSig1' into a quadruple-precision floating-point value, returning the result.
   * After being shifted into the proper positions, the three fields `zSign', `zExp', and `zSig0'
   * are simply added together to form the most significant 32 bits of the result. This means that
   * any integer portion of `zSig0' will be added into the exponent. Since a properly normalized
   * significand will have an integer portion equal to 1, the `zExp' input should be 1 less than the
   * desired result exponent whenever `zSig0' and `zSig1' concatenated form a complete, normalized
   * significand.
   * 
   * @param zSign flag
   * @param zExp 1int32
   * @param zSig0 bits64
   * @param zSig1 bits64
   * 
   * @return Float128
   */
  public static Float128 packFloat128(boolean zSign, int zExp, long zSig0, long zSig1) {
    Float128 z = new Float128();

    z.low = zSig1;
    z.high = ((zSign ? (long) 1 : (long) 0) << 63) + (((long) zExp) << 48) + zSig0;
    return z;
  }

  /**
   * Takes an abstract floating-point value having sign `zSign', exponent `zExp', and extended
   * significand formed by the concatenation of `zSig0', `zSig1', and `zSig2', and returns the
   * proper quadruple-precision floating-point value corresponding to the abstract input.
   * Ordinarily, the abstract value is simply rounded and packed into the quadruple-precision
   * format, with the inexact exception raised if the abstract input cannot be represented exactly.
   * However, if the abstract value is too large, the overflow and inexact exceptions are raised and
   * an infinity or maximal finite value is returned. If the abstract value is too small, the input
   * value is rounded to a subnormal number, and the underflow and inexact exceptions are raised if
   * the abstract input cannot be represented exactly as a subnormal quadruple- precision
   * floating-point number. The input significand must be normalized or smaller. If the input
   * significand is not normalized, `zExp' must be 0; in that case, the result returned is a
   * subnormal number, and it must not require rounding. In the usual case that the input
   * significand is normalized, `zExp' must be 1 less than the ``true'' floating-point exponent. The
   * handling of underflow and overflow follows the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param zSign flag
   * @param zExp int32
   * @param zSig0 bits64
   * @param zSig1 bits64
   * @param zSig2 bits64
   * 
   * @return Float128
   */
  public static Float128 roundAndPackFloat128(boolean zSign, int zExp, long zSig0, long zSig1,
      long zSig2) {
    FloatRoundingMode roundingMode; // int8
    boolean roundNearestEven, increment, isTiny; // flag

    roundingMode = float_rounding_mode;
    roundNearestEven = (roundingMode == FloatRoundingMode.float_round_nearest_even);

    increment = (zSig2 < 0);
    if (!roundNearestEven) {
      if (roundingMode == FloatRoundingMode.float_round_to_zero) {
        increment = false;
      } else {
        if (zSign) {
          increment = (roundingMode == FloatRoundingMode.float_round_down) && zSig2 != 0;
        } else {
          increment = (roundingMode == FloatRoundingMode.float_round_up) && zSig2 != 0;
        }
      }
    }
    // if (0x7FFD <= zExp) {
    if (Utils.compareUnsigned(0x7FFD, zExp) || 0x7FFD == zExp) {
      if ((0x7FFD < zExp)
          || ((zExp == 0x7FFD)
              && JSoftFloatUtils.eq128(0x0001FFFFFFFFFFFFL, 0xFFFFFFFFFFFFFFFFL, zSig0, zSig1) && increment)) {
        float_raise(FloatExceptionFlags.float_flag_overflow.getValue()
            | FloatExceptionFlags.float_flag_inexact.getValue());
        if ((roundingMode == FloatRoundingMode.float_round_to_zero)
            || (zSign && (roundingMode == FloatRoundingMode.float_round_up))
            || (!zSign && (roundingMode == FloatRoundingMode.float_round_down))) {
          return packFloat128(zSign, 0x7FFE, 0x0000FFFFFFFFFFFFL, 0xFFFFFFFFFFFFFFFFL);
        }
        return packFloat128(zSign, 0x7FFF, 0, 0);
      }
      if (zExp < 0) {
        isTiny =
            (float_detect_tininess == FloatDetectTininess.float_tininess_before_rounding)
                || (zExp < -1) || !increment
                || JSoftFloatUtils.lt128(zSig0, zSig1, 0x0001FFFFFFFFFFFFL, 0xFFFFFFFFFFFFFFFFL);
        List<Long> list =
            JSoftFloatUtils.shift128ExtraRightJamming(zSig0, zSig1, zSig2, -zExp);//, zSig0, zSig1, zSig2);
        zSig0 = list.get(0);
        zSig1 = list.get(1);
        zSig2 = list.get(2);

        zExp = 0;
        if (isTiny && zSig2 != 0)
          float_raise(FloatExceptionFlags.float_flag_underflow.getValue());
        if (roundNearestEven) {
          increment = ((long) zSig2 < 0);
        } else {
          if (zSign) {
            increment = (roundingMode == FloatRoundingMode.float_round_down) && zSig2 != 0;
          } else {
            increment = (roundingMode == FloatRoundingMode.float_round_up) && zSig2 != 0;
          }
        }
      }
    }
    if (zSig2 != 0)
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    if (increment) {
      List<Long> list = JSoftFloatUtils.add128(zSig0, zSig1, 0, 1); // , zSig0, zSig1);
      zSig0 = list.get(0);
      zSig1 = list.get(1);
      zSig1 &= ~((zSig2 + zSig2 == 0) & roundNearestEven ? 1 : 0);
    } else {
      if ((zSig0 | zSig1) == 0)
        zExp = 0;
    }
    return packFloat128(zSign, zExp, zSig0, zSig1);
  }

  /**
   * Takes an abstract floating-point value having sign `zSign', exponent `zExp', and significand
   * formed by the concatenation of `zSig0' and `zSig1', and returns the proper quadruple-precision
   * floating-point value corresponding to the abstract input. This routine is just like
   * `roundAndPackFloat128' except that the input significand has fewer bits and does not have to be
   * normalized. In all cases, `zExp' must be 1 less than the ``true'' floating- point exponent.
   * 
   * @param zSign flag
   * @param zExp int32
   * @param zSig0 bits64
   * @param zSig1 bits64
   * 
   * @return Float128
   */
  public static Float128 normalizeRoundAndPackFloat128(boolean zSign, int zExp, long zSig0,
      long zSig1) {
    byte shiftCount; // int8
    long zSig2; // bits64

    if (zSig0 == 0) {
      zSig0 = zSig1;
      zSig1 = 0;
      zExp -= 64;
    }
    shiftCount = (byte) (JSoftFloatUtils.countLeadingZeros64(zSig0) - 15);
    zSig2 = 0;
    if (0 <= shiftCount) {
      List<Long> list = JSoftFloatUtils.shortShift128Left(zSig0, zSig1, shiftCount);//, zSig0, zSig1);
      zSig0 = list.get(0);
      zSig1 = list.get(1);
    } else {
      List<Long> list =
          JSoftFloatUtils.shift128ExtraRightJamming(zSig0, zSig1, 0, -shiftCount);//, zSig0, zSig1, zSig2);
      zSig0 = list.get(0);
      zSig1 = list.get(1);
      zSig2 = list.get(2);
    }

    zExp -= shiftCount;
    return roundAndPackFloat128(zSign, zExp, zSig0, zSig1, zSig2);
  }

  /**
   * Returns the result of converting the 32-bit two's complement integer `a' to the
   * single-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the 32-bit integer.
   * 
   * @return float32
   */
  public static float int32_to_float32(int a) {
    boolean zSign; // flag

    if (a == 0)
      return 0;
    if (a == 0x80000000)
      return packFloat32(true, (short) 0x9E, 0);
    zSign = (a < 0);
    return normalizeRoundAndPackFloat32(zSign, (short) 0x9C, zSign ? -1 * a : a);
  }

  /**
   * Returns the result of converting the 32-bit two's complement integer `a' to the
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the 32-bit integer.
   * 
   * @return float64
   */
  public static double int32_to_float64(int a) {
    boolean zSign; // flag
    int absA; // uint32
    short shiftCount; // int8
    long zSig; // bits64

    if (a == 0)
      return 0;
    zSign = (a < 0);
    absA = zSign ? -a : a;
    shiftCount = (short) (JSoftFloatUtils.countLeadingZeros32(absA) + 21);
    zSig = absA;
    return packFloat64(zSign, (short) (0x432 - shiftCount), zSig << shiftCount);
  }

  /**
   * Returns the result of converting the 32-bit two's complement integer `a' to the extended
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the 32-bit integer.
   * 
   * @return float80
   */
  public static FloatX80 int32_to_floatx80(int a) {
    boolean zSign; // flag
    int absA; // uint32
    short shiftCount; // int8
    long zSig; // bits64

    if (a == 0)
      return packFloatx80(false, 0, 0);
    zSign = (a < 0);
    absA = zSign ? -a : a;
    shiftCount = (short) (JSoftFloatUtils.countLeadingZeros32(absA) + 32);
    zSig = absA;
    return packFloatx80(zSign, 0x403E - shiftCount, zSig << shiftCount);
  }

  /**
   * Returns the result of converting the 32-bit two's complement integer `a' to the
   * quadruple-precision floating-point format. The conversion is performed according to the
   * IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the 32-bit integer.
   * 
   * @return float128
   */
  public static Float128 int32_to_float128(final int a) {
    boolean zSign; // flag
    int absA; // uint32
    short shiftCount; // int8
    long zSig0; // bits64

    if (a == 0)
      return packFloat128(false, 0, 0, 0);
    zSign = (a < 0);
    absA = zSign ? -a : a;
    shiftCount = (short) (JSoftFloatUtils.countLeadingZeros32(absA) + 17);
    zSig0 = absA;
    return packFloat128(zSign, 0x402E - shiftCount, zSig0 << shiftCount, 0);
  }

  /**
   * Returns the result of converting the 64-bit two's complement integer `a' to the
   * single-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the 64-bit integer.
   * 
   * @return float32
   */
  public static float int64_to_float32(long a) {
    boolean zSign; // flag
    long absA; // uint64
    short shiftCount; // int8
    // int zSig; //bits32

    if (a == 0)
      return 0;
    zSign = (a < 0);
    absA = zSign ? -a : a;
    shiftCount = (short) (JSoftFloatUtils.countLeadingZeros64(absA) - 40);
    if (0 <= shiftCount) {
      return packFloat32(zSign, (short) (0x95 - shiftCount), (int) (absA << shiftCount));
    } else {
      shiftCount += 7;
      if (shiftCount < 0) {
        absA = JSoftFloatUtils.shift64RightJamming(absA, (short) -shiftCount);//, absA);
      } else {
        absA <<= shiftCount;
      }
      return roundAndPackFloat32(zSign, (short) (0x9C - shiftCount), (int) absA);
    }
  }

  /**
   * Returns the result of converting the 64-bit two's complement integer `a' to the
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the 64-bit integer.
   * 
   * @return float64
   */
  public static double int64_to_float64(long a) {
    boolean zSign; // flag

    if (a == 0)
      return 0;
    if (a == (long) 0x8000000000000000L) {
      return packFloat64(true, (short) 0x43E, 0);
    }
    zSign = (a < 0);
    return normalizeRoundAndPackFloat64(zSign, (short) 0x43C, zSign ? -a : a);
  }

  /**
   * Returns the result of converting the 64-bit two's complement integer `a' to the extended
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the 64-bit integer.
   * 
   * @return float80
   */
  public static FloatX80 int64_to_floatx80(long a) {
    boolean zSign; // flag
    long absA; // uint64
    byte shiftCount; // int8

    if (a == 0)
      return packFloatx80(false, 0, 0);
    zSign = (a < 0);
    absA = zSign ? -a : a;
    shiftCount = JSoftFloatUtils.countLeadingZeros64(absA);
    return packFloatx80(zSign, 0x403E - shiftCount, absA << shiftCount);
  }

  /**
   * Returns the result of converting the 64-bit two's complement integer `a' to the
   * quadruple-precision floating-point format. The conversion is performed according to the
   * IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the 64-bit integer.
   * 
   * @return float128
   */
  public static Float128 int64_to_float128(long a) {
    boolean zSign; // flag
    long absA; // uint64
    byte shiftCount; // int8
    int zExp; // int32
    long zSig0, zSig1; // bits64

    if (a == 0)
      return packFloat128(false, 0, 0, 0);
    zSign = (a < 0);
    absA = zSign ? -a : a;
    shiftCount = (byte) (JSoftFloatUtils.countLeadingZeros64(absA) + 49);
    zExp = 0x406E - shiftCount;
    if (64 <= shiftCount) {
      zSig1 = 0;
      zSig0 = absA;
      shiftCount -= 64;
    } else {
      zSig1 = absA;
      zSig0 = 0;
    }
    List<Long> list = JSoftFloatUtils.shortShift128Left(zSig0, zSig1, shiftCount);//, zSig0, zSig1);
    zSig0 = list.get(0);
    zSig1 = list.get(1);

    return packFloat128(zSign, zExp, zSig0, zSig1);
  }

  /**
   * Returns the result of converting the single-precision floating-point value `a' to the 32-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic---which means in particular that the conversion is rounded
   * according to the current rounding mode. If `a' is a NaN, the largest positive integer is
   * returned. Otherwise, if the conversion overflows, the largest integer with the same sign as `a'
   * is returned.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return int32
   */
  public static int float32_to_int32(float a) {
    boolean aSign; // flag
    short aExp, shiftCount; // int16
    int aSig; // bits32
    long aSig64; // bits64

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);
    if ((aExp == 0xFF) && aSig != 0)
      aSign = false;
    if (aExp != 0)
      aSig |= 0x00800000;
    shiftCount = (short) (0xAF - aExp);
    aSig64 = aSig;
    aSig64 <<= 32;
    if (0 < shiftCount)
      aSig64 = JSoftFloatUtils.shift64RightJamming(aSig64, shiftCount);//, aSig64);

    return roundAndPackInt32(aSign, aSig64);
  }

  /**
   * Returns the result of converting the single-precision floating-point value `a' to the 32-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic, except that the conversion is always rounded toward zero.
   * If `a' is a NaN, the largest positive integer is returned. Otherwise, if the conversion
   * overflows, the largest integer with the same sign as `a' is returned.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return int32
   */
  public static int float32_to_int32_round_to_zero(float a) {
    boolean aSign; // flag
    short aExp, shiftCount; // int16
    int aSig; // bits32
    int z; // int32

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);

    shiftCount = (short) (aExp - 0x9E);
    if (0 <= shiftCount) {
      if (a != 0xCF000000) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        if (!aSign || ((aExp == 0xFF) && aSig != 0))
          return 0x7FFFFFFF;
      }
      return 0x80000000;
    } else if (aExp <= 0x7E) {
      if ((aExp | aSig) != 0)
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      return 0;
    }
    aSig = (aSig | 0x00800000) << 8;
    z = aSig >>> (-shiftCount);
    if (aSig << (shiftCount & 31) != 0) {
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    }
    if (aSign)
      z = -z;
    return z;
  }

  /**
   * Returns the result of converting the single-precision floating-point value `a' to the 64-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic---which means in particular that the conversion is rounded
   * according to the current rounding mode. If `a' is a NaN, the largest positive integer is
   * returned. Otherwise, if the conversion overflows, the largest integer with the same sign as `a'
   * is returned.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return int64
   */
  public static long float32_to_int64(float a) {
    boolean aSign; // flag
    short aExp, shiftCount; // int16
    int aSig; // bits32
    long aSig64, aSigExtra; // bits64

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);
    shiftCount = (short) (0xBE - aExp);
    if (shiftCount < 0) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      if (!aSign || ((aExp == 0xFF) && aSig != 0)) {
        return 0x7FFFFFFFFFFFFFFFL;
      }
      return 0x8000000000000000L;
    }
    if (aExp != 0)
      aSig |= 0x00800000;
    aSig64 = aSig;
    aSig64 <<= 40;
    aSigExtra = 0;
    List<Long> list =
        JSoftFloatUtils.shift64ExtraRightJamming(aSig64, 0, shiftCount); //, aSig64, aSigExtra);
    aSig64 = list.get(0);
    aSigExtra = list.get(1);
    return roundAndPackInt64(aSign, aSig64, aSigExtra);
  }

  /**
   * Returns the result of converting the single-precision floating-point value `a' to the 64-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic, except that the conversion is always rounded toward zero.
   * If `a' is a NaN, the largest positive integer is returned. Otherwise, if the conversion
   * overflows, the largest integer with the same sign as `a' is returned.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return int64
   */
  public static long float32_to_int64_round_to_zero(float a) {
    boolean aSign; // flag
    short aExp, shiftCount; // int16
    int aSig; // bits32
    long aSig64; // bits64
    long z; // int64

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);
    shiftCount = (short) (aExp - 0xBE);
    if (0 <= shiftCount) {
      if (a != 0xDF000000) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        if (!aSign || ((aExp == 0xFF) && aSig != 0)) {
          return 0x7FFFFFFFFFFFFFFFL;
        }
      }
      return 0x8000000000000000L;
    } else if (aExp <= 0x7E) {
      if ((aExp | aSig) != 0)
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      return 0;
    }
    aSig64 = aSig | 0x00800000;
    aSig64 <<= 40;
    z = aSig64 >>> (-shiftCount);
    if (aSig64 << (shiftCount & 63) != 0) {
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    }
    if (aSign)
      z = -z;
    return z;
  }

  /**
   * Returns the result of converting the single-precision floating-point NaN `a' to the canonical
   * NaN format. If `a' is a signaling NaN, the invalid exception is raised.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return CommonNaNT
   */
  static CommonNaNT float32ToCommonNaN(float a) {
    CommonNaNT z = new CommonNaNT();

    if (float32_is_signaling_nan(a))
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
    z.sign = Float.floatToRawIntBits(a) >>> 31 != 0;
    z.low = 0;
    z.high = (Float.floatToRawIntBits(a)) << 41;
    return z;
  }

  /**
   * Returns 1 if the single-precision floating-point value `a' is a signaling NaN; otherwise
   * returns 0.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float32_is_signaling_nan(float a) {
    BigInteger aBigInteger = Utils.getUnsignedBigInteger(Float.floatToRawIntBits(a));

    boolean aOne =
        aBigInteger.shiftRight(22).and(Utils.getUnsignedBigInteger(0x1FF))
            .equals(Utils.getUnsignedBigInteger(0x1FE));
    boolean aTwo = aBigInteger.and(Utils.getUnsignedBigInteger(0x003FFFFF)).equals(BigInteger.ZERO);

    // return (((Float.floatToRawIntBits(a) >>> 22) & 0x1FF) == 0x1FE)
    // && (Float.floatToRawIntBits(a) & 0x003FFFFF) != 0;
    return aOne && !aTwo;
  }

  /**
   * Returns the result of converting the canonical NaN `a' to the double- precision floating-point
   * format.
   * 
   * @param a - commonNaNT
   * 
   * @return float64
   */
  public static double commonNaNToFloat64(CommonNaNT a) {
    return Double.longBitsToDouble(((a.sign ? (long) 1 : (long) 0) << 63) | 0x7FF8000000000000L
        | (a.high >>> 12));
  }

  /**
   * Returns the result of converting the single-precision floating-point value `a' to the
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return float64
   */
  public static double float32_to_float64(float a) {
    boolean aSign; // flag
    short aExp; // int16
    int aSig; // bits32

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);
    if (aExp == 0xFF) {
      if (aSig != 0)
        return commonNaNToFloat64(float32ToCommonNaN(a));
      return packFloat64(aSign, (short) 0x7FF, 0);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloat64(aSign, (short) 0, 0);
      List<Number> list = normalizeFloat32Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Integer) list.get(1);
      --aExp;
    }
    return packFloat64(aSign, (short) (aExp + 0x380), ((long) aSig) << 29);
  }

  /**
   * Returns the result of converting the single-precision floating-point value `a' to the extended
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return floatx80
   */
  public static FloatX80 float32_to_floatx80(float a) {
    boolean aSign; // flag
    short aExp; // int16
    int aSig; // bits32

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);
    if (aExp == 0xFF) {
      if (aSig != 0)
        return commonNaNToFloatx80(float32ToCommonNaN(a));
      return packFloatx80(aSign, 0x7FFF, 0x8000000000000000L);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloatx80(aSign, 0, 0);
      List<Number> list = normalizeFloat32Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Integer) list.get(1);
    }
    aSig |= 0x00800000;
    return packFloatx80(aSign, aExp + 0x3F80, ((long) aSig) << 40);
  }

  /**
   * Returns the result of converting the canonical NaN `a' to the extended double-precision
   * floating-point format.
   * 
   * @param a commonNaNT
   * 
   * @return floatx80
   */
  public static FloatX80 commonNaNToFloatx80(CommonNaNT a) {
    FloatX80 z = new FloatX80();

    z.low = 0xC000000000000000L | (a.high >>> 1);
    z.high = (short) (((a.sign ? 1 : 0) << 15) | 0x7FFF);
    return z;
  }

  /**
   * Returns the result of converting the single-precision floating-point value `a' to the
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return float128
   */
  public static Float128 float32_to_float128(float a) {
    boolean aSign; // flag
    short aExp; // int16
    int aSig; // bits32

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);
    if (aExp == 0xFF) {
      if (aSig != 0)
        return commonNaNToFloat128(float32ToCommonNaN(a));
      return packFloat128(aSign, 0x7FFF, 0, 0);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloat128(aSign, 0, 0, 0);
      List<Number> list = normalizeFloat32Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Integer) list.get(1);
      --aExp;
    }
    return packFloat128(aSign, aExp + 0x3F80, ((long) aSig) << 25, 0);
  }

  /**
   * Returns the result of converting the canonical NaN `a' to the quadruple- precision
   * floating-point format.
   * 
   * @param a commonNaNT
   * 
   * @return float128
   */
  static Float128 commonNaNToFloat128(CommonNaNT a) {
    Float128 z = new Float128();

    List<Long> list = JSoftFloatUtils.shift128Right(a.high, a.low, (short) 16);//, z.high, z.low);
    z.high = list.get(0);
    z.low = list.get(1);

    z.high |= (((long) (a.sign ? (long) 1 : (long) 0)) << 63) | 0x7FFF800000000000L;
    return z;
  }

  /**
   * Rounds the single-precision floating-point value `a' to an integer, and returns the result as a
   * single-precision floating-point value. The operation is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return float32
   */
  public static float float32_round_to_int(float a) {
    boolean aSign; // flag
    short aExp; //
    int lastBitMask, roundBitsMask; // bits32
    FloatRoundingMode roundingMode; // int8
    float z; // float32

    aExp = extractFloat32Exp(a);
    if (0x96 <= aExp) {
      if ((aExp == 0xFF) && extractFloat32Frac(a) != 0) {
        return propagateFloat32NaN(a, a);
      }
      return a;
    }
    if (aExp <= 0x7E) {
      if ((Float.floatToRawIntBits(a) << 1) == 0)
        return a;
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      aSign = extractFloat32Sign(a);
      switch (float_rounding_mode) {
        case float_round_nearest_even:
          if ((aExp == 0x7E) && extractFloat32Frac(a) != 0) {
            return packFloat32(aSign, (short) 0x7F, 0);
          }
          break;
        case float_round_down:
          return aSign ? 0xBF800000 : 0;
        case float_round_up:
          return aSign ? 0x80000000 : 0x3F800000;
          // Default
        default:
          break;
      }
      return packFloat32(aSign, (short) 0, 0);
    }
    lastBitMask = 1;
    lastBitMask <<= 0x96 - aExp;
    roundBitsMask = lastBitMask - 1;
    z = a;
    roundingMode = float_rounding_mode;
    if (roundingMode == FloatRoundingMode.float_round_nearest_even) {
      z += lastBitMask >>> 1;
      if (Float.intBitsToFloat((Float.floatToRawIntBits(z) & roundBitsMask)) == 0) {
        z = Float.intBitsToFloat(Float.floatToRawIntBits(z) & (~lastBitMask));
      }
    } else if (roundingMode != FloatRoundingMode.float_round_to_zero) {
      if (extractFloat32Sign(z) ^ (roundingMode == FloatRoundingMode.float_round_up)) {
        z += roundBitsMask;
      }
    }
    z = Float.intBitsToFloat(Float.floatToRawIntBits(z) & (~roundBitsMask)); // z &= ~
                                                                             // roundBitsMask;
    if (z != a)
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    return z;
  }

  /**
   * Takes two single-precision floating-point values `a' and `b', one of which is a NaN, and
   * returns the appropriate NaN result. If either `a' or `b' is a signaling NaN, the invalid
   * exception is raised.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return float32
   */
  public static float propagateFloat32NaN(float a, float b) {
    boolean aIsNaN, aIsSignalingNaN, bIsNaN, bIsSignalingNaN; // flag

    aIsNaN = float32_is_nan(a);
    aIsSignalingNaN = float32_is_signaling_nan(a);
    bIsNaN = float32_is_nan(b);
    bIsSignalingNaN = float32_is_signaling_nan(b);
    a = Float.intBitsToFloat(Float.floatToRawIntBits(a) | 0x00400000); // a |= 0x00400000;
    b = Float.intBitsToFloat(Float.floatToRawIntBits(b) | 0x00400000); // b |= 0x00400000;

    if (aIsSignalingNaN | bIsSignalingNaN)
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
    if (aIsSignalingNaN) {
      if (bIsSignalingNaN) {
        // goto returnLargerSignificand;
        return returnLargerSignificand(a, b);
      }
      return bIsNaN ? b : a;
    } else if (aIsNaN) {
      if (bIsSignalingNaN | !bIsNaN) {
        return a;
      }
      // returnLargerSignificand:
      return returnLargerSignificand(a, b);
    } else {
      return b;
    }
  }

  private static float returnLargerSignificand(float a, float b) {
    // if ( (bits32) ( a<<1 ) < (bits32) ( b<<1 ) ) return b;
    if (((Float.floatToRawIntBits(a) << 1) & 0xffffffffL) < ((Float.floatToRawIntBits(b) << 1) & 0xffffffffL)) {
      return b;
    }
    // if ( (bits32) ( b<<1 ) < (bits32) ( a<<1 ) ) return a;
    if (((Float.floatToRawIntBits(b) << 1) & 0xffffffffL) < ((Float.floatToRawIntBits(a) << 1) & 0xffffffffL)) {
      return a;
    }
    return (a < b) ? a : b;
  }

  /**
   * Returns 1 if the single-precision floating-point value `a' is a NaN; otherwise returns 0.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float32_is_nan(float a) {
    return (0xFF000000L < (0xffffffffL & (Float.floatToRawIntBits(a) << 1)));
  }

  /**
   * Returns the result of adding the absolute values of the single-precision floating-point values
   * `a' and `b'. If `zSign' is 1, the sum is negated before being returned. `zSign' is ignored if
   * the result is a NaN. The addition is performed according to the IEC/IEEE Standard for Binary
   * Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * @param zSign flag
   * 
   * @return float32
   */
  static float addFloat32Sigs(float a, float b, boolean zSign) {
    short aExp, bExp, zExp; // int16
    int aSig, bSig, zSig; // bits32
    short expDiff; // int16

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    bSig = extractFloat32Frac(b);
    bExp = extractFloat32Exp(b);
    expDiff = (short) (aExp - bExp);
    aSig <<= 6;
    bSig <<= 6;
    if (0 < expDiff) {
      if (aExp == 0xFF) {
        if (aSig != 0)
          return propagateFloat32NaN(a, b);
        return a;
      }
      if (bExp == 0) {
        --expDiff;
      } else {
        bSig |= 0x20000000;
      }
      bSig = JSoftFloatUtils.shift32RightJamming(bSig, expDiff);//, bSig);
      zExp = aExp;
    } else if (expDiff < 0) {
      if (bExp == 0xFF) {
        if (bSig != 0)
          return propagateFloat32NaN(a, b);
        return packFloat32(zSign, (short) 0xFF, 0);
      }
      if (aExp == 0) {
        ++expDiff;
      } else {
        aSig |= 0x20000000;
      }
      aSig = JSoftFloatUtils.shift32RightJamming(aSig, (short) -expDiff);//, aSig);
      zExp = bExp;
    } else {
      if (aExp == 0xFF) {
        if ((aSig | bSig) != 0)
          return propagateFloat32NaN(a, b);
        return a;
      }
      if (aExp == 0)
        return packFloat32(zSign, (short) 0, (aSig + bSig) >>> 6);
      zSig = 0x40000000 + aSig + bSig;
      zExp = aExp;
      // goto roundAndPack;
      return roundAndPackFloat32(zSign, zExp, zSig);
    }
    aSig |= 0x20000000;
    zSig = (aSig + bSig) << 1;
    --zExp;
    if ((int) zSig < 0) {
      zSig = aSig + bSig;
      ++zExp;
    }
    // roundAndPack:
    return roundAndPackFloat32(zSign, zExp, zSig);
  }

  /**
   * Returns the result of subtracting the absolute values of the single- precision floating-point
   * values `a' and `b'. If `zSign' is 1, the difference is negated before being returned. `zSign'
   * is ignored if the result is a NaN. The subtraction is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * @param zSign flag
   * 
   * @return float32
   */
  public static float subFloat32Sigs(float a, float b, boolean zSign) {
    // goto
    short aExp, bExp, zExp; // int16
    int aSig, bSig, zSig; // bits32
    short expDiff; // int16
    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    bSig = extractFloat32Frac(b);
    bExp = extractFloat32Exp(b);

    expDiff = (short) (aExp - bExp);
    aSig <<= 7;
    bSig <<= 7;

    if (0 < expDiff) {
      // goto aExpBigger;
      if (aExp == 0xFF) {
        if (aSig != 0)
          return propagateFloat32NaN(a, b);
        return a;
      }
      if (bExp == 0) {
        --expDiff;
      } else {
        bSig |= 0x40000000;
      }
      bSig = JSoftFloatUtils.shift32RightJamming(bSig, expDiff);//, bSig); // TODO remove bSig
      aSig |= 0x40000000;
      zSig = aSig - bSig;
      zExp = aExp;
      --zExp;
      return normalizeRoundAndPackFloat32(zSign, zExp, zSig);
    }
    if (expDiff < 0) {
      // goto bExpBigger;
      if (bExp == 0xFF) {
        if (bSig != 0)
          return propagateFloat32NaN(a, b);
        return packFloat32(zSign ^ true, (short) 0xFF, 0);
      }
      if (aExp == 0) {
        ++expDiff;
      } else {
        aSig |= 0x40000000;
      }
      aSig = JSoftFloatUtils.shift32RightJamming(aSig, (short) -expDiff);//, aSig);
      bSig |= 0x40000000;
      zSig = bSig - aSig;
      zExp = bExp;
      zSign ^= true;
      --zExp;
      return normalizeRoundAndPackFloat32(zSign, zExp, zSig);
    }
    if (aExp == 0xFF) {
      if ((aSig | bSig) != 0)
        return propagateFloat32NaN(a, b);
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return float32_default_nan;
    }
    if (aExp == 0) {
      aExp = 1;
      bExp = 1;
    }
    if (bSig < aSig) {
      // goto aBigger;
      zSig = aSig - bSig;
      zExp = aExp;
      --zExp;
      return normalizeRoundAndPackFloat32(zSign, zExp, zSig);
    }
    if (aSig < bSig) {
      // goto bBigger;
      zSig = bSig - aSig;
      zExp = bExp;
      zSign ^= true;
      --zExp;
      return normalizeRoundAndPackFloat32(zSign, zExp, zSig);
    }
    return packFloat32(float_rounding_mode == FloatRoundingMode.float_round_down, (short) 0, 0);

  }

  /**
   * Returns the result of adding the single-precision floating-point values `a' and `b'. The
   * operation is performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return float32
   */
  public static float float32_add(float a, float b) {
    boolean aSign, bSign; // flag

    aSign = extractFloat32Sign(a);
    bSign = extractFloat32Sign(b);
    if (aSign == bSign) {
      return addFloat32Sigs(a, b, aSign);
    } else {
      return subFloat32Sigs(a, b, aSign);
    }
  }

  /**
   * Returns the result of subtracting the single-precision floating-point values `a' and `b'. The
   * operation is performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return float32
   */
  public static float float32_sub(float a, float b) {
    boolean aSign, bSign; // flag

    aSign = extractFloat32Sign(a);
    bSign = extractFloat32Sign(b);

    if (aSign == bSign) {
      return subFloat32Sigs(a, b, aSign);
    } else {
      return addFloat32Sigs(a, b, aSign);
    }
  }

  /**
   * Returns the result of multiplying the single-precision floating-point values `a' and `b'. The
   * operation is performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return float32
   */
  public static float float32_mul(float a, float b) {
    boolean aSign, bSign, zSign; // flag
    short aExp, bExp, zExp; // int16
    int aSig, bSig; // bits32
    long zSig64; // bits64
    int zSig; // bits32

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);
    bSig = extractFloat32Frac(b);
    bExp = extractFloat32Exp(b);
    bSign = extractFloat32Sign(b);
    zSign = aSign ^ bSign;
    if (aExp == 0xFF) {
      if ((aSig != 0) || ((bExp == 0xFF) && (bSig != 0))) {
        return propagateFloat32NaN(a, b);
      }
      if ((bExp | bSig) == 0) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        return float32_default_nan;
      }
      return packFloat32(zSign, (short) 0xFF, 0);
    }
    if (bExp == 0xFF) {
      if (bSig != 0)
        return propagateFloat32NaN(a, b);
      if ((aExp | aSig) == 0) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        return float32_default_nan;
      }
      return packFloat32(zSign, (short) 0xFF, 0);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloat32(zSign, (short) 0, 0);
      List<Number> list = normalizeFloat32Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Integer) list.get(1);
    }
    if (bExp == 0) {
      if (bSig == 0)
        return packFloat32(zSign, (short) 0, 0);
      List<Number> list = normalizeFloat32Subnormal(bSig);
      bExp = (Short) list.get(0);
      bSig = (Integer) list.get(1);
    }
    zExp = (short) (aExp + bExp - 0x7F);

    BigInteger aSigTemp;
    aSigTemp = BigInteger.valueOf((long) (aSig | 0x00800000));// aSig = (aSig | 0x00800000) << 7;
    aSigTemp = aSigTemp.shiftLeft(7);

    BigInteger bSigTemp;
    bSigTemp = BigInteger.valueOf(bSig | 0x00800000); // bSig = (bSig | 0x00800000) << 8;
    bSigTemp = bSigTemp.shiftLeft(8);

    aSigTemp = aSigTemp.multiply(bSigTemp);// ((long) aSig) * bSig

    zSig64 = 0;
    zSig64 = JSoftFloatUtils.shift64RightJamming(aSigTemp.longValue(), (short) 32);//, zSig64);
    zSig = (int) zSig64;
    if (0 <= (int) (zSig << 1)) {
      zSig <<= 1;
      --zExp;
    }

    return roundAndPackFloat32(zSign, zExp, zSig);
  }

  /**
   * Returns the result of dividing the single-precision floating-point value `a' by the
   * corresponding value `b'. The operation is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return float32
   */
  public static float float32_div(float a, float b) {
    boolean aSign, bSign, zSign; // flag
    short aExp, bExp, zExp; // int16
    int aSig, bSig, zSig; // bits32

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);
    bSig = extractFloat32Frac(b);
    bExp = extractFloat32Exp(b);
    bSign = extractFloat32Sign(b);
    zSign = aSign ^ bSign;
    if (aExp == 0xFF) {
      if (aSig != 0)
        return propagateFloat32NaN(a, b);
      if (bExp == 0xFF) {
        if (bSig != 0)
          return propagateFloat32NaN(a, b);
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        return float32_default_nan;
      }
      return packFloat32(zSign, (short) 0xFF, 0);
    }
    if (bExp == 0xFF) {
      if (bSig != 0)
        return propagateFloat32NaN(a, b);
      return packFloat32(zSign, (short) 0, 0);
    }
    if (bExp == 0) {
      if (bSig == 0) {
        if ((aExp | aSig) == 0) {
          float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
          return float32_default_nan;
        }
        float_raise(FloatExceptionFlags.float_flag_divbyzero.getValue());
        return packFloat32(zSign, (short) 0xFF, 0);
      }
      List<Number> list = normalizeFloat32Subnormal(bSig);
      bExp = (Short) list.get(0);
      bSig = (Integer) list.get(1);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloat32(zSign, (short) 0, 0);
      List<Number> list = normalizeFloat32Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Integer) list.get(1);
    }
    zExp = (short) (aExp - bExp + 0x7D);
    BigInteger aSigTemp;
    aSigTemp = BigInteger.valueOf((long) (aSig | 0x00800000)); // aSig = (aSig | 0x00800000) << 7;
    aSigTemp = aSigTemp.shiftLeft(7);

    BigInteger bSigTemp;
    bSigTemp = BigInteger.valueOf(bSig | 0x00800000); // bSig = (bSig | 0x00800000) << 8;
    bSigTemp = bSigTemp.shiftLeft(8);

    if (bSigTemp.longValue() <= 2 * (aSigTemp.longValue())) { // if (bSig <= (aSig + aSig))
      aSigTemp = aSigTemp.shiftRight(1); // aSig >>>= 1;
      ++zExp;
    }

    aSigTemp = aSigTemp.shiftLeft(32);
    BigInteger a2SigTemp = aSigTemp;
    aSigTemp = aSigTemp.divide(bSigTemp);
    zSig = aSigTemp.intValue();
    // zSig = (int) ((((long) aSig) << 32) / bSig);
    if ((zSig & 0x3F) == 0) {
      zSig |= (bSigTemp.longValue() * zSig != a2SigTemp.longValue()) ? 1 : 0;
      // zSig |= ((long) bSig * zSig != ((long) aSig) << 32) ? 1 : 0;
    }
    return roundAndPackFloat32(zSign, zExp, zSig);
  }

  /**
   * Returns the remainder of the single-precision floating-point value `a' with respect to the
   * corresponding value `b'. The operation is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return float32
   */

  public static float float32_rem(float a, float b) {
    boolean aSign, zSign; // flag
    // boolean bSign;
    short aExp, bExp, expDiff; // int16
    int aSig, bSig; // bits32
    int q; // bits32
    long aSig64, bSig64, q64; // bits64
    int alternateASig; // bits32
    int sigMean; // sbits32

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);
    bSig = extractFloat32Frac(b);
    bExp = extractFloat32Exp(b);
    // bSign = extractFloat32Sign( b );

    if (aExp == 0xFF) {
      if (aSig != 0 || ((bExp == 0xFF) && bSig != 0)) {
        return propagateFloat32NaN(a, b);
      }
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return float32_default_nan;
    }
    if (bExp == 0xFF) {
      if (bSig != 0)
        return propagateFloat32NaN(a, b);
      return a;
    }
    if (bExp == 0) {
      if (bSig == 0) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        return float32_default_nan;
      }
      List<Number> list = normalizeFloat32Subnormal(bSig);
      bExp = (Short) list.get(0);
      bSig = (Integer) list.get(1);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return a;
      List<Number> list = normalizeFloat32Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Integer) list.get(1);
    }

    expDiff = (short) (aExp - bExp);
    aSig |= 0x00800000;
    bSig |= 0x00800000;

    if (expDiff < 32) {
      aSig <<= 8;
      bSig <<= 8;
      if (expDiff < 0) {
        if (expDiff < -1)
          return a;
        aSig >>>= 1;
      }
      q = (Utils.compareUnsigned(bSig, aSig) || bSig == aSig) ? 1 : 0;

      if (q != 0)
        aSig -= bSig;
      if (0 < expDiff) {
        BigInteger aSigBigInteger = Utils.getUnsignedBigInteger(aSig);
        BigInteger aSigBigIntegerTemp = aSigBigInteger.shiftLeft(32);

        BigInteger bSigBigInteger = Utils.getUnsignedBigInteger(bSig);

        // q = (int) ((((long) aSig) << 32) / bSig);
        BigInteger qBigInteger = aSigBigIntegerTemp.divide(bSigBigInteger);

        // q >>= 32 - expDiff;
        qBigInteger = qBigInteger.shiftRight(32 - expDiff);
        // bSig >>>= 2;

        bSigBigInteger = bSigBigInteger.shiftRight(2);

        aSigBigInteger =
            aSigBigInteger.shiftRight(1).shiftLeft(expDiff - 1)
                .subtract(bSigBigInteger.multiply(qBigInteger));
        // aSig = ((aSig >>> 1) << (expDiff - 1)) - bSig * q;

        q = qBigInteger.intValue();
        aSig = aSigBigInteger.intValue();
        bSig = bSigBigInteger.intValue();
      } else {
        aSig >>>= 2;
        bSig >>>= 2;
      }
    } else {

      // bSig <= aSig
      if (Utils.compareUnsigned(bSig, aSig) || bSig == aSig) {
        aSig -= bSig;
      }

      aSig64 = ((long) aSig) << 40;
      bSig64 = ((long) bSig) << 40;

      expDiff -= 64;
      q64 = 0;
      while (0 < expDiff) {
        q64 = JSoftFloatUtils.estimateDiv128To64(aSig64, 0, bSig64);
        q64 = (Utils.compareUnsigned(2, q64)) ? q64 - 2 : 0;
        aSig64 = -((bSig * q64) << 38);
        expDiff -= 62;
      }
      expDiff += 64;
      q64 = JSoftFloatUtils.estimateDiv128To64(aSig64, 0, bSig64);
      q64 = (Utils.compareUnsigned(2, q64)) ? q64 - 2 : 0;
      q = (int) (q64 >>> (64 - expDiff));

      bSig <<= 6;
      aSig = (int) (((aSig64 >>> 33) << (expDiff - 1)) - bSig * q);
    }

    do {
      alternateASig = aSig;
      ++q;
      aSig -= bSig;
    } while (0 <= (int) aSig);

    sigMean = aSig + alternateASig;

    if ((sigMean < 0) || ((sigMean == 0) && ((q & 1) != 0))) {
      aSig = alternateASig;
    }
    zSign = ((int) aSig < 0);

    if (zSign)
      aSig = -aSig;

    return normalizeRoundAndPackFloat32(aSign ^ zSign, bExp, aSig);
  }

  /**
   * Returns the square root of the single-precision floating-point value `a'. The operation is
   * performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * 
   * @return float32
   */
  public static float float32_sqrt(float a) {
    boolean aSign; // flag
    short aExp, zExp; // int16
    int aSig, zSig; // bits32
    // long rem, term; // bits64

    aSig = extractFloat32Frac(a);
    aExp = extractFloat32Exp(a);
    aSign = extractFloat32Sign(a);

    if (aExp == 0xFF) {
      if (aSig != 0)
        return propagateFloat32NaN(a, 0);
      if (!aSign)
        return a;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return float32_default_nan;
    }
    if (aSign) {
      if ((aExp | aSig) == 0)
        return a;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return float32_default_nan;
    }
    if (aExp == 0) {
      if (aSig == 0)
        return 0;
      List<Number> list = normalizeFloat32Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Integer) list.get(1);
    }

    zExp = (short) (((aExp - 0x7F) >> 1) + 0x7E);
    aSig = (aSig | 0x00800000) << 8;
    zSig = JSoftFloatUtils.estimateSqrt32(aExp, aSig) + 2;

    if ((zSig & 0x7F) <= 5) {
      if (Utils.compareUnsigned(zSig, 2)) {
        zSig = 0x7FFFFFFF;
        // goto roundAndPack;
        return roundAndPackFloat32(false, zExp, zSig);
      }

      BigInteger aSigBigInteger = Utils.getUnsignedBigInteger(aSig);
      // aSig >>>= aExp & 1;
      aSigBigInteger = aSigBigInteger.shiftRight(aExp & 1);
      // term = ((long) zSig) * zSig;
      BigInteger zSigBigInteger = Utils.getUnsignedBigInteger(zSig);
      BigInteger termBigInteger = zSigBigInteger.multiply(zSigBigInteger);

      // rem = (((long) aSig) << 32) - term;
      BigInteger remBigInteger = aSigBigInteger.shiftLeft(32).subtract(termBigInteger);

      // while ((long) rem < 0) {
      while (remBigInteger.longValue() < 0) {
        // --zSig;
        zSigBigInteger = zSigBigInteger.subtract(BigInteger.ONE);
        // rem += (((long) zSig) << 1) | 1;
        BigInteger tempzSig = zSigBigInteger.shiftLeft(1).or(BigInteger.ONE);

        remBigInteger = remBigInteger.add(tempzSig);
      }
      // zSig |= (rem != 0 ? 1 : 0);
      zSigBigInteger =
          zSigBigInteger.or(remBigInteger != BigInteger.ONE ? BigInteger.ONE : BigInteger.ZERO);

      zSig = zSigBigInteger.intValue();
    }
    zSig = JSoftFloatUtils.shift32RightJamming(zSig, (short) 1);//, zSig);
    // roundAndPack:
    return roundAndPackFloat32(false, zExp, zSig);
  }

  /**
   * Returns 1 if the single-precision floating-point value `a' is equal to the corresponding value
   * `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE Standard for Binary
   * Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float32_eq(float a, float b) {
    if (((extractFloat32Exp(a) == 0xFF) && extractFloat32Frac(a) != 0)
        || ((extractFloat32Exp(b) == 0xFF) && extractFloat32Frac(b) != 0)) {
      if (float32_is_signaling_nan(a) || float32_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    return (a == b)
        || ((int) ((Float.floatToRawIntBits(a) | Float.floatToRawIntBits(b)) << 1) == 0);
  }

  /**
   * Returns 1 if the single-precision floating-point value `a' is less than or equal to the
   * corresponding value `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float32_le(float a, float b) {
    boolean aSign, bSign; // flag

    if (((extractFloat32Exp(a) == 0xFF) && extractFloat32Frac(a) != 0)
        || ((extractFloat32Exp(b) == 0xFF) && extractFloat32Frac(b) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    aSign = extractFloat32Sign(a);
    bSign = extractFloat32Sign(b);
    if (aSign != bSign) {
      return aSign || ((int) ((Float.floatToRawIntBits(a) | Float.floatToRawIntBits(b)) << 1) == 0);
    }

    return (a == b) || (aSign ^ (Float.floatToRawIntBits(a) < Float.floatToRawIntBits(b)));
  }

  /**
   * Returns 1 if the single-precision floating-point value `a' is less than the corresponding
   * value `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float32_lt(float a, float b) {
    boolean aSign, bSign; // flag

    if (((extractFloat32Exp(a) == 0xFF) && extractFloat32Frac(a) != 0)
        || ((extractFloat32Exp(b) == 0xFF) && extractFloat32Frac(b) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    aSign = extractFloat32Sign(a);
    bSign = extractFloat32Sign(b);
    if (aSign != bSign)
      return aSign && ((int) ((Float.floatToRawIntBits(a) | Float.floatToRawIntBits(b)) << 1) != 0);
    return (a != b) && (aSign ^ (Float.floatToRawIntBits(a) < Float.floatToRawIntBits(b)));
  }

  /**
   * Returns 1 if the single-precision floating-point value `a' is equal to the corresponding value
   * `b', and 0 otherwise. The invalid exception is raised if either operand is a NaN. Otherwise,
   * the comparison is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float32_eq_signaling(float a, float b) {

    if (((extractFloat32Exp(a) == 0xFF) && extractFloat32Frac(a) != 0)
        || ((extractFloat32Exp(b) == 0xFF) && extractFloat32Frac(b) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    return (a == b)
        || ((int) ((Float.floatToRawIntBits(a) | Float.floatToRawIntBits(b)) << 1) == 0);

  }

  /**
   * Returns 1 if the single-precision floating-point value `a' is less than or equal to the
   * corresponding value `b', and 0 otherwise. Quiet NaNs do not cause an exception. Otherwise, the
   * comparison is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float32_le_quiet(float a, float b) {
    boolean aSign, bSign; // flag
    // short aExp, bExp; // int16

    if (((extractFloat32Exp(a) == 0xFF) && extractFloat32Frac(a) != 0)
        || ((extractFloat32Exp(b) == 0xFF) && extractFloat32Frac(b) != 0)) {
      if (float32_is_signaling_nan(a) || float32_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    aSign = extractFloat32Sign(a);
    bSign = extractFloat32Sign(b);
    if (aSign != bSign)
      return aSign || ((int) ((Float.floatToRawIntBits(a) | Float.floatToRawIntBits(b)) << 1) == 0);
    return (a == b) || (aSign ^ (Float.floatToRawIntBits(a) < Float.floatToRawIntBits(b)));

  }

  /**
   * Returns 1 if the single-precision floating-point value `a' is less than the corresponding value
   * `b', and 0 otherwise. Quiet NaNs do not cause an exception. Otherwise, the comparison is
   * performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the single-precision floating-point value.
   * @param b the single-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float32_lt_quiet(float a, float b) {
    boolean aSign, bSign; // flag

    if (((extractFloat32Exp(a) == 0xFF) && extractFloat32Frac(a) != 0)
        || ((extractFloat32Exp(b) == 0xFF) && extractFloat32Frac(b) != 0)) {
      if (float32_is_signaling_nan(a) || float32_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    aSign = extractFloat32Sign(a);
    bSign = extractFloat32Sign(b);
    if (aSign != bSign)
      return aSign && ((int) ((Float.floatToRawIntBits(a) | Float.floatToRawIntBits(b)) << 1) != 0);
    return (a != b) && (aSign ^ (Float.floatToRawIntBits(a) < Float.floatToRawIntBits(b)));
  }

  /**
   * Returns the result of converting the double-precision floating-point value `a' to the 32-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic---which means in particular that the conversion is rounded
   * according to the current rounding mode. If `a' is a NaN, the largest positive integer is
   * returned. Otherwise, if the conversion overflows, the largest integer with the same sign as `a'
   * is returned.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return int32
   */
  public static int float64_to_int32(double a) {
    boolean aSign; // flag
    short aExp, shiftCount; // int16
    long aSig; // bits64

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    if ((aExp == 0x7FF) && aSig != 0)
      aSign = false;
    if (aExp != 0)
      aSig |= 0x0010000000000000L;
    shiftCount = (short) (0x42C - aExp);
    if (0 < shiftCount)
      aSig = JSoftFloatUtils.shift64RightJamming(aSig, shiftCount);//, aSig);
    return roundAndPackInt32(aSign, aSig);
  }

  /**
   * Returns the result of converting the double-precision floating-point value `a' to the 32-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic, except that the conversion is always rounded toward zero.
   * If `a' is a NaN, the largest positive integer is returned. Otherwise, if the conversion
   * overflows, the largest integer with the same sign as `a' is returned.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return int32
   */
  public static int float64_to_int32_round_to_zero(double a) {
    boolean aSign; // flag
    short aExp, shiftCount; // int16
    long aSig, savedASig; // bits64
    int z; // int32

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    if (0x41E < aExp) {
      if ((aExp == 0x7FF) && aSig != 0)
        aSign = false;
      // goto invalid;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return aSign ? (int) 0x80000000 : 0x7FFFFFFF;
    } else if (aExp < 0x3FF) {
      if ((aExp | aSig) != 0)
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      return 0;
    }
    aSig |= 0x0010000000000000L;
    shiftCount = (short) (0x433 - aExp);
    savedASig = aSig;
    aSig >>>= shiftCount;
    z = (int) aSig;
    if (aSign)
      z = -z;
    if ((z < 0) ^ aSign) {
      // invalid:
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return aSign ? (int) 0x80000000 : 0x7FFFFFFF;
    }
    if ((aSig << shiftCount) != savedASig) {
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    }
    return z;
  }

  /**
   * Returns the result of converting the double-precision floating-point value `a' to the 64-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic---which means in particular that the conversion is rounded
   * according to the current rounding mode. If `a' is a NaN, the largest positive integer is
   * returned. Otherwise, if the conversion overflows, the largest integer with the same sign as `a'
   * is returned.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return int64
   */
  public static long float64_to_int64(double a) {
    boolean aSign; // flag
    short aExp, shiftCount; // int16
    long aSig, aSigExtra = 0; // bits64

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    if (aExp != 0)
      aSig |= 0x0010000000000000L;
    shiftCount = (short) (0x433 - aExp);


    if (shiftCount <= 0) {
      if (0x43E < aExp) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        if (!aSign || ((aExp == 0x7FF) && (aSig != 0x0010000000000000L))) {
          return 0x7FFFFFFFFFFFFFFFL;
        }
        return 0x8000000000000000L;
      }
      aSigExtra = 0;
      aSig <<= -shiftCount;
    } else {
      List<Long> list =
          JSoftFloatUtils.shift64ExtraRightJamming(aSig, 0, shiftCount); //, aSig, aSigExtra);
      aSig = list.get(0);
      aSigExtra = list.get(1);
    }
    return roundAndPackInt64(aSign, aSig, aSigExtra);
  }

  /**
   * Returns the result of converting the double-precision floating-point value `a' to the 64-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic, except that the conversion is always rounded toward zero.
   * If `a' is a NaN, the largest positive integer is returned. Otherwise, if the conversion
   * overflows, the largest integer with the same sign as `a' is returned.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return int64
   */
  public static long float64_to_int64_round_to_zero(double a) {
    boolean aSign; // flag
    short aExp, shiftCount; // int16
    long aSig; // bits64
    long z; // int64

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    if (aExp != 0)
      aSig |= 0x0010000000000000L;
    shiftCount = (short) (aExp - 0x433);
    if (0 <= shiftCount) {
      if (0x43E <= aExp) {
        if (a != 0xC3E0000000000000L) {
          float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
          if (!aSign || ((aExp == 0x7FF) && (aSig != 0x0010000000000000L))) {
            return 0x7FFFFFFFFFFFFFFFL;
          }
        }
        return 0x8000000000000000L;
      }
      z = aSig << shiftCount;
    } else {
      if (aExp < 0x3FE) {
        if ((aExp | aSig) != 0)
          float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
        return 0;
      }
      z = aSig >> (-shiftCount);
      if ((aSig << (shiftCount & 63)) != 0) {
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      }
    }
    if (aSign)
      z = -z;
    return z;
  }

  /**
   * Returns the result of converting the double-precision floating-point value `a' to the
   * single-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return float32
   */
  public static float float64_to_float32(double a) {
    boolean aSign; // flag
    short aExp; // int16
    long aSig; // bits64
    int zSig; // bits32

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    if (aExp == 0x7FF) {
      if (aSig != 0)
        return commonNaNToFloat32(float64ToCommonNaN(a));
      return packFloat32(aSign, (short) 0xFF, 0);
    }
    aSig = JSoftFloatUtils.shift64RightJamming(aSig, (short) 22);//, aSig);
    zSig = (int) aSig;
    if (aExp != 0 || zSig != 0) {
      zSig |= 0x40000000;
      aExp -= 0x381;
    }
    return roundAndPackFloat32(aSign, aExp, zSig);
  }

  /**
   * Returns the result of converting the double-precision floating-point NaN `a' to the canonical
   * NaN format. If `a' is a signaling NaN, the invalid exception is raised.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return commonNaNT
   */
  public static CommonNaNT float64ToCommonNaN(double a) {
    CommonNaNT z = new CommonNaNT();

    if (float64_is_signaling_nan(a))
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
    z.sign = Double.doubleToRawLongBits(a) >>> 63 != 0;
    z.low = 0;
    z.high = Double.doubleToRawLongBits(a) << 12;
    return z;
  }

  /**
   * Returns 1 if the double-precision floating-point value `a' is a signaling NaN; otherwise
   * returns 0.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float64_is_signaling_nan(double a) {
    return (((Double.doubleToRawLongBits(a) >>> 51) & 0xFFF) == 0xFFE)
        && (Double.doubleToRawLongBits(a) & 0x0007FFFFFFFFFFFFL) != 0;
  }

  /**
   * Returns the result of converting the canonical NaN `a' to the single- precision floating-point
   * format.
   * 
   * @param a commonNaNT
   * 
   * @return float32
   */
  public static float commonNaNToFloat32(CommonNaNT a) {
    return Float.intBitsToFloat((int) (((a.sign ? 1 : 0) << 31) | 0x7FC00000 | (a.high >>> 41)));
  }

  /**
   * Returns the result of converting the double-precision floating-point value `a' to the extended
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return floatx80
   */
  public static FloatX80 float64_to_floatx80(double a) {
    boolean aSign; // flag
    short aExp; // int16
    long aSig; // bits64

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    if (aExp == 0x7FF) {
      if (aSig != 0)
        return commonNaNToFloatx80(float64ToCommonNaN(a));
      return packFloatx80(aSign, 0x7FFF, 0x8000000000000000L);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloatx80(aSign, 0, 0);
      List<Number> list = normalizeFloat64Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Long) list.get(1);
    }
    return packFloatx80(aSign, aExp + 0x3C00, (aSig | 0x0010000000000000L) << 11);
  }

  /**
   * Returns the result of converting the double-precision floating-point value `a' to the
   * quadruple-precision floating-point format. The conversion is performed according to the
   * IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return float128
   */

  public static Float128 float64_to_float128(double a) {
    boolean aSign; // flag
    short aExp; // int16
    long aSig, zSig0 = 0, zSig1 = 0; // bits64

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    if (aExp == 0x7FF) {
      if (aSig != 0)
        return commonNaNToFloat128(float64ToCommonNaN(a));
      return packFloat128(aSign, 0x7FFF, 0, 0);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloat128(aSign, 0, 0, 0);
      List<Number> list = normalizeFloat64Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Long) list.get(1);
      --aExp;
    }
    List<Long> list = JSoftFloatUtils.shift128Right(aSig, 0, (short) 4);//, zSig0, zSig1);
    zSig0 = list.get(0);
    zSig1 = list.get(1);
    return packFloat128(aSign, aExp + 0x3C00, zSig0, zSig1);
  }

  /**
   * Rounds the double-precision floating-point value `a' to an integer, and returns the result as a
   * double-precision floating-point value. The operation is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return float64
   */
  public double float64_round_to_int(double a) {
    boolean aSign; // flag
    short aExp; // int16
    long lastBitMask, roundBitsMask; // bits64
    FloatRoundingMode roundingMode; // int8
    double z; // float64

    aExp = extractFloat64Exp(a);
    if (0x433 <= aExp) {
      if ((aExp == 0x7FF) && extractFloat64Frac(a) != 0) {
        return propagateFloat64NaN(a, a);
      }
      return a;
    }
    if (aExp < 0x3FF) {
      if ((long) (Double.doubleToRawLongBits(a) << 1) == 0)
        return a;
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      aSign = extractFloat64Sign(a);
      switch (float_rounding_mode) {
        case float_round_nearest_even:
          if ((aExp == 0x3FE) && extractFloat64Frac(a) != 0) {
            return packFloat64(aSign, (short) 0x3FF, 0);
          }
          break;
        case float_round_down:
          return aSign ? 0xBFF0000000000000L : 0;
        case float_round_up:
          return aSign ? 0x8000000000000000L : 0x3FF0000000000000L;
          // Default
        default:
          break;
      }
      return packFloat64(aSign, (short) 0, 0);
    }
    lastBitMask = 1;
    lastBitMask <<= 0x433 - aExp;
    roundBitsMask = lastBitMask - 1;
    z = a;
    roundingMode = float_rounding_mode;
    if (roundingMode == FloatRoundingMode.float_round_nearest_even) {
      z += lastBitMask >>> 1;
      if ((Double.longBitsToDouble(Double.doubleToRawLongBits(z) & roundBitsMask)) == 0) {
        z = Double.longBitsToDouble(Double.doubleToRawLongBits(z) & ~lastBitMask);
      }
    } else if (roundingMode != FloatRoundingMode.float_round_to_zero) {
      if (extractFloat64Sign(z) ^ (roundingMode == FloatRoundingMode.float_round_up)) {
        z += roundBitsMask;
      }
    }
    z = Double.longBitsToDouble(Double.doubleToRawLongBits(z) & ~roundBitsMask);
    if (z != a)
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    return z;

  }

  /**
   * Takes two double-precision floating-point values `a' and `b', one of which is a NaN, and
   * returns the appropriate NaN result. If either `a' or `b' is a signaling NaN, the invalid
   * exception is raised.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return float64
   */
  public static double propagateFloat64NaN(double a, double b) {
    boolean aIsNaN, aIsSignalingNaN, bIsNaN, bIsSignalingNaN; // flag

    aIsNaN = float64_is_nan(a);
    aIsSignalingNaN = float64_is_signaling_nan(a);
    bIsNaN = float64_is_nan(b);
    bIsSignalingNaN = float64_is_signaling_nan(b);
    a = Double.longBitsToDouble(Double.doubleToRawLongBits(a) | 0x0008000000000000L);
    b = Double.longBitsToDouble(Double.doubleToRawLongBits(b) | 0x0008000000000000L);
    if (aIsSignalingNaN | bIsSignalingNaN)
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
    if (aIsSignalingNaN) {
      if (bIsSignalingNaN) {
        // goto returnLargerSignificand;
        if ((long) (Double.doubleToRawLongBits(a) << 1) < (long) (Double.doubleToRawLongBits(b) << 1))
          return b;
        if ((long) (Double.doubleToRawLongBits(b) << 1) < (long) (Double.doubleToRawLongBits(a) << 1))
          return a;
        return (a < b) ? a : b;
      }
      return bIsNaN ? b : a;
    } else if (aIsNaN) {
      if (bIsSignalingNaN | !bIsNaN)
        return a;
      // returnLargerSignificand:
      if ((long) (Double.doubleToRawLongBits(a) << 1) < (long) (Double.doubleToRawLongBits(b) << 1))
        return b;
      if ((long) (Double.doubleToRawLongBits(b) << 1) < (long) (Double.doubleToRawLongBits(a) << 1))
        return a;
      return (a < b) ? a : b;
    } else {
      return b;
    }
  }

  /**
   * Returns 1 if the double-precision floating-point value `a' is a NaN; otherwise returns 0.
   * 
   * @param a float64
   * 
   * @return flag
   */
  public static boolean float64_is_nan(double a) {
    return Utils.compareUnsigned(0xFFE0000000000000L, (Double.doubleToRawLongBits(a) << 1));
  }

  /**
   * Returns the result of adding the absolute values of the double-precision floating-point values
   * `a' and `b'. If `zSign' is 1, the sum is negated before being returned. `zSign' is ignored if
   * the result is a NaN. The addition is performed according to the IEC/IEEE Standard for Binary
   * Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * @param zSign flag
   * 
   * @return float64
   */
  public static double addFloat64Sigs(double a, double b, boolean zSign) {
    short aExp, bExp, zExp; // int16
    long aSig, bSig, zSig; // bits64
    short expDiff; // int16

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    bSig = extractFloat64Frac(b);
    bExp = extractFloat64Exp(b);
    expDiff = (short) (aExp - bExp);
    aSig <<= 9;
    bSig <<= 9;
    if (0 < expDiff) {
      if (aExp == 0x7FF) {
        if (aSig != 0)
          return propagateFloat64NaN(a, b);
        return a;
      }
      if (bExp == 0) {
        --expDiff;
      } else {
        bSig |= 0x2000000000000000L;
      }
      bSig = JSoftFloatUtils.shift64RightJamming(bSig, expDiff);//, bSig);
      zExp = aExp;
    } else if (expDiff < 0) {
      if (bExp == 0x7FF) {
        if (bSig != 0)
          return propagateFloat64NaN(a, b);
        return packFloat64(zSign, (short) 0x7FF, 0);
      }
      if (aExp == 0) {
        ++expDiff;
      } else {
        aSig |= 0x2000000000000000L;
      }
      aSig = JSoftFloatUtils.shift64RightJamming(aSig, (short) -expDiff);//, aSig);
      zExp = bExp;
    } else {
      if (aExp == 0x7FF) {
        if ((aSig | bSig) != 0)
          return propagateFloat64NaN(a, b);
        return a;
      }
      if (aExp == 0)
        return packFloat64(zSign, (short) 0, (aSig + bSig) >>> 9);
      zSig = 0x4000000000000000L + aSig + bSig;
      zExp = aExp;
      // goto roundAndPack;
      return roundAndPackFloat64(zSign, zExp, zSig);
    }
    aSig |= 0x2000000000000000L;
    zSig = (aSig + bSig) << 1;
    --zExp;
    if ((long) zSig < 0) {
      zSig = aSig + bSig;
      ++zExp;
    }
    // roundAndPack:
    return roundAndPackFloat64(zSign, zExp, zSig);
  }

  /**
   * Returns the result of subtracting the absolute values of the double- precision floating-point
   * values `a' and `b'. If `zSign' is 1, the difference is negated before being returned. `zSign'
   * is ignored if the result is a NaN. The subtraction is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * @param zSign flag
   * 
   * @return float64
   */
  public static double subFloat64Sigs(double a, double b, boolean zSign) {
    short aExp, bExp, zExp; // int16
    long aSig, bSig, zSig; // bits64
    short expDiff; // int16

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    bSig = extractFloat64Frac(b);
    bExp = extractFloat64Exp(b);
    expDiff = (short) (aExp - bExp);
    aSig <<= 10;
    bSig <<= 10;
    if (0 < expDiff) {
      // goto aExpBigger;
      if (aExp == 0x7FF) {
        if (aSig != 0)
          return propagateFloat64NaN(a, b);
        return a;
      }
      if (bExp == 0) {
        --expDiff;
      } else {
        bSig |= 0x4000000000000000L;
      }
      bSig = JSoftFloatUtils.shift64RightJamming(bSig, expDiff);//, bSig);
      aSig |= 0x4000000000000000L;
      zSig = aSig - bSig;
      zExp = aExp;
      --zExp;
      return normalizeRoundAndPackFloat64(zSign, zExp, zSig);

    }
    if (expDiff < 0) {
      // goto bExpBigger;
      if (bExp == 0x7FF) {
        if (bSig != 0)
          return propagateFloat64NaN(a, b);
        return packFloat64(((zSign ? 1 : 0) ^ 1) != 0, (short) 0x7FF, 0);
      }
      if (aExp == 0) {
        ++expDiff;
      } else {
        aSig |= 0x4000000000000000L;
      }
      aSig = JSoftFloatUtils.shift64RightJamming(aSig, (short) -expDiff);//, aSig);
      bSig |= 0x4000000000000000L;
      zSig = bSig - aSig;
      zExp = bExp;
      zSign = ((zSign ? 1 : 0) ^ 1) != 0;// ^= 1;
      --zExp;
      return normalizeRoundAndPackFloat64(zSign, zExp, zSig);
    }
    if (aExp == 0x7FF) {
      if ((aSig | bSig) != 0)
        return propagateFloat64NaN(a, b);
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return float64_default_nan;
    }
    if (aExp == 0) {
      aExp = 1;
      bExp = 1;
    }
    if (bSig < aSig) {
      // goto aBigger;
      zSig = aSig - bSig;
      zExp = aExp;
      --zExp;
      return normalizeRoundAndPackFloat64(zSign, zExp, zSig);
    }
    if (aSig < bSig) {
      // goto bBigger;
      zSig = bSig - aSig;
      zExp = bExp;
      zSign = ((zSign ? 1 : 0) ^ 1) != 0;// ^= 1;
      --zExp;
      return normalizeRoundAndPackFloat64(zSign, zExp, zSig);
    }
    return packFloat64(float_rounding_mode == FloatRoundingMode.float_round_down, (short) 0, 0);
  }

  /**
   * Returns the result of adding the double-precision floating-point values `a' and `b'. The
   * operation is performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return float64
   */
  public static double float64_add(double a, double b) {
    boolean aSign, bSign; // flag

    aSign = extractFloat64Sign(a);
    bSign = extractFloat64Sign(b);
    if (aSign == bSign) {
      return addFloat64Sigs(a, b, aSign);
    } else {
      return subFloat64Sigs(a, b, aSign);
    }
  }

  /**
   * Returns the result of subtracting the double-precision floating-point values `a' and `b'. The
   * operation is performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return float64
   */
  public static double float64_sub(double a, double b) {
    boolean aSign, bSign; // flag

    aSign = extractFloat64Sign(a);
    bSign = extractFloat64Sign(b);
    if (aSign == bSign) {
      return subFloat64Sigs(a, b, aSign);
    } else {
      return addFloat64Sigs(a, b, aSign);
    }
  }

  /**
   * Returns the result of multiplying the double-precision floating-point values `a' and `b'. The
   * operation is performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return float64
   */
  public static double float64_mul(double a, double b) {
    boolean aSign, bSign, zSign; // flag
    short aExp, bExp, zExp; // int16
    long aSig, bSig, zSig0 = 0, zSig1 = 0; // bits64

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    bSig = extractFloat64Frac(b);
    bExp = extractFloat64Exp(b);
    bSign = extractFloat64Sign(b);
    zSign = aSign ^ bSign;

    if (aExp == 0x7FF) {
      if (aSig != 0 || ((bExp == 0x7FF) && bSig != 0)) {
        return propagateFloat64NaN(a, b);
      }
      if ((bExp | bSig) == 0) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        return float64_default_nan;
      }
      return packFloat64(zSign, (short) 0x7FF, 0);
    }
    if (bExp == 0x7FF) {
      if (bSig != 0)
        return propagateFloat64NaN(a, b);
      if ((aExp | aSig) == 0) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        return float64_default_nan;
      }
      return packFloat64(zSign, (short) 0x7FF, 0);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloat64(zSign, (short) 0, 0);
      List<Number> list = normalizeFloat64Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Long) list.get(1);
    }
    if (bExp == 0) {
      if (bSig == 0)
        return packFloat64(zSign, (short) 0, 0);
      List<Number> list = normalizeFloat64Subnormal(bSig);
      bExp = (Short) list.get(0);
      bSig = (Long) list.get(1);
    }

    zExp = (short) (aExp + bExp - 0x3FF);
    aSig = (aSig | 0x0010000000000000L) << 10;
    bSig = (bSig | 0x0010000000000000L) << 11;
    List<Long> list = JSoftFloatUtils.mul64To128(aSig, bSig);// , zSig0, zSig1);

    zSig0 = list.get(0);
    zSig1 = list.get(1);
    zSig0 |= (zSig1 != 0) ? 1 : 0;
    if (0 <= (long) (zSig0 << 1)) {
      zSig0 <<= 1;
      --zExp;
    }

    return roundAndPackFloat64(zSign, zExp, zSig0);
  }

  /**
   * Returns the result of dividing the double-precision floating-point value `a' by the
   * corresponding value `b'. The operation is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return float64
   */
  public static double float64_div(double a, double b) {
    boolean aSign, bSign, zSign; // flag
    short aExp, bExp, zExp; // int16
    long aSig, bSig, zSig; // bits64
    long rem0 = 0, rem1 = 0; // bits64
    long term0 = 0, term1 = 0; // bits64

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    bSig = extractFloat64Frac(b);
    bExp = extractFloat64Exp(b);
    bSign = extractFloat64Sign(b);
    zSign = aSign ^ bSign;

    if (aExp == 0x7FF) {
      if (aSig != 0)
        return propagateFloat64NaN(a, b);
      if (bExp == 0x7FF) {
        if (bSig != 0)
          return propagateFloat64NaN(a, b);
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        return float64_default_nan;
      }
      return packFloat64(zSign, (short) 0x7FF, 0);
    }
    if (bExp == 0x7FF) {
      if (bSig != 0)
        return propagateFloat64NaN(a, b);
      return packFloat64(zSign, (short) 0, 0);
    }
    if (bExp == 0) {
      if (bSig == 0) {
        if ((aExp | aSig) == 0) {
          float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
          return float64_default_nan;
        }
        float_raise(FloatExceptionFlags.float_flag_divbyzero.getValue());
        return packFloat64(zSign, (short) 0x7FF, 0);
      }
      List<Number> list = normalizeFloat64Subnormal(bSig);
      bExp = (Short) list.get(0);
      bSig = (Long) list.get(1);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloat64(zSign, (short) 0, 0);
      List<Number> list = normalizeFloat64Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Long) list.get(1);
    }

    zExp = (short) (aExp - bExp + 0x3FD);

    aSig = (aSig | 0x0010000000000000L) << 10;
    bSig = (bSig | 0x0010000000000000L) << 11;
    if (bSig <= (aSig + aSig)) {
      aSig >>>= 1;
      ++zExp;
    }

    zSig = JSoftFloatUtils.estimateDiv128To64(aSig, 0, bSig);

    if ((zSig & 0x1FF) <= 2) {
      List<Long> list = JSoftFloatUtils.mul64To128(bSig, zSig);// , term0, term1);
      term0 = list.get(0);
      term1 = list.get(1);
      List<Long> list2 = JSoftFloatUtils.sub128(aSig, 0, term0, term1);// , rem0, rem1);
      rem0 = list2.get(0);
      rem1 = list2.get(1);

      // (sbits64) rem0 < 0
      while (rem0 < 0) {
        --zSig;
        List<Long> list3 = JSoftFloatUtils.add128(rem0, rem1, 0, bSig); // , rem0, rem1);
        rem0 = list3.get(0);
        rem1 = list3.get(1);
      }
      zSig |= (rem1 != 0) ? 1 : 0;
    }

    return roundAndPackFloat64(zSign, zExp, zSig);
  }

  /**
   * Returns the remainder of the double-precision floating-point value `a' with respect to the
   * corresponding value `b'. The operation is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return float64
   */
  public static double float64_rem(double a, double b) {
    boolean aSign, zSign; // flag
    // boolean bSign
    short aExp, bExp, expDiff; // int16
    long aSig, bSig; // bits64
    long q, alternateASig; // bits64
    long sigMean; // sbits64

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);
    bSig = extractFloat64Frac(b);
    bExp = extractFloat64Exp(b);
    // bSign = extractFloat64Sign( b );

    if (aExp == 0x7FF) {
      if (aSig != 0 || ((bExp == 0x7FF) && bSig != 0)) {
        return propagateFloat64NaN(a, b);
      }
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return float64_default_nan;
    }
    if (bExp == 0x7FF) {
      if (bSig != 0)
        return propagateFloat64NaN(a, b);
      return a;
    }
    if (bExp == 0) {
      if (bSig == 0) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        return float64_default_nan;
      }
      List<Number> list = normalizeFloat64Subnormal(bSig);
      bExp = (Short) list.get(0);
      bSig = (Long) list.get(1);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return a;
      List<Number> list = normalizeFloat64Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Long) list.get(1);
    }

    expDiff = (short) (aExp - bExp);
    aSig = (aSig | 0x0010000000000000L) << 11;
    bSig = (bSig | 0x0010000000000000L) << 11;
    if (expDiff < 0) {
      if (expDiff < -1)
        return a;
      aSig >>>= 1;
    }

    q = ((Utils.compareUnsigned(bSig, aSig) || bSig == aSig) ? 1 : 0);

    if (q != 0)
      aSig -= bSig;

    expDiff -= 64;
    while (0 < expDiff) {
      q = JSoftFloatUtils.estimateDiv128To64(aSig, 0, bSig);
      q = (Utils.compareUnsigned(2, q)) ? q - 2 : 0;
      aSig = -((bSig >>> 2) * q);
      expDiff -= 62;
    }

    expDiff += 64;
    if (0 < expDiff) {
      q = JSoftFloatUtils.estimateDiv128To64(aSig, 0, bSig);
      q = (Utils.compareUnsigned(2, q)) ? q - 2 : 0;
      q >>>= 64 - expDiff;
      bSig >>>= 2;
      aSig = ((aSig >>> 1) << (expDiff - 1)) - bSig * q;
    } else {
      aSig >>>= 2;
      bSig >>>= 2;
    }
    do {
      alternateASig = aSig;
      ++q;
      aSig -= bSig;
    } while (0 <= (long) aSig);
    sigMean = aSig + alternateASig;
    if ((sigMean < 0) || ((sigMean == 0) && ((q & 1) != 0))) {
      aSig = alternateASig;
    }
    zSign = ((long) aSig < 0);
    if (zSign)
      aSig = -aSig;

    return normalizeRoundAndPackFloat64(aSign ^ zSign, bExp, aSig);
  }

  /**
   * Returns the square root of the double-precision floating-point value `a'. The operation is
   * performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * 
   * @return float64
   */
  public static double float64_sqrt(double a) {
    boolean aSign; // flag
    short aExp, zExp; // int16
    long aSig, zSig, doubleZSig; // bits64
    long rem0 = 0, rem1 = 0, term0 = 0, term1 = 0; // bits64
    // double z; // float64

    aSig = extractFloat64Frac(a);
    aExp = extractFloat64Exp(a);
    aSign = extractFloat64Sign(a);

    if (aExp == 0x7FF) {
      if (aSig != 0)
        return propagateFloat64NaN(a, a);
      if (!aSign)
        return a;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return float64_default_nan;
    }
    if (aSign) {
      if ((aExp | aSig) == 0)
        return a;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return float64_default_nan;
    }
    if (aExp == 0) {
      if (aSig == 0)
        return 0;
      List<Number> list = normalizeFloat64Subnormal(aSig);
      aExp = (Short) list.get(0);
      aSig = (Long) list.get(1);
    }

    zExp = (short) (((aExp - 0x3FF) >> 1) + 0x3FE);
    aSig |= 0x0010000000000000L;
    zSig = 0xffffFFFFL & JSoftFloatUtils.estimateSqrt32(aExp, (int) (aSig >>> 21));
    aSig <<= 9 - (aExp & 1);
    zSig = JSoftFloatUtils.estimateDiv128To64(aSig, 0, zSig << 32) + (zSig << 30);

    if ((zSig & 0x1FF) <= 5) {
      doubleZSig = zSig << 1;
      List<Long> list = JSoftFloatUtils.mul64To128(zSig, zSig);// , term0, term1);
      term0 = list.get(0);
      term1 = list.get(1);
      List<Long> list2 = JSoftFloatUtils.sub128(aSig, 0, term0, term1);// , rem0, rem1);
      rem0 = list2.get(0);
      rem1 = list2.get(1);
      while ((long) rem0 < 0) {
        --zSig;
        doubleZSig -= 2;
        List<Long> list3 = JSoftFloatUtils.add128(rem0, rem1, zSig >>> 63, doubleZSig | 1);
        rem0 = list3.get(0);
        rem1 = list3.get(1);
      }
      zSig |= ((rem0 | rem1) != 0 ? 1 : 0);
    }
    return roundAndPackFloat64(false, zExp, zSig);
  }

  /**
   * Returns 1 if the double-precision floating-point value `a' is equal to the corresponding value
   * `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE Standard for Binary
   * Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float64_eq(double a, double b) {
    if (((extractFloat64Exp(a) == 0x7FF) && extractFloat64Frac(a) != 0)
        || ((extractFloat64Exp(b) == 0x7FF) && extractFloat64Frac(b) != 0)) {
      if (float64_is_signaling_nan(a) || float64_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    return (a == b)
        || (((Double.doubleToRawLongBits(a) | Double.doubleToRawLongBits(b)) << 1) == 0);
  }

  /**
   * Returns 1 if the double-precision floating-point value `a' is less than or equal to the
   * corresponding value `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float64_le(double a, double b) {
    boolean aSign, bSign; // flag

    if (((extractFloat64Exp(a) == 0x7FF) && extractFloat64Frac(a) != 0)
        || ((extractFloat64Exp(b) == 0x7FF) && extractFloat64Frac(b) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    aSign = extractFloat64Sign(a);
    bSign = extractFloat64Sign(b);
    if (aSign != bSign)
      return aSign || ((Double.doubleToRawLongBits(a) | Double.doubleToRawLongBits(b)) << 1) == 0;

    return (a == b)
        || (aSign ^ Utils.compareUnsigned(Double.doubleToLongBits(a), Double.doubleToLongBits(b)));
  }

  /**
   * Returns 1 if the double-precision floating-point value `a' is less than the corresponding value
   * `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE Standard for Binary
   * Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float64_lt(double a, double b) {
    boolean aSign, bSign; // flag

    if (((extractFloat64Exp(a) == 0x7FF) && extractFloat64Frac(a) != 0)
        || ((extractFloat64Exp(b) == 0x7FF) && extractFloat64Frac(b) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    aSign = extractFloat64Sign(a);
    bSign = extractFloat64Sign(b);
    if (aSign != bSign)
      return aSign
          && ((long) ((Double.doubleToRawLongBits(a) | Double.doubleToRawLongBits(b)) << 1) != 0);
    return (a != b)
        && (aSign ^ Utils.compareUnsigned(Double.doubleToLongBits(a), Double.doubleToLongBits(b)));
  }

  /**
   * Returns 1 if the double-precision floating-point value `a' is equal to the corresponding value
   * `b', and 0 otherwise. The invalid exception is raised if either operand is a NaN. Otherwise,
   * the comparison is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float64_eq_signaling(double a, double b) {
    if (((extractFloat64Exp(a) == 0x7FF) && extractFloat64Frac(a) != 0)
        || ((extractFloat64Exp(b) == 0x7FF) && extractFloat64Frac(b) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    return (a == b)
        || ((long) ((Double.doubleToRawLongBits(a) | Double.doubleToRawLongBits(b)) << 1) == 0);
  }

  /**
   * Returns 1 if the double-precision floating-point value `a' is less than or equal to the
   * corresponding value `b', and 0 otherwise. Quiet NaNs do not cause an exception. Otherwise, the
   * comparison is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float64_le_quiet(double a, double b) {
    boolean aSign, bSign; // flag
    // short aExp, bExp; // int16

    if (((extractFloat64Exp(a) == 0x7FF) && extractFloat64Frac(a) != 0)
        || ((extractFloat64Exp(b) == 0x7FF) && extractFloat64Frac(b) != 0)) {
      if (float64_is_signaling_nan(a) || float64_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    aSign = extractFloat64Sign(a);
    bSign = extractFloat64Sign(b);
    if (aSign != bSign)
      return aSign
          || ((long) ((Double.doubleToRawLongBits(a) | Double.doubleToRawLongBits(b)) << 1) == 0);
    return (a == b)
        || (aSign ^ Utils.compareUnsigned(Double.doubleToLongBits(a), Double.doubleToLongBits(b)));
  }

  /**
   * Returns 1 if the double-precision floating-point value `a' is less than the corresponding value
   * `b', and 0 otherwise. Quiet NaNs do not cause an exception. Otherwise, the comparison is
   * performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the double-precision floating-point value.
   * @param b the double-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean float64_lt_quiet(double a, double b) {
    boolean aSign, bSign; // flag

    if (((extractFloat64Exp(a) == 0x7FF) && extractFloat64Frac(a) != 0)
        || ((extractFloat64Exp(b) == 0x7FF) && extractFloat64Frac(b) != 0)) {
      if (float64_is_signaling_nan(a) || float64_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    aSign = extractFloat64Sign(a);
    bSign = extractFloat64Sign(b);
    if (aSign != bSign)
      return aSign
          && ((long) ((Double.doubleToRawLongBits(a) | Double.doubleToRawLongBits(b)) << 1) != 0);
    return (a != b)
        && (aSign ^ Utils.compareUnsigned(Double.doubleToLongBits(a), Double.doubleToLongBits(b)));
  }

  /**
   * Returns the result of converting the extended double-precision floating- point value `a' to the
   * 32-bit two's complement integer format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic---which means in particular that the conversion
   * is rounded according to the current rounding mode. If `a' is a NaN, the largest positive
   * integer is returned. Otherwise, if the conversion overflows, the largest integer with the same
   * sign as `a' is returned.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return int32
   */
  public static int floatx80_to_int32(FloatX80 a) {
    boolean aSign; // flag
    int aExp, shiftCount; // int32
    long aSig; // bits64

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);

    if ((aExp == 0x7FFF) && (long) (aSig << 1) != 0)
      aSign = false;
    shiftCount = 0x4037 - aExp;
    if (shiftCount <= 0)
      shiftCount = 1;
    aSig = JSoftFloatUtils.shift64RightJamming(aSig, (short) shiftCount);//, aSig);

    return roundAndPackInt32(aSign, aSig);
  }

  /**
   * Returns the result of converting the extended double-precision floating- point value `a' to the
   * 32-bit two's complement integer format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic, except that the conversion is always rounded
   * toward zero. If `a' is a NaN, the largest positive integer is returned. Otherwise, if the
   * conversion overflows, the largest integer with the same sign as `a' is returned.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return the result of converting the extended double-precision floating- point value to the
   *         32-bit two's complement integer format.
   */
  public static int floatx80_to_int32_round_to_zero(FloatX80 a) {
    boolean aSign; // flag
    int aExp, shiftCount; // int32
    long aSig, savedASig; // bits64
    int z; // int32

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);
    if (0x401E < aExp) {
      if ((aExp == 0x7FFF) && (long) (aSig << 1) != 0)
        aSign = false;
      // goto invalid;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return aSign ? (int) 0x80000000 : 0x7FFFFFFF;
    } else if (aExp < 0x3FFF) {
      if (aExp != 0 || aSig != 0)
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      return 0;
    }
    shiftCount = 0x403E - aExp;
    savedASig = aSig;
    aSig >>>= shiftCount;
    z = (int) aSig;
    if (aSign)
      z = -z;
    if ((z < 0) ^ aSign) {
      // invalid:
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return aSign ? (int) 0x80000000 : 0x7FFFFFFF;
    }
    if ((aSig << shiftCount) != savedASig) {
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    }
    return z;
  }

  /**
   * Returns the result of converting the extended double-precision floating- point value `a' to the
   * 64-bit two's complement integer format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic---which means in particular that the conversion
   * is rounded according to the current rounding mode. If `a' is a NaN, the largest positive
   * integer is returned. Otherwise, if the conversion overflows, the largest integer with the same
   * sign as `a' is returned.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return int64
   */
  public static long floatx80_to_int64(FloatX80 a) {
    boolean aSign; // flag
    int aExp, shiftCount; // int32
    long aSig, aSigExtra = 0; // bits64

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);
    shiftCount = 0x403E - aExp;
    if (shiftCount <= 0) {
      if (shiftCount != 0) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        if (!aSign || ((aExp == 0x7FFF) && (aSig != 0x8000000000000000L))) {
          return 0x7FFFFFFFFFFFFFFFL;
        }
        return 0x8000000000000000L;
      }
      aSigExtra = 0;
    } else {
      List<Long> list =
          JSoftFloatUtils.shift64ExtraRightJamming(aSig, 0, shiftCount); //, aSig, aSigExtra);
      aSig = list.get(0);
      aSigExtra = list.get(1);
    }
    return roundAndPackInt64(aSign, aSig, aSigExtra);
  }

  /**
   * Returns the result of converting the extended double-precision floating- point value `a' to the
   * 64-bit two's complement integer format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic, except that the conversion is always rounded
   * toward zero. If `a' is a NaN, the largest positive integer is returned. Otherwise, if the
   * conversion overflows, the largest integer with the same sign as `a' is returned.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return int64
   */
  public static long floatx80_to_int64_round_to_zero(FloatX80 a) {
    boolean aSign; // flag
    int aExp, shiftCount; // int32
    long aSig; // bits64
    long z; // int64

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);
    shiftCount = aExp - 0x403E;
    if (0 <= shiftCount) {
      aSig &= 0x7FFFFFFFFFFFFFFFL;
      if ((a.high != 0xC03E) || aSig != 0) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        if (!aSign || ((aExp == 0x7FFF) && aSig != 0)) {
          return 0x7FFFFFFFFFFFFFFFL;
        }
      }
      return 0x8000000000000000L;
    } else if (aExp < 0x3FFF) {
      if ((aExp | aSig) != 0)
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      return 0;
    }
    z = aSig >>> (-shiftCount);
    if ((aSig << (shiftCount & 63)) != 0) {
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    }
    if (aSign)
      z = -z;
    return z;
  }

  /**
   * Returns the result of converting the extended double-precision floating- point value `a' to the
   * single-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return float32
   */
  public static float floatx80_to_float32(FloatX80 a) {
    boolean aSign; // flag
    int aExp; // int32
    long aSig; // bits64

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);
    if (aExp == 0x7FFF) {
      if ((aSig << 1) != 0) {
        return commonNaNToFloat32(floatx80ToCommonNaN(a));
      }
      return packFloat32(aSign, (short) 0xFF, 0);
    }
    aSig = JSoftFloatUtils.shift64RightJamming(aSig, (short) 33);//, aSig);
    if (aExp != 0 || aSig != 0)
      aExp -= 0x3F81;
    return roundAndPackFloat32(aSign, (short) aExp, (int) aSig);
  }

  /**
   * Returns the result of converting the extended double-precision floating- point NaN `a' to the
   * canonical NaN format. If `a' is a signaling NaN, the invalid exception is raised.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return commonNaNT
   */
  public static CommonNaNT floatx80ToCommonNaN(FloatX80 a) {
    CommonNaNT z = new CommonNaNT();

    if (floatx80_is_signaling_nan(a))
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
    z.sign = (a.high >>> 15 != 0);
    z.low = 0;
    z.high = a.low << 1;
    return z;
  }

  /**
   * Returns 1 if the extended double-precision floating-point value `a' is a signaling NaN;
   * otherwise returns 0.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean floatx80_is_signaling_nan(FloatX80 a) {
    long aLow; // bits64

    aLow = a.low & ~0x4000000000000000L;
    return ((a.high & 0x7FFF) == 0x7FFF) && (aLow << 1 != 0) && (a.low == aLow);
  }

  /**
   * Returns the result of converting the extended double-precision floating- point value `a' to the
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return float64
   */
  public static double floatx80_to_float64(FloatX80 a) {
    boolean aSign; // flag
    int aExp; // int32
    long aSig, zSig = 0; // bits64

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);
    if (aExp == 0x7FFF) {
      if ((aSig << 1) != 0) {
        return commonNaNToFloat64(floatx80ToCommonNaN(a));
      }
      return packFloat64(aSign, (short) 0x7FF, 0);
    }
    zSig = JSoftFloatUtils.shift64RightJamming(aSig, (short) 1);//, zSig);
    if (aExp != 0 || aSig != 0)
      aExp -= 0x3C01;
    return roundAndPackFloat64(aSign, (short) aExp, zSig);
  }

  /**
   * Returns the result of converting the extended double-precision floating- point value `a' to the
   * quadruple-precision floating-point format. The conversion is performed according to the
   * IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return float128
   */
  public static Float128 floatx80_to_float128(FloatX80 a) {
    boolean aSign; // flag
    short aExp; // int16
    long aSig, zSig0 = 0, zSig1 = 0; // bits64

    aSig = extractFloatx80Frac(a);
    aExp = (short) extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);
    if ((aExp == 0x7FFF) && (aSig << 1 != 0)) {
      return commonNaNToFloat128(floatx80ToCommonNaN(a));
    }
    List<Long> list = JSoftFloatUtils.shift128Right(aSig << 1, 0, (short) 16);//, zSig0, zSig1);
    zSig0 = list.get(0);
    zSig1 = list.get(1);
    return packFloat128(aSign, aExp, zSig0, zSig1);
  }

  /**
   * Rounds the extended double-precision floating-point value `a' to an integer, and returns the
   * result as an extended quadruple-precision floating-point value. The operation is performed
   * according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return floatx80
   */
  public static FloatX80 floatx80_round_to_int(FloatX80 a) {
    boolean aSign; // flag
    int aExp; // int32
    long lastBitMask, roundBitsMask; // bits64
    FloatRoundingMode roundingMode; // int8
    FloatX80 z; // floatx80

    aExp = extractFloatx80Exp(a);
    if (0x403E <= aExp) {
      if ((aExp == 0x7FFF) && (extractFloatx80Frac(a) << 1 != 0)) {
        return propagateFloatx80NaN(a, a);
      }
      return a;
    }
    if (aExp < 0x3FFF) {
      if ((aExp == 0) && ((extractFloatx80Frac(a) << 1) == 0)) {
        return a;
      }
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      aSign = extractFloatx80Sign(a);
      switch (float_rounding_mode) {
        case float_round_nearest_even:
          if ((aExp == 0x3FFE) && (extractFloatx80Frac(a) << 1 != 0)) {
            return packFloatx80(aSign, 0x3FFF, 0x8000000000000000L);
          }
          break;
        case float_round_down:
          return aSign ? packFloatx80(true, 0x3FFF, 0x8000000000000000L)
              : packFloatx80(false, 0, 0);
        case float_round_up:
          return aSign ? packFloatx80(true, 0, 0)
              : packFloatx80(false, 0x3FFF, 0x8000000000000000L);
        default:
          break;
      }
      return packFloatx80(aSign, 0, 0);
    }
    lastBitMask = 1;
    lastBitMask <<= 0x403E - aExp;
    roundBitsMask = lastBitMask - 1;
    z = a;
    roundingMode = float_rounding_mode;
    if (roundingMode == FloatRoundingMode.float_round_nearest_even) {
      z.low += lastBitMask >>> 1;
      if ((z.low & roundBitsMask) == 0)
        z.low &= ~lastBitMask;
    } else if (roundingMode != FloatRoundingMode.float_round_to_zero) {
      if (extractFloatx80Sign(z) ^ (roundingMode == FloatRoundingMode.float_round_up)) {
        z.low += roundBitsMask;
      }
    }
    z.low &= ~roundBitsMask;
    if (z.low == 0) {
      ++z.high;
      z.low = 0x8000000000000000L;
    }
    if (z.low != a.low)
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    return z;
  }

  /**
   * Takes two extended double-precision floating-point values `a' and `b', one of which is a NaN,
   * and returns the appropriate NaN result. If either `a' or `b' is a signaling NaN, the invalid
   * exception is raised.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return floatx80
   */
  public static FloatX80 propagateFloatx80NaN(FloatX80 a, FloatX80 b) {
    boolean aIsNaN, aIsSignalingNaN, bIsNaN, bIsSignalingNaN; // flag

    aIsNaN = floatx80_is_nan(a);
    aIsSignalingNaN = floatx80_is_signaling_nan(a);
    bIsNaN = floatx80_is_nan(b);
    bIsSignalingNaN = floatx80_is_signaling_nan(b);
    a.low |= 0xC000000000000000L;
    b.low |= 0xC000000000000000L;
    if (aIsSignalingNaN | bIsSignalingNaN)
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
    if (aIsSignalingNaN) {
      if (bIsSignalingNaN) {
        // goto returnLargerSignificand;
        if (a.low < b.low)
          return b;
        if (b.low < a.low)
          return a;
        return (a.high < b.high) ? a : b;
      }
      return bIsNaN ? b : a;
    } else if (aIsNaN) {
      if (bIsSignalingNaN | !bIsNaN)
        return a;
      // returnLargerSignificand:
      if (a.low < b.low)
        return b;
      if (b.low < a.low)
        return a;
      return (a.high < b.high) ? a : b;
    } else {
      return b;
    }

  }

  /**
   * Returns 1 if the extended double-precision floating-point value `a' is a NaN; otherwise returns
   * 0.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return flag
   */
  public static boolean floatx80_is_nan(final FloatX80 a) {
    return ((a.high & 0x7FFF) == 0x7FFF) && (a.low << 1) != 0;
  }

  /**
   * Returns the result of adding the absolute values of the extended double- precision
   * floating-point values `a' and `b'. If `zSign' is 1, the sum is negated before being returned.
   * `zSign' is ignored if the result is a NaN. The addition is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * @param zSign flag
   * 
   * @return floatx80
   */
  public static FloatX80 addFloatx80Sigs(FloatX80 a, FloatX80 b, boolean zSign) {
    int aExp, bExp, zExp = 0; // int32
    long aSig, bSig, zSig0, zSig1 = 0; // bits64
    int expDiff; // int32

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    bSig = extractFloatx80Frac(b);
    bExp = extractFloatx80Exp(b);

    expDiff = aExp - bExp;
    if (0 < expDiff) {
      if (aExp == 0x7FFF) {
        if (aSig << 1 != 0)
          return propagateFloatx80NaN(a, b);
        return a;
      }
      if (bExp == 0)
        --expDiff;
      List<Long> list = JSoftFloatUtils.shift64ExtraRightJamming(bSig, 0, expDiff); //, bSig, zSig1);
      bSig = list.get(0);
      zSig1 = list.get(1);

      zExp = aExp;
    } else if (expDiff < 0) {
      if (bExp == 0x7FFF) {
        if (bSig << 1 != 0)
          return propagateFloatx80NaN(a, b);
        return packFloatx80(zSign, 0x7FFF, 0x8000000000000000L);
      }
      if (aExp == 0)
        ++expDiff;
      List<Long> list = JSoftFloatUtils.shift64ExtraRightJamming(aSig, 0, -expDiff); //, aSig, zSig1);
      aSig = list.get(0);
      zSig1 = list.get(1);
      zExp = bExp;
    } else {
      if (aExp == 0x7FFF) {
        if ((aSig | bSig) << 1 != 0) {
          return propagateFloatx80NaN(a, b);
        }
        return a;
      }
      zSig1 = 0;
      zSig0 = aSig + bSig;

      if (aExp == 0) {
        List<Number> list = normalizeFloatx80Subnormal(zSig0); // , zExp, zSig0
        zExp = (Integer) list.get(0);
        zSig0 = (Long) list.get(1);
        // goto roundAndPack;

        return roundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);
      }
      zExp = aExp;
      // goto shiftRight1;
      List<Long> list = JSoftFloatUtils.shift64ExtraRightJamming(zSig0, zSig1, 1); //, zSig0, zSig1);
      zSig0 = list.get(0);
      zSig1 = list.get(1);

      zSig0 |= 0x8000000000000000L;
      ++zExp;
      return roundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);
    }
    zSig0 = aSig + bSig;
    if (zSig0 < 0) {
      // goto roundAndPack;
      return roundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);
    }
    // shiftRight1:
    List<Long> list = JSoftFloatUtils.shift64ExtraRightJamming(zSig0, zSig1, 1); //, zSig0, zSig1);
    zSig0 = list.get(0);
    zSig1 = list.get(1);

    zSig0 |= 0x8000000000000000L;
    ++zExp;
    // roundAndPack:

    return roundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);
  }

  /**
   * Returns the result of subtracting the absolute values of the extended double-precision
   * floating-point values `a' and `b'. If `zSign' is 1, the difference is negated before being
   * returned. `zSign' is ignored if the result is a NaN. The subtraction is performed according to
   * the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * @param zSign flag
   * 
   * @return floatx80
   */
  public static FloatX80 subFloatx80Sigs(FloatX80 a, FloatX80 b, boolean zSign) {
    int aExp, bExp, zExp; // int32
    long aSig, bSig, zSig0 = 0, zSig1 = 0; // bits64
    int expDiff; // int32
    FloatX80 z = new FloatX80(); // floatx80

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    bSig = extractFloatx80Frac(b);
    bExp = extractFloatx80Exp(b);
    expDiff = aExp - bExp;
    if (0 < expDiff) {
      // goto aExpBigger;
      // aExpBigger:
      if (aExp == 0x7FFF) {
        if (aSig << 1 != 0)
          return propagateFloatx80NaN(a, b);
        return a;
      }
      if (bExp == 0)
        --expDiff;
      List<Long> list3 = JSoftFloatUtils.shift128RightJamming(bSig, 0, (short) expDiff);// , bSig,
                                                                                        // zSig1);
      bSig = list3.get(0);
      zSig1 = list3.get(1);
      // aBigger:
      List<Long> list4 = JSoftFloatUtils.sub128(aSig, 0, bSig, zSig1);// , zSig0, zSig1);
      zSig0 = list4.get(0);
      zSig1 = list4.get(1);

      zExp = aExp;
      // normalizeRoundAndPack:
      return normalizeRoundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);

    }
    if (expDiff < 0) {
      // goto bExpBigger;
      // bExpBigger:
      if (bExp == 0x7FFF) {
        if (bSig << 1 != 0)
          return propagateFloatx80NaN(a, b);
        return packFloatx80((zSign ? 1 : 0 ^ 1) != 0, 0x7FFF, 0x8000000000000000L);
      }
      if (aExp == 0)
        ++expDiff;
      List<Long> list = JSoftFloatUtils.shift128RightJamming(aSig, 0, (short) -expDiff);// , aSig,
                                                                                        // zSig1);
      aSig = list.get(0);
      zSig1 = list.get(1);

      // bBigger:
      List<Long> list2 = JSoftFloatUtils.sub128(bSig, 0, aSig, zSig1);// , zSig0, zSig1);
      zSig0 = list2.get(0);
      zSig1 = list2.get(1);
      zExp = bExp;
      zSign = ((zSign ? 1 : 0) ^ 1) != 0;
      // goto normalizeRoundAndPack;
      // normalizeRoundAndPack:
      return normalizeRoundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);
    }
    if (aExp == 0x7FFF) {
      if ((aSig | bSig) << 1 != 0) {
        return propagateFloatx80NaN(a, b);
      }
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      z.low = floatx80_default_nan_low;
      z.high = floatx80_default_nan_high;
      return z;
    }
    if (aExp == 0) {
      aExp = 1;
      bExp = 1;
    }
    zSig1 = 0;
    if (Utils.compareUnsigned(bSig, aSig)) {
      // goto aBigger;
      // aBigger:
      List<Long> list4 = JSoftFloatUtils.sub128(aSig, 0, bSig, zSig1);// , zSig0, zSig1);
      zSig0 = list4.get(0);
      zSig1 = list4.get(1);

      zExp = aExp;
      // normalizeRoundAndPack:
      return normalizeRoundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);

    }
    if (Utils.compareUnsigned(aSig, bSig)) {
      // goto bBigger;
      // bBigger:
      List<Long> list2 = JSoftFloatUtils.sub128(bSig, 0, aSig, zSig1);// , zSig0, zSig1);
      zSig0 = list2.get(0);
      zSig1 = list2.get(1);
      zExp = bExp;
      zSign = ((zSign ? 1 : 0) ^ 1) != 0;
      // goto normalizeRoundAndPack;
      // normalizeRoundAndPack:
      return normalizeRoundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);
    }
    return packFloatx80(float_rounding_mode == FloatRoundingMode.float_round_down, 0, 0);
  }

  /**
   * Returns the result of adding the extended double-precision floating-point values `a' and `b'.
   * The operation is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return floatx80
   */

  public static FloatX80 floatx80_add(FloatX80 a, FloatX80 b) {
    boolean aSign, bSign; // flag

    aSign = extractFloatx80Sign(a);

    bSign = extractFloatx80Sign(b);

    if (aSign == bSign) {
      return addFloatx80Sigs(a, b, aSign);
    } else {
      return subFloatx80Sigs(a, b, aSign);
    }
  }

  /**
   * Returns the result of subtracting the extended double-precision floating- point values `a' and
   * `b'. The operation is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return floatx80
   */

  public static FloatX80 floatx80_sub(FloatX80 a, FloatX80 b) {
    boolean aSign, bSign; // flag

    aSign = extractFloatx80Sign(a);
    bSign = extractFloatx80Sign(b);
    if (aSign == bSign) {
      return subFloatx80Sigs(a, b, aSign);
    } else {
      return addFloatx80Sigs(a, b, aSign);
    }
  }

  /**
   * Returns the result of multiplying the extended double-precision floating- point values `a' and
   * `b'. The operation is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return floatx80
   */
  public static FloatX80 floatx80_mul(final FloatX80 a, final FloatX80 b) {
    boolean aSign, bSign, zSign; // flag
    int aExp, bExp, zExp; // int32
    long aSig, bSig, zSig0 = 0, zSig1 = 0; // bits64
    FloatX80 z = new FloatX80(); // floatx80

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);
    bSig = extractFloatx80Frac(b);
    bExp = extractFloatx80Exp(b);
    bSign = extractFloatx80Sign(b);
    zSign = aSign ^ bSign;
    if (aExp == 0x7FFF) {
      if ((aSig << 1 != 0) || ((bExp == 0x7FFF) && (bSig << 1 != 0))) {
        return propagateFloatx80NaN(a, b);
      }
      if ((bExp | bSig) == 0) {
        // goto invalid;
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        z.low = floatx80_default_nan_low;
        z.high = floatx80_default_nan_high;
        return z;

      }
      return packFloatx80(zSign, 0x7FFF, 0x8000000000000000L);
    }
    if (bExp == 0x7FFF) {
      if (bSig << 1 != 0)
        return propagateFloatx80NaN(a, b);
      if ((aExp | aSig) == 0) {
        // invalid:
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        z.low = floatx80_default_nan_low;
        z.high = floatx80_default_nan_high;
        return z;
      }
      return packFloatx80(zSign, 0x7FFF, 0x8000000000000000L);
    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloatx80(zSign, 0, 0);
      List<Number> list = normalizeFloatx80Subnormal(aSig);
      aExp = (Integer) list.get(0);
      aSig = (Long) list.get(1);

    }
    if (bExp == 0) {
      if (bSig == 0)
        return packFloatx80(zSign, 0, 0);
      List<Number> list = normalizeFloatx80Subnormal(bSig);
      bExp = (Integer) list.get(0);
      bSig = (Long) list.get(1);

    }
    zExp = aExp + bExp - 0x3FFE;
    List<Long> list = JSoftFloatUtils.mul64To128(aSig, bSig);// , zSig0, zSig1);
    zSig0 = list.get(0);
    zSig1 = list.get(1);

    if (0 < (long) zSig0) {
      List<Long> list2 = JSoftFloatUtils.shortShift128Left(zSig0, zSig1, (short) 1);//, zSig0, zSig1);
      zSig0 = list2.get(0);
      zSig1 = list2.get(1);

      --zExp;
    }
    return roundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);
  }

  /**
   * Returns the result of dividing the extended double-precision floating-point value `a' by the
   * corresponding value `b'. The operation is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return floatx80
   */

  public static FloatX80 floatx80_div(final FloatX80 a, final FloatX80 b) {
    boolean aSign, bSign, zSign; // flag
    int aExp, bExp, zExp; // int32
    long aSig, bSig, zSig0, zSig1; // bits64
    long rem0 = 0, rem1, rem2 = 0, term0 = 0, term1 = 0, term2 = 0; // bits64
    FloatX80 z = new FloatX80(); // floatx80

    aSig = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);
    bSig = extractFloatx80Frac(b);
    bExp = extractFloatx80Exp(b);
    bSign = extractFloatx80Sign(b);

    zSign = aSign ^ bSign;
    if (aExp == 0x7FFF) {
      if (aSig << 1 != 0)
        return propagateFloatx80NaN(a, b);
      if (bExp == 0x7FFF) {
        if (bSig << 1 != 0)
          return propagateFloatx80NaN(a, b);
        // goto invalid;
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        z.low = floatx80_default_nan_low;
        z.high = floatx80_default_nan_high;
        return z;
      }
      return packFloatx80(zSign, 0x7FFF, 0x8000000000000000L);
    }
    if (bExp == 0x7FFF) {
      if (bSig << 1 != 0)
        return propagateFloatx80NaN(a, b);
      return packFloatx80(zSign, 0, 0);
    }
    if (bExp == 0) {
      if (bSig == 0) {
        if ((aExp | aSig) == 0) {
          // invalid:
          float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
          z.low = floatx80_default_nan_low;
          z.high = floatx80_default_nan_high;
          return z;
        }
        float_raise(FloatExceptionFlags.float_flag_divbyzero.getValue());
        return packFloatx80(zSign, 0x7FFF, 0x8000000000000000L);
      }
      List<Number> list = normalizeFloatx80Subnormal(bSig);
      bExp = (Integer) list.get(0);
      bSig = (Long) list.get(1);

    }
    if (aExp == 0) {
      if (aSig == 0)
        return packFloatx80(zSign, 0, 0);
      List<Number> list = normalizeFloatx80Subnormal(aSig);
      aExp = (Integer) list.get(0);
      aSig = (Long) list.get(1);
    }
    zExp = aExp - bExp + 0x3FFE;
    rem1 = 0;
    // if (bSig <= aSig) {
    if (Utils.compareUnsigned(bSig, aSig) || bSig == aSig) {
      List<Long> list = JSoftFloatUtils.shift128Right(aSig, 0, (short) 1);//, aSig, rem1);
      aSig = list.get(0);
      rem1 = list.get(1);

      ++zExp;
    }

    zSig0 = JSoftFloatUtils.estimateDiv128To64(aSig, rem1, bSig);

    List<Long> list = JSoftFloatUtils.mul64To128(bSig, zSig0);// , term0, term1);
    term0 = list.get(0);
    term1 = list.get(1);

    List<Long> list2 = JSoftFloatUtils.sub128(aSig, rem1, term0, term1);// , rem0, rem1);
    rem0 = list2.get(0);
    rem1 = list2.get(1);

    // (sbits64) rem0 < 0
    while (rem0 < 0) {
      --zSig0;
      List<Long> list3 = JSoftFloatUtils.add128(rem0, rem1, 0, bSig); // , rem0, rem1);
      rem0 = list3.get(0);
      rem1 = list3.get(1);
    }

    zSig1 = JSoftFloatUtils.estimateDiv128To64(rem1, 0, bSig);

    // if ((zSig1 << 1) <= 8) {
    if (Utils.compareUnsigned((zSig1 << 1), 8) || ((zSig1 << 1) == 8)) {
      List<Long> list3 = JSoftFloatUtils.mul64To128(bSig, zSig1);// , term1, term2);
      term1 = list3.get(0);
      term2 = list3.get(1);
      List<Long> list4 = JSoftFloatUtils.sub128(rem1, 0, term1, term2);// , rem1, rem2);
      rem1 = list4.get(0);
      rem2 = list4.get(1);

      while (rem1 < 0) {
        --zSig1;
        List<Long> list5 = JSoftFloatUtils.add128(rem1, rem2, 0, bSig); // , rem1, rem2);
        rem1 = list5.get(0);
        rem2 = list5.get(1);
      }
      zSig1 |= ((rem1 | rem2) != 0 ? 1 : 0);
    }
    return roundAndPackFloatx80(floatx80_rounding_precision, zSign, zExp, zSig0, zSig1);
  }

  /**
   * Returns the remainder of the extended double-precision floating-point value `a' with respect to
   * the corresponding value `b'. The operation is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return the remainder of the extended double-precision floating-point values.
   */
  public static FloatX80 floatx80_rem(final FloatX80 a, final FloatX80 b) {
    boolean aSign, zSign; // flag
    // boolean bSign
    int aExp, bExp, expDiff; // int32
    long aSig0, aSig1, bSig; // bits64
    long q, term0 = 0, term1 = 0, alternateASig0 = 0, alternateASig1 = 0; // bits64
    FloatX80 z = new FloatX80(); // floatx80

    aSig0 = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);
    bSig = extractFloatx80Frac(b);
    bExp = extractFloatx80Exp(b);
    // bSign = extractFloatx80Sign( b );

    if (aExp == 0x7FFF) {
      if ((aSig0 << 1 != 0) || ((bExp == 0x7FFF) && bSig << 1 != 0)) {
        return propagateFloatx80NaN(a, b);
      }
      // goto invalid;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      z.low = floatx80_default_nan_low;
      z.high = floatx80_default_nan_high;
      return z;
    }
    if (bExp == 0x7FFF) {
      if (bSig << 1 != 0)
        return propagateFloatx80NaN(a, b);
      return a;
    }
    if (bExp == 0) {
      if (bSig == 0) {
        // invalid:
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        z.low = floatx80_default_nan_low;
        z.high = floatx80_default_nan_high;

        return z;
      }
      List<Number> list = normalizeFloatx80Subnormal(bSig);
      bExp = (Integer) list.get(0);
      bSig = (Long) list.get(1);
    }
    if (aExp == 0) {
      if (aSig0 << 1 == 0)
        return a;
      List<Number> list = normalizeFloatx80Subnormal(aSig0);
      aExp = (Integer) list.get(0);
      aSig0 = (Long) list.get(1);
    }
    bSig |= 0x8000000000000000L;
    zSign = aSign;
    expDiff = aExp - bExp;
    aSig1 = 0;

    if (expDiff < 0) {
      if (expDiff < -1)
        return a;
      List<Long> list = JSoftFloatUtils.shift128Right(aSig0, 0, (short) 1);//, aSig0, aSig1);
      aSig0 = list.get(0);
      aSig1 = list.get(1);

      expDiff = 0;
    }
    // q = (bSig <= aSig0 ? 1 : 0);
    q = ((Utils.compareUnsigned(bSig, aSig0) || (bSig == aSig0)) ? 1 : 0);
    if (q != 0)
      aSig0 -= bSig;
    expDiff -= 64;

    // expDiff = -1;
    while (0 < expDiff) {
      // for (int h = 0; h < 15; h++) {
      q = JSoftFloatUtils.estimateDiv128To64(aSig0, aSig1, bSig);
      // q = (2 < q) ? q - 2 : 0;
      q = Utils.compareUnsigned(2, q) ? q - 2 : 0;
      List<Long> list = JSoftFloatUtils.mul64To128(bSig, q);// , term0, term1);
      term0 = list.get(0);
      term1 = list.get(1);

      List<Long> list1 = JSoftFloatUtils.sub128(aSig0, aSig1, term0, term1);// , aSig0, aSig1);
      aSig0 = list1.get(0);
      aSig1 = list1.get(1);

      List<Long> list2 = JSoftFloatUtils.shortShift128Left(aSig0, aSig1, (short) 62);//, aSig0, aSig1);
      aSig0 = list2.get(0);
      aSig1 = list2.get(1);

      expDiff -= 62;
    }

    expDiff += 64;
    if (0 < expDiff) {
      q = JSoftFloatUtils.estimateDiv128To64(aSig0, aSig1, bSig);
      q = (Utils.compareUnsigned(2, q)) ? q - 2 : 0;
      q >>>= 64 - expDiff;
      List<Long> list = JSoftFloatUtils.mul64To128(bSig, q << (64 - expDiff));// , term0, term1);
      term0 = list.get(0);
      term1 = list.get(1);
      List<Long> list1 = JSoftFloatUtils.sub128(aSig0, aSig1, term0, term1);// , aSig0, aSig1);
      aSig0 = list1.get(0);
      aSig1 = list1.get(1);
      List<Long> list2 =
          JSoftFloatUtils.shortShift128Left(0, bSig, (short) (64 - expDiff));//, term0, term1);
      term0 = list2.get(0);
      term1 = list2.get(1);

      while (JSoftFloatUtils.le128(term0, term1, aSig0, aSig1)) {
        ++q;
        List<Long> list3 = JSoftFloatUtils.sub128(aSig0, aSig1, term0, term1);// , aSig0, aSig1);
        aSig0 = list3.get(0);
        aSig1 = list3.get(1);
      }
    } else {
      term1 = 0;
      term0 = bSig;
    }

    List<Long> list = JSoftFloatUtils.sub128(term0, term1, aSig0, aSig1);
    alternateASig0 = list.get(0);
    alternateASig1 = list.get(1);

    if (JSoftFloatUtils.lt128(alternateASig0, alternateASig1, aSig0, aSig1)
        || (JSoftFloatUtils.eq128(alternateASig0, alternateASig1, aSig0, aSig1) && ((q & 1) != 0))) {
      aSig0 = alternateASig0;
      aSig1 = alternateASig1;
      zSign = !zSign;
    }

    return normalizeRoundAndPackFloatx80((byte) 80, zSign, bExp + expDiff, aSig0, aSig1);
  }

  /**
   * Returns the square root of the extended double-precision floating-point value `a'. The
   * operation is performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * 
   * @return the square root of the extended double-precision floating-point value.
   */
  public static FloatX80 floatx80_sqrt(final FloatX80 a) {
    boolean aSign; // flag
    int aExp, zExp; // int32
    long aSig0, aSig1 = 0, zSig0, zSig1, doubleZSig0; // bits64
    long rem0 = 0, rem1 = 0, rem2 = 0, rem3 = 0, term0 = 0, term1 = 0, term2 = 0, term3 = 0;//bits64
    FloatX80 z = new FloatX80(); // floatx80

    aSig0 = extractFloatx80Frac(a);
    aExp = extractFloatx80Exp(a);
    aSign = extractFloatx80Sign(a);

    if (aExp == 0x7FFF) {
      if (aSig0 << 1 != 0)
        return propagateFloatx80NaN(a, a);
      if (!aSign)
        return a;
      // goto invalid;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      z.low = floatx80_default_nan_low;
      z.high = floatx80_default_nan_high;
      return z;
    }
    if (aSign) {
      if ((aExp | aSig0) == 0)
        return a;
      // invalid:
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      z.low = floatx80_default_nan_low;
      z.high = floatx80_default_nan_high;
      return z;
    }
    if (aExp == 0) {
      if (aSig0 == 0)
        return packFloatx80(false, 0, 0);
      List<Number> list = normalizeFloatx80Subnormal(aSig0);
      aExp = (Integer) list.get(0);
      aSig0 = (Long) list.get(1);
    }
    zExp = ((aExp - 0x3FFF) >> 1) + 0x3FFF;
    zSig0 =
        0x00000000FFFFffffL & JSoftFloatUtils.estimateSqrt32((short) aExp, (int) (aSig0 >>> 32));
    List<Long> list =
        JSoftFloatUtils.shift128Right(aSig0, 0, (short) (2 + (aExp & 1)));//, aSig0, aSig1);
    aSig0 = list.get(0);
    aSig1 = list.get(1);

    zSig0 = JSoftFloatUtils.estimateDiv128To64(aSig0, aSig1, zSig0 << 32) + (zSig0 << 30);

    ByteBuffer buffer1 = ByteBuffer.allocate(8);
    buffer1.putLong(zSig0);
    BigInteger tempzDoubleZSig0 = new BigInteger(1, buffer1.array());

    doubleZSig0 = zSig0 << 1;
    tempzDoubleZSig0 = tempzDoubleZSig0.shiftLeft(1);

    List<Long> list2 = JSoftFloatUtils.mul64To128(zSig0, zSig0);// , term0, term1);
    term0 = list2.get(0);
    term1 = list2.get(1);

    List<Long> list3 = JSoftFloatUtils.sub128(aSig0, aSig1, term0, term1);// , rem0, rem1);
    rem0 = list3.get(0);
    rem1 = list3.get(1);

    while (rem0 < 0) {
      --zSig0;
      doubleZSig0 -= 2;
      List<Long> list4 = JSoftFloatUtils.add128(rem0, rem1, zSig0 >>> 63, doubleZSig0 | 1);
      rem0 = list4.get(0);
      rem1 = list4.get(1);
    }

    zSig1 = JSoftFloatUtils.estimateDiv128To64(rem1, 0, doubleZSig0);
    if ((zSig1 & 0x3FFFFFFFFFFFFFFFL) <= 5) {
      if (zSig1 == 0)
        zSig1 = 1;
      List<Long> list4 = JSoftFloatUtils.mul64To128(doubleZSig0, zSig1);// , term1, term2);
      term1 = list4.get(0);
      term2 = list4.get(1);

      List<Long> list5 = JSoftFloatUtils.sub128(rem1, 0, term1, term2);// , rem1, rem2);
      rem0 = list5.get(0);
      rem1 = list5.get(1);

      List<Long> list6 = JSoftFloatUtils.mul64To128(zSig1, zSig1);// , term2, term3);
      term1 = list6.get(0);
      term2 = list6.get(1);

      List<Long> list7 = JSoftFloatUtils.sub192(rem1, rem2, 0, 0, term2, term3);
      rem1 = list7.get(0);
      rem2 = list7.get(1);
      rem3 = list7.get(2);

      while (rem1 < 0) {
        --zSig1;
        List<Long> list8 = JSoftFloatUtils.shortShift128Left(0, zSig1, (short) 1);//, term2, term3);
        term2 = list8.get(0);
        term3 = list8.get(1);

        term3 |= 1;
        term2 |= doubleZSig0;
        List<Long> list9 =
            JSoftFloatUtils.add192(rem1, rem2, rem3, 0, term2, term3);//, rem1, rem2, rem3);
        rem1 = list9.get(0);
        rem2 = list9.get(1);
        rem3 = list9.get(2);
      }
      zSig1 |= ((rem1 | rem2 | rem3) != 0 ? 1 : 0);
    }
    List<Long> list8 = JSoftFloatUtils.shortShift128Left(0, zSig1, (short) 1);//, zSig0, zSig1);
    zSig0 = list8.get(0);
    zSig1 = list8.get(1);
    zSig0 |= doubleZSig0;

    return roundAndPackFloatx80(floatx80_rounding_precision, false, zExp, zSig0, zSig1);
  }

  /**
   * Returns 1 if the extended double-precision floating-point value `a' is equal to the
   * corresponding value `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return {@code true} if a == b, {@code false} otherwise.
   */
  public static boolean floatx80_eq(final FloatX80 a, final FloatX80 b) {
    if (((extractFloatx80Exp(a) == 0x7FFF) && (extractFloatx80Frac(a) << 1) != 0)
        || ((extractFloatx80Exp(b) == 0x7FFF) && (extractFloatx80Frac(b) << 1) != 0)) {
      if (floatx80_is_signaling_nan(a) || floatx80_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    return (a.low == b.low)
        && ((a.high == b.high) || ((a.low == 0) && (((a.high | b.high) << 1) == 0)));
  }

  /**
   * Returns 1 if the extended double-precision floating-point value `a' is less than or equal to
   * the corresponding value `b', and 0 otherwise. The comparison is performed according to the
   * IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return {@code true} if a <= b, {@code false} if a > b.
   */
  public static boolean floatx80_le(final FloatX80 a, final FloatX80 b) {
    boolean aSign, bSign; // flag

    if (((extractFloatx80Exp(a) == 0x7FFF) && (extractFloatx80Frac(a) << 1) != 0)
        || ((extractFloatx80Exp(b) == 0x7FFF) && (extractFloatx80Frac(b) << 1) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    aSign = extractFloatx80Sign(a);
    bSign = extractFloatx80Sign(b);
    if (aSign != bSign) {
      return aSign || (((((a.high | b.high) << 1)) | a.low | b.low) == 0);
    }
    return aSign ? JSoftFloatUtils.le128(b.high, b.low, a.high, a.low) : JSoftFloatUtils.le128(
        a.high, a.low, b.high, b.low);
  }

  /**
   * Returns 1 if the extended double-precision floating-point value `a' is less than the
   * corresponding value `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return {@code true} if a < b, {@code false} if a >= b.
   */
  public static boolean floatx80_lt(final FloatX80 a, final FloatX80 b) {
    boolean aSign, bSign; // flag

    if (((extractFloatx80Exp(a) == 0x7FFF) && (extractFloatx80Frac(a) << 1) != 0)
        || ((extractFloatx80Exp(b) == 0x7FFF) && (extractFloatx80Frac(b) << 1) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    aSign = extractFloatx80Sign(a);
    bSign = extractFloatx80Sign(b);
    if (aSign != bSign) {
      return aSign && ((((a.high | b.high) << 1)) | a.low | b.low) != 0;
    }
    return aSign ? JSoftFloatUtils.lt128(b.high, b.low, a.high, a.low) : JSoftFloatUtils.lt128(
        a.high, a.low, b.high, b.low);
  }

  /**
   * Returns 1 if the extended double-precision floating-point value `a' is equal to the
   * corresponding value `b', and 0 otherwise. The invalid exception is raised if either operand is
   * a NaN. Otherwise, the comparison is performed according to the IEC/IEEE Standard for Binary
   * Floating-Point Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return {@code true} if a == b, {@code false} otherwise.
   */
  public static boolean floatx80_eq_signaling(final FloatX80 a, final FloatX80 b) {
    if (((extractFloatx80Exp(a) == 0x7FFF) && (extractFloatx80Frac(a) << 1) != 0)
        || ((extractFloatx80Exp(b) == 0x7FFF) && (extractFloatx80Frac(b) << 1) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    return (a.low == b.low)
        && ((a.high == b.high) || ((a.low == 0) && (((a.high | b.high) << 1) == 0)));
  }

  /**
   * Returns 1 if the extended double-precision floating-point value `a' is less than or equal to
   * the corresponding value `b', and 0 otherwise. Quiet NaNs do not cause an exception. Otherwise,
   * the comparison is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return {@code true} if a <= b, {@code false} if a > b.
   */
  public static boolean floatx80_le_quiet(final FloatX80 a, final FloatX80 b) {
    boolean aSign, bSign; // flag

    if (((extractFloatx80Exp(a) == 0x7FFF) && (extractFloatx80Frac(a) << 1) != 0)
        || ((extractFloatx80Exp(b) == 0x7FFF) && (extractFloatx80Frac(b) << 1) != 0)) {
      if (floatx80_is_signaling_nan(a) || floatx80_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    aSign = extractFloatx80Sign(a);
    bSign = extractFloatx80Sign(b);
    if (aSign != bSign) {
      return aSign || (((((a.high | b.high) << 1)) | a.low | b.low) == 0);
    }
    return aSign ? JSoftFloatUtils.le128(b.high, b.low, a.high, a.low) : JSoftFloatUtils.le128(
        a.high, a.low, b.high, b.low);
  }

  /**
   * Returns 1 if the extended double-precision floating-point value `a' is less than the
   * corresponding value `b', and 0 otherwise. Quiet NaNs do not cause an exception. Otherwise, the
   * comparison is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the extended double-precision floating-point value.
   * @param b the extended double-precision floating-point value.
   * 
   * @return {@code true} if a < b, {@code false} if a >= b.
   */
  public static boolean floatx80_lt_quiet(final FloatX80 a, final FloatX80 b) {
    boolean aSign, bSign; // flag

    if (((extractFloatx80Exp(a) == 0x7FFF) && (extractFloatx80Frac(a) << 1) != 0)
        || ((extractFloatx80Exp(b) == 0x7FFF) && (extractFloatx80Frac(b) << 1) != 0)) {
      if (floatx80_is_signaling_nan(a) || floatx80_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    aSign = extractFloatx80Sign(a);
    bSign = extractFloatx80Sign(b);
    if (aSign != bSign) {
      return aSign && (((((a.high | b.high) << 1)) | a.low | b.low) != 0);
    }
    return aSign ? JSoftFloatUtils.lt128(b.high, b.low, a.high, a.low) : JSoftFloatUtils.lt128(
        a.high, a.low, b.high, b.low);
  }

  /**
   * Returns the result of converting the quadruple-precision floating-point value `a' to the 32-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic---which means in particular that the conversion is rounded
   * according to the current rounding mode. If `a' is a NaN, the largest positive integer is
   * returned. Otherwise, if the conversion overflows, the largest integer with the same sign as `a'
   * is returned.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return the result of converting the quadruple-precision floating-point value to Integer.
   */
  public static int float128_to_int32(final Float128 a) {
    boolean aSign; // flag
    int aExp, shiftCount; // int32
    long aSig0, aSig1; // bits64

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    if ((aExp == 0x7FFF) && ((aSig0 | aSig1) != 0))
      aSign = false;
    if (aExp != 0)
      aSig0 |= 0x0001000000000000L;
    aSig0 |= (aSig1 != 0) ? 1 : 0;
    shiftCount = 0x4028 - aExp;
    if (0 < shiftCount)
      aSig0 = JSoftFloatUtils.shift64RightJamming(aSig0, (short) shiftCount);
    return roundAndPackInt32(aSign, aSig0);
  }

  /**
   * Returns the result of converting the quadruple-precision floating-point value `a' to the 32-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic, except that the conversion is always rounded toward zero.
   * If `a' is a NaN, the largest positive integer is returned. Otherwise, if the conversion
   * overflows, the largest integer with the same sign as `a' is returned.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return int32
   */
  public static int float128_to_int32_round_to_zero(final Float128 a) {
    boolean aSign; // flag
    int aExp, shiftCount; // int32
    long aSig0, aSig1, savedASig; // bits64
    int z; // int32

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    aSig0 |= (aSig1 != 0) ? 1 : 0;
    if (0x401E < aExp) {
      if ((aExp == 0x7FFF) && aSig0 != 0)
        aSign = false;
      // goto invalid;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return aSign ? (int) 0x80000000 : 0x7FFFFFFF;
    } else if (aExp < 0x3FFF) {
      if (aExp != 0 || aSig0 != 0)
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      return 0;
    }
    aSig0 |= 0x0001000000000000L;
    shiftCount = 0x402F - aExp;
    savedASig = aSig0;
    aSig0 >>>= shiftCount;
    z = (int) aSig0;
    if (aSign)
      z = -z;
    if ((z < 0) ^ aSign) {
      // invalid:
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return aSign ? (int) 0x80000000 : 0x7FFFFFFF;
    }
    if ((aSig0 << shiftCount) != savedASig) {
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    }
    return z;
  }

  /**
   * Returns the result of converting the quadruple-precision floating-point value `a' to the 64-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic---which means in particular that the conversion is rounded
   * according to the current rounding mode. If `a' is a NaN, the largest positive integer is
   * returned. Otherwise, if the conversion overflows, the largest integer with the same sign as `a'
   * is returned.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return the result of converting the quadruple-precision floating-point value to the Long.
   */
  public static long float128_to_int64(final Float128 a) {
    boolean aSign; // flag
    int aExp, shiftCount; // int32
    long aSig0, aSig1; // bits64

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    if (aExp != 0)
      aSig0 |= 0x0001000000000000L;

    shiftCount = 0x402F - aExp;
    if (shiftCount <= 0) {
      if (0x403E < aExp) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        if (!aSign || ((aExp == 0x7FFF) && (aSig1 != 0 || (aSig0 != 0x0001000000000000L)))) {
          return 0x7FFFFFFFFFFFFFFFL;
        }
        return 0x8000000000000000L;
      }
      List<Long> list =
          JSoftFloatUtils.shortShift128Left(aSig0, aSig1, (short) -shiftCount);//, aSig0, aSig1);
      aSig0 = list.get(0);
      aSig1 = list.get(1);

    } else {
      List<Long> list =
          JSoftFloatUtils.shift64ExtraRightJamming(aSig0, aSig1, shiftCount); //, aSig0, aSig1);
      aSig0 = list.get(0);
      aSig1 = list.get(1);
    }
    return roundAndPackInt64(aSign, aSig0, aSig1);
  }

  /**
   * Returns the result of converting the quadruple-precision floating-point value `a' to the 64-bit
   * two's complement integer format. The conversion is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic, except that the conversion is always rounded toward zero.
   * If `a' is a NaN, the largest positive integer is returned. Otherwise, if the conversion
   * overflows, the largest integer with the same sign as `a' is returned.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return int64
   */
  public static long float128_to_int64_round_to_zero(final Float128 a) {
    boolean aSign; // flag
    int aExp, shiftCount; // int32
    long aSig0, aSig1; // bits64
    long z; // int64

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    if (aExp != 0)
      aSig0 |= 0x0001000000000000L;
    shiftCount = aExp - 0x402F;
    if (0 < shiftCount) {
      if (0x403E <= aExp) {
        aSig0 &= 0x0000FFFFFFFFFFFFL;
        if ((a.high == 0xC03E000000000000L) && (aSig1 < 0x0002000000000000L)) {
          if (aSig1 != 0)
            float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
        } else {
          float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
          if (!aSign || ((aExp == 0x7FFF) && (aSig0 | aSig1) != 0)) {
            return 0x7FFFFFFFFFFFFFFFL;
          }
        }
        return 0x8000000000000000L;
      }
      z = (aSig0 << shiftCount) | (aSig1 >>> ((-shiftCount) & 63));
      if (aSig1 << shiftCount != 0) {
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      }
    } else {
      if (aExp < 0x3FFF) {
        if ((aExp | aSig0 | aSig1) != 0) {
          float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
        }
        return 0;
      }
      z = aSig0 >>> (-shiftCount);
      if (aSig1 != 0 || (shiftCount != 0 && (aSig0 << (shiftCount & 63)) != 0)) {
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
      }
    }
    if (aSign)
      z = -z;
    return z;
  }

  /**
   * Returns the result of converting the quadruple-precision floating-point value `a' to the
   * single-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return float32
   */
  public static float float128_to_float32(final Float128 a) {
    boolean aSign; // flag
    int aExp; // int32
    long aSig0, aSig1; // bits64
    int zSig; // bits32

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    if (aExp == 0x7FFF) {
      if ((aSig0 | aSig1) != 0) {
        return commonNaNToFloat32(float128ToCommonNaN(a));
      }
      return packFloat32(aSign, (short) 0xFF, 0);
    }
    aSig0 |= (aSig1 != 0) ? 1 : 0;
    aSig0 = JSoftFloatUtils.shift64RightJamming(aSig0, (short) 18);//, aSig0);
    zSig = (int) aSig0;
    if (aExp != 0 || zSig != 0) {
      zSig |= 0x40000000;
      aExp -= 0x3F81;
    }
    return roundAndPackFloat32(aSign, (short) aExp, zSig);
  }

  /**
   * Returns the result of converting the quadruple-precision floating-point NaN `a' to the
   * canonical NaN format. If `a' is a signaling NaN, the invalid exception is raised.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return commonNaNT
   */
  public static CommonNaNT float128ToCommonNaN(final Float128 a) {
    CommonNaNT z = new CommonNaNT();

    if (JSoftFloatUtils.float128_is_signaling_nan(a))
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
    z.sign = a.high >>> 63 != 0;
    List<Long> list = JSoftFloatUtils.shortShift128Left(a.high, a.low, (short) 16);//, z.high, z.low);
    z.high = list.get(0);
    z.low = list.get(1);

    return z;
  }

  /**
   * Returns the result of converting the quadruple-precision floating-point value `a' to the
   * double-precision floating-point format. The conversion is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return float64
   */
  public static double float128_to_float64(final Float128 a) {
    boolean aSign; // flag
    int aExp; // int32
    long aSig0, aSig1; // bits64

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    if (aExp == 0x7FFF) {
      if ((aSig0 | aSig1) != 0) {
        return commonNaNToFloat64(float128ToCommonNaN(a));
      }
      return packFloat64(aSign, (short) 0x7FF, 0);
    }
    List<Long> list = JSoftFloatUtils.shortShift128Left(aSig0, aSig1, (short) 14);//, aSig0, aSig1);
    aSig0 = list.get(0);
    aSig1 = list.get(1);

    aSig0 |= (aSig1 != 0) ? 1 : 0;
    if (aExp != 0 || aSig0 != 0) {
      aSig0 |= 0x4000000000000000L;
      aExp -= 0x3C01;
    }
    return roundAndPackFloat64(aSign, (short) aExp, aSig0);
  }

  /**
   * Returns the result of converting the quadruple-precision floating-point value `a' to the
   * extended double-precision floating-point format. The conversion is performed according to the
   * IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return floatx80
   */
  public static FloatX80 float128_to_floatx80(final Float128 a) {
    boolean aSign; // flag
    int aExp; // int32
    long aSig0, aSig1; // bits64

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    if (aExp == 0x7FFF) {
      if ((aSig0 | aSig1) != 0) {
        return commonNaNToFloatx80(float128ToCommonNaN(a));
      }
      return packFloatx80(aSign, 0x7FFF, 0x8000000000000000L);
    }
    if (aExp == 0) {
      if ((aSig0 | aSig1) == 0)
        return packFloatx80(aSign, 0, 0);
      List<Number> list = normalizeFloat128Subnormal(aSig0, aSig1, aExp, aSig0, aSig1);
      aExp = (Integer) list.get(0);
      aSig0 = (Long) list.get(1);
      aSig1 = (Long) list.get(2);
    } else {
      aSig0 |= 0x0001000000000000L;
    }
    List<Long> list = JSoftFloatUtils.shortShift128Left(aSig0, aSig1, (short) 15);//, aSig0, aSig1);
    aSig0 = list.get(0);
    aSig1 = list.get(1);

    return roundAndPackFloatx80((byte) 80, aSign, aExp, aSig0, aSig1);
  }

  /**
   * Rounds the quadruple-precision floating-point value `a' to an integer, and returns the result
   * as a quadruple-precision floating-point value. The operation is performed according to the
   * IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return float128
   */
  public static Float128 float128_round_to_int(final Float128 a) {
    boolean aSign; // flag
    int aExp; // int32
    long lastBitMask, roundBitsMask; // bits64
    FloatRoundingMode roundingMode; // int8
    Float128 z = new Float128(); // float128

    aExp = extractFloat128Exp(a);
    if (0x402F <= aExp) {
      if (0x406F <= aExp) {
        if ((aExp == 0x7FFF) && ((extractFloat128Frac0(a) | extractFloat128Frac1(a)) != 0)) {
          return propagateFloat128NaN(a, a);
        }
        return a;
      }
      lastBitMask = 1;
      lastBitMask = (lastBitMask << (0x406E - aExp)) << 1;
      roundBitsMask = lastBitMask - 1;
      z = a;
      roundingMode = float_rounding_mode;
      if (roundingMode == FloatRoundingMode.float_round_nearest_even) {
        if (lastBitMask != 0) {
          List<Long> list = JSoftFloatUtils.add128(z.high, z.low, 0, lastBitMask >>> 1);
          z.high = list.get(0);
          z.low = list.get(1);

          if ((z.low & roundBitsMask) == 0)
            z.low &= ~lastBitMask;
        } else {
          if (z.low < 0) {
            ++z.high;
            if ((z.low << 1) == 0)
              z.high &= ~1;
          }
        }
      } else if (roundingMode != FloatRoundingMode.float_round_to_zero) {
        if (extractFloat128Sign(z) ^ (roundingMode == FloatRoundingMode.float_round_up)) {
          List<Long> list = JSoftFloatUtils.add128(z.high, z.low, 0, roundBitsMask);
          z.high = list.get(0);
          z.low = list.get(1);
        }
      }
      z.low &= ~roundBitsMask;
    } else {
      if (aExp < 0x3FFF) {
        if (((a.high << 1) | a.low) == 0)
          return a;
        float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
        aSign = extractFloat128Sign(a);
        switch (float_rounding_mode) {
          case float_round_nearest_even:
            if ((aExp == 0x3FFE) && ((extractFloat128Frac0(a) | extractFloat128Frac1(a)) != 0)) {
              return packFloat128(aSign, 0x3FFF, 0, 0);
            }
            break;
          case float_round_down:
            return aSign ? packFloat128(true, 0x3FFF, 0, 0) : packFloat128(false, 0, 0, 0);
          case float_round_up:
            return aSign ? packFloat128(true, 0, 0, 0) : packFloat128(false, 0x3FFF, 0, 0);
          default:
            break;
        }
        return packFloat128(aSign, 0, 0, 0);
      }
      lastBitMask = 1;
      lastBitMask <<= 0x402F - aExp;
      roundBitsMask = lastBitMask - 1;
      z.low = 0;
      z.high = a.high;
      roundingMode = float_rounding_mode;
      if (roundingMode == FloatRoundingMode.float_round_nearest_even) {
        z.high += lastBitMask >>> 1;
        if (((z.high & roundBitsMask) | a.low) == 0) {
          z.high &= ~lastBitMask;
        }
      } else if (roundingMode != FloatRoundingMode.float_round_to_zero) {
        if (extractFloat128Sign(z) ^ (roundingMode == FloatRoundingMode.float_round_up)) {
          z.high |= (a.low != 0) ? 1 : 0;
          z.high += roundBitsMask;
        }
      }
      z.high &= ~roundBitsMask;
    }
    if ((z.low != a.low) || (z.high != a.high)) {
      float_exception_flags |= FloatExceptionFlags.float_flag_inexact.getValue();
    }
    return z;

  }

  /**
   * Takes two quadruple-precision floating-point values `a' and `b', one of which is a NaN, and
   * returns the appropriate NaN result. If either `a' or `b' is a signaling NaN, the invalid
   * exception is raised.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return float128
   */
  public static Float128 propagateFloat128NaN(final Float128 a, final Float128 b) {
    boolean aIsNaN, aIsSignalingNaN, bIsNaN, bIsSignalingNaN; // flag

    aIsNaN = JSoftFloatUtils.float128_is_nan(a);
    aIsSignalingNaN = JSoftFloatUtils.float128_is_signaling_nan(a);
    bIsNaN = JSoftFloatUtils.float128_is_nan(b);
    bIsSignalingNaN = JSoftFloatUtils.float128_is_signaling_nan(b);
    a.high |= 0x0000800000000000L;
    b.high |= 0x0000800000000000L;
    if (aIsSignalingNaN | bIsSignalingNaN)
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
    if (aIsSignalingNaN) {
      if (bIsSignalingNaN) {
        // goto returnLargerSignificand;
        if (JSoftFloatUtils.lt128(a.high << 1, a.low, b.high << 1, b.low))
          return b;
        if (JSoftFloatUtils.lt128(b.high << 1, b.low, a.high << 1, a.low))
          return a;
        return (a.high < b.high) ? a : b;
      }
      return bIsNaN ? b : a;
    } else if (aIsNaN) {
      if (bIsSignalingNaN | !bIsNaN)
        return a;
      // returnLargerSignificand:
      if (JSoftFloatUtils.lt128(a.high << 1, a.low, b.high << 1, b.low))
        return b;
      if (JSoftFloatUtils.lt128(b.high << 1, b.low, a.high << 1, a.low))
        return a;
      return (a.high < b.high) ? a : b;
    } else {
      return b;
    }
  }

  /**
   * Returns the result of adding the absolute values of the quadruple-precision floating-point
   * values `a' and `b'. If `zSign' is 1, the sum is negated before being returned. `zSign' is
   * ignored if the result is a NaN. The addition is performed according to the IEC/IEEE Standard
   * for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * @param zSign if zSign == {@code true} the sum is negated before being returned,
   *              if zSign == {@code false} otherwise.
   * 
   * @return the result of adding the absolute values of the quadruple-precision floating-point
   *         values.
   */
  public static Float128 addFloat128Sigs(final Float128 a, final Float128 b, boolean zSign) {
    int aExp, bExp, zExp; // int32
    long aSig0, aSig1, bSig0, bSig1, zSig0 = 0, zSig1 = 0, zSig2 = 0; // bits64
    int expDiff; // int32

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    bSig1 = extractFloat128Frac1(b);
    bSig0 = extractFloat128Frac0(b);
    bExp = extractFloat128Exp(b);
    expDiff = aExp - bExp;
    if (0 < expDiff) {
      if (aExp == 0x7FFF) {
        if ((aSig0 | aSig1) != 0)
          return propagateFloat128NaN(a, b);
        return a;
      }
      if (bExp == 0) {
        --expDiff;
      } else {
        bSig0 |= 0x0001000000000000L;
      }
      List<Long> list = JSoftFloatUtils.shift128ExtraRightJamming(bSig0, bSig1, 0, expDiff);
      bSig0 = list.get(0);
      bSig1 = list.get(1);
      zSig2 = list.get(2);

      zExp = aExp;
    } else if (expDiff < 0) {
      if (bExp == 0x7FFF) {
        if ((bSig0 | bSig1) != 0)
          return propagateFloat128NaN(a, b);
        return packFloat128(zSign, 0x7FFF, 0, 0);
      }
      if (aExp == 0) {
        ++expDiff;
      } else {
        aSig0 |= 0x0001000000000000L;
      }
      List<Long> list = JSoftFloatUtils.shift128ExtraRightJamming(aSig0, aSig1, 0, -expDiff);
      aSig0 = list.get(0);
      aSig1 = list.get(1);
      zSig2 = list.get(2);
      zExp = bExp;
    } else {
      if (aExp == 0x7FFF) {
        if ((aSig0 | aSig1 | bSig0 | bSig1) != 0) {
          return propagateFloat128NaN(a, b);
        }
        return a;
      }
      List<Long> list = JSoftFloatUtils.add128(aSig0, aSig1, bSig0, bSig1);
      zSig0 = list.get(0);
      zSig1 = list.get(1);

      if (aExp == 0)
        return packFloat128(zSign, 0, zSig0, zSig1);
      zSig2 = 0;
      zSig0 |= 0x0002000000000000L;
      zExp = aExp;
      // goto shiftRight1;
      List<Long> list2 = JSoftFloatUtils.shift128ExtraRightJamming(zSig0, zSig1, zSig2, 1);
      zSig0 = list2.get(0);
      zSig1 = list2.get(1);
      zSig2 = list2.get(2);
      // roundAndPack:
      return roundAndPackFloat128(zSign, zExp, zSig0, zSig1, zSig2);
    }
    aSig0 |= 0x0001000000000000L;
    List<Long> list = JSoftFloatUtils.add128(aSig0, aSig1, bSig0, bSig1);
    zSig0 = list.get(0);
    zSig1 = list.get(1);
    --zExp;
    if (Utils.compareUnsigned(zSig0, 0x0002000000000000L)) {
      // goto roundAndPack;
      return roundAndPackFloat128(zSign, zExp, zSig0, zSig1, zSig2);
    }
    ++zExp;
    // shiftRight1:
    List<Long> list2 = JSoftFloatUtils.shift128ExtraRightJamming(zSig0, zSig1, zSig2, 1);
    zSig0 = list2.get(0);
    zSig1 = list2.get(1);
    zSig2 = list2.get(2);
    // roundAndPack:
    return roundAndPackFloat128(zSign, zExp, zSig0, zSig1, zSig2);
  }

  /**
   * Returns the result of subtracting the absolute values of the quadruple- precision
   * floating-point values `a' and `b'. If `zSign' is 1, the difference is negated before being
   * returned. `zSign' is ignored if the result is a NaN. The subtraction is performed according to
   * the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * @param zSign if zSign == {@code true} the difference is negated before being returned,
   *              if zSign == {@code false} otherwise.
   * 
   * @return the result of subtracting the absolute values of the quadruple- precision
   *         floating-point values.
   */
  public static Float128 subFloat128Sigs(final Float128 a, final Float128 b, boolean zSign) {
    int aExp, bExp, zExp; // int32
    long aSig0, aSig1, bSig0, bSig1, zSig0 = 0, zSig1 = 0; // bits64
    int expDiff; // int32
    Float128 z = new Float128();

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    bSig1 = extractFloat128Frac1(b);
    bSig0 = extractFloat128Frac0(b);
    bExp = extractFloat128Exp(b);
    expDiff = aExp - bExp;
    List<Long> list = JSoftFloatUtils.shortShift128Left(aSig0, aSig1, (short) 14);
    aSig0 = list.get(0);
    aSig1 = list.get(1);

    List<Long> list2 = JSoftFloatUtils.shortShift128Left(bSig0, bSig1, (short) 14);
    bSig0 = list2.get(0);
    bSig1 = list2.get(1);
    if (0 < expDiff) {
      // goto aExpBigger;
      // aExpBigger:
      if (aExp == 0x7FFF) {
        if ((aSig0 | aSig1) != 0)
          return propagateFloat128NaN(a, b);
        return a;
      }
      if (bExp == 0) {
        --expDiff;
      } else {
        bSig0 |= 0x4000000000000000L;
      }
      List<Long> list5 = JSoftFloatUtils.shift128RightJamming(bSig0, bSig1, (short) expDiff);
      bSig0 = list5.get(0);
      bSig1 = list5.get(1);
      aSig0 |= 0x4000000000000000L;
      // aBigger:
      List<Long> list6 = JSoftFloatUtils.sub128(aSig0, aSig1, bSig0, bSig1);
      zSig0 = list6.get(0);
      zSig1 = list6.get(1);
      zExp = aExp;
      // normalizeRoundAndPack:
      --zExp;
      return normalizeRoundAndPackFloat128(zSign, zExp - 14, zSig0, zSig1);
    }
    if (expDiff < 0) {
      // goto bExpBigger;
      // bExpBigger:
      if (bExp == 0x7FFF) {
        if ((bSig0 | bSig1) != 0)
          return propagateFloat128NaN(a, b);
        return packFloat128(((zSign ? 1 : 0) ^ 1) != 0, 0x7FFF, 0, 0);
      }
      if (aExp == 0) {
        ++expDiff;
      } else {
        aSig0 |= 0x4000000000000000L;
      }
      List<Long> list3 = JSoftFloatUtils.shift128RightJamming(aSig0, aSig1, (short) -expDiff);
      aSig0 = list3.get(0);
      aSig1 = list3.get(1);

      bSig0 |= 0x4000000000000000L;
      // bBigger:
      List<Long> list4 = JSoftFloatUtils.sub128(bSig0, bSig1, aSig0, aSig1);
      zSig0 = list4.get(0);
      zSig1 = list4.get(1);

      zExp = bExp;
      zSign = ((zSign ? 1 : 0) ^ 1) != 0;
      // goto normalizeRoundAndPack;
      // normalizeRoundAndPack:
      --zExp;
      return normalizeRoundAndPackFloat128(zSign, zExp - 14, zSig0, zSig1);
    }
    if (aExp == 0x7FFF) {
      if ((aSig0 | aSig1 | bSig0 | bSig1) != 0) {
        return propagateFloat128NaN(a, b);
      }
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      z.low = float128_default_nan_low;
      z.high = float128_default_nan_high;
      return z;
    }
    if (aExp == 0) {
      aExp = 1;
      bExp = 1;
    }

    if (Utils.compareUnsigned(bSig0, aSig0)) {
      // goto aBigger;
      // aBigger:
      List<Long> list6 = JSoftFloatUtils.sub128(aSig0, aSig1, bSig0, bSig1);
      zSig0 = list6.get(0);
      zSig1 = list6.get(1);
      zExp = aExp;
      // normalizeRoundAndPack:
      --zExp;
      return normalizeRoundAndPackFloat128(zSign, zExp - 14, zSig0, zSig1);
    }
    if (Utils.compareUnsigned(aSig0, bSig0)) {
      // goto bBigger;
      // bBigger:
      List<Long> list4 = JSoftFloatUtils.sub128(bSig0, bSig1, aSig0, aSig1);
      zSig0 = list4.get(0);
      zSig1 = list4.get(1);

      zExp = bExp;
      zSign = ((zSign ? 1 : 0) ^ 1) != 0;
      // goto normalizeRoundAndPack;
      // normalizeRoundAndPack:

      --zExp;
      return normalizeRoundAndPackFloat128(zSign, zExp - 14, zSig0, zSig1);
    }
    if (Utils.compareUnsigned(bSig1, aSig1)) {
      // goto aBigger;
      // aBigger:
      List<Long> list6 = JSoftFloatUtils.sub128(aSig0, aSig1, bSig0, bSig1);
      zSig0 = list6.get(0);
      zSig1 = list6.get(1);
      zExp = aExp;
      // normalizeRoundAndPack:
      --zExp;
      return normalizeRoundAndPackFloat128(zSign, zExp - 14, zSig0, zSig1);
    }
    if (Utils.compareUnsigned(aSig1, bSig1)) {
      // goto bBigger;
      // bBigger:
      List<Long> list4 = JSoftFloatUtils.sub128(bSig0, bSig1, aSig0, aSig1);
      zSig0 = list4.get(0);
      zSig1 = list4.get(1);

      zExp = bExp;
      zSign = ((zSign ? 1 : 0) ^ 1) != 0;
      // goto normalizeRoundAndPack;
      // normalizeRoundAndPack:
      --zExp;
      return normalizeRoundAndPackFloat128(zSign, zExp - 14, zSig0, zSig1);
    }
    return packFloat128(float_rounding_mode == FloatRoundingMode.float_round_down, 0, 0, 0);
  }

  /**
   * Returns the result of adding the quadruple-precision floating-point values `a' and `b'. The
   * operation is performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return the result of adding the quadruple-precision floating-point values.
   */
  public static Float128 float128_add(final Float128 a, final Float128 b) {
    boolean aSign, bSign;

    aSign = extractFloat128Sign(a);
    bSign = extractFloat128Sign(b);
    if (aSign == bSign) {
      return addFloat128Sigs(a, b, aSign);
    } else {
      return subFloat128Sigs(a, b, aSign);
    }
  }

  /**
   * Returns the result of subtracting the quadruple-precision floating-point values `a' and `b'.
   * The operation is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return the result of subtracting.
   */
  public static Float128 float128_sub(final Float128 a, final Float128 b) {
    boolean aSign, bSign;

    aSign = extractFloat128Sign(a);
    bSign = extractFloat128Sign(b);
    if (aSign == bSign) {
      return subFloat128Sigs(a, b, aSign);
    } else {
      return addFloat128Sigs(a, b, aSign);
    }
  }

  /**
   * Returns the result of multiplying the quadruple-precision floating-point values `a' and `b'.
   * The operation is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return the result of multiplying.
   */
  public static Float128 float128_mul(Float128 a, Float128 b) {
    boolean aSign, bSign, zSign;
    int aExp, bExp, zExp;
    long aSig0, aSig1, bSig0, bSig1, zSig0 = 0, zSig1 = 0, zSig2 = 0, zSig3 = 0; // bits64
    Float128 z = new Float128();

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    bSig1 = extractFloat128Frac1(b);
    bSig0 = extractFloat128Frac0(b);
    bExp = extractFloat128Exp(b);
    bSign = extractFloat128Sign(b);
    zSign = aSign ^ bSign;
    if (aExp == 0x7FFF) {
      if (((aSig0 | aSig1) != 0) || ((bExp == 0x7FFF) && (bSig0 | bSig1) != 0)) {
        return propagateFloat128NaN(a, b);
      }
      if ((bExp | bSig0 | bSig1) == 0) {
        // goto invalid;
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        z.low = float128_default_nan_low;
        z.high = float128_default_nan_high;
        return z;
      }
      return packFloat128(zSign, 0x7FFF, 0, 0);
    }
    if (bExp == 0x7FFF) {
      if ((bSig0 | bSig1) != 0)
        return propagateFloat128NaN(a, b);
      if ((aExp | aSig0 | aSig1) == 0) {
        // invalid:
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        z.low = float128_default_nan_low;
        z.high = float128_default_nan_high;
        return z;
      }
      return packFloat128(zSign, 0x7FFF, 0, 0);
    }
    if (aExp == 0) {
      if ((aSig0 | aSig1) == 0)
        return packFloat128(zSign, 0, 0, 0);
      List<Number> list = normalizeFloat128Subnormal(aSig0, aSig1, aExp, aSig0, aSig1);
      aExp = (Integer) list.get(0);
      aSig0 = (Long) list.get(1);
      aSig1 = (Long) list.get(2);
    }
    if (bExp == 0) {
      if ((bSig0 | bSig1) == 0)
        return packFloat128(zSign, 0, 0, 0);

      List<Number> list = normalizeFloat128Subnormal(bSig0, bSig1, bExp, bSig0, bSig1);
      bExp = (Integer) list.get(0);
      bSig0 = (Long) list.get(1);
      bSig1 = (Long) list.get(2);
    }
    zExp = aExp + bExp - 0x4000;
    aSig0 |= 0x0001000000000000L;
    List<Long> list = JSoftFloatUtils.shortShift128Left(bSig0, bSig1, (short) 16);
    bSig0 = list.get(0);
    bSig1 = list.get(1);

    List<Long> list2 = JSoftFloatUtils.mul128To256(aSig0, aSig1, bSig0, bSig1);
    zSig0 = list2.get(0);
    zSig1 = list2.get(1);
    zSig2 = list2.get(2);
    zSig3 = list2.get(3);

    List<Long> list3 = JSoftFloatUtils.add128(zSig0, zSig1, aSig0, aSig1);
    zSig0 = list3.get(0);
    zSig1 = list3.get(1);
    zSig2 |= (zSig3 != 0) ? 1 : 0;
    if (0x0002000000000000L <= zSig0) {
      List<Long> list4 = JSoftFloatUtils.shift128ExtraRightJamming(zSig0, zSig1, zSig2, 1);
      zSig0 = list4.get(0);
      zSig1 = list4.get(1);
      zSig2 = list4.get(2);

      ++zExp;
    }
    return roundAndPackFloat128(zSign, zExp, zSig0, zSig1, zSig2);
  }

  /**
   * Returns the result of dividing the quadruple-precision floating-point value `a' by the
   * corresponding value `b'. The operation is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value (dividend).
   * @param b the quadruple-precision floating-point value (divider).
   * 
   * @return the result of dividing.
   */
  public static Float128 float128_div(Float128 a, Float128 b) {
    boolean aSign, bSign, zSign; // flag
    int aExp, bExp, zExp; // int32
    long aSig0, aSig1, bSig0, bSig1, zSig0, zSig1, zSig2 = 0; // bits64
    long rem0 = 0, rem1 = 0, rem2 = 0, rem3 = 0, term0 = 0, term1 = 0, term2 = 0, term3 = 0;//bits64
    Float128 z = new Float128(); //

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    bSig1 = extractFloat128Frac1(b);
    bSig0 = extractFloat128Frac0(b);
    bExp = extractFloat128Exp(b);
    bSign = extractFloat128Sign(b);
    zSign = aSign ^ bSign;
    if (aExp == 0x7FFF) {
      if ((aSig0 | aSig1) != 0)
        return propagateFloat128NaN(a, b);
      if (bExp == 0x7FFF) {
        if ((bSig0 | bSig1) != 0)
          return propagateFloat128NaN(a, b);
        // goto invalid;
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        z.low = float128_default_nan_low;
        z.high = float128_default_nan_high;
        return z;
      }
      return packFloat128(zSign, 0x7FFF, 0, 0);
    }
    if (bExp == 0x7FFF) {
      if ((bSig0 | bSig1) != 0)
        return propagateFloat128NaN(a, b);
      return packFloat128(zSign, 0, 0, 0);
    }
    if (bExp == 0) {
      if ((bSig0 | bSig1) == 0) {
        if ((aExp | aSig0 | aSig1) == 0) {
          // invalid:
          float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
          z.low = float128_default_nan_low;
          z.high = float128_default_nan_high;
          return z;
        }
        float_raise(FloatExceptionFlags.float_flag_divbyzero.getValue());
        return packFloat128(zSign, 0x7FFF, 0, 0);
      }
      List<Number> list = normalizeFloat128Subnormal(bSig0, bSig1, bExp, bSig0, bSig1);
      bExp = (Integer) list.get(0);
      bSig0 = (Long) list.get(1);
      bSig1 = (Long) list.get(2);
    }
    if (aExp == 0) {
      if ((aSig0 | aSig1) == 0)
        return packFloat128(zSign, 0, 0, 0);
      List<Number> list = normalizeFloat128Subnormal(aSig0, aSig1, aExp, aSig0, aSig1);
      aExp = (Integer) list.get(0);
      aSig0 = (Long) list.get(1);
      aSig1 = (Long) list.get(2);

    }
    zExp = aExp - bExp + 0x3FFD;
    List<Long> list =
        JSoftFloatUtils.shortShift128Left(aSig0 | 0x0001000000000000L, aSig1, (short) 15);
    aSig0 = list.get(0);
    aSig1 = list.get(1);

    List<Long> list1 =
        JSoftFloatUtils.shortShift128Left(bSig0 | 0x0001000000000000L, bSig1, (short) 15);
    bSig0 = list1.get(0);
    bSig1 = list1.get(1);

    if (JSoftFloatUtils.le128(bSig0, bSig1, aSig0, aSig1)) {
      List<Long> list2 = JSoftFloatUtils.shift128Right(aSig0, aSig1, (short) 1);//, aSig0, aSig1);
      aSig0 = list2.get(0);
      aSig1 = list2.get(1);

      ++zExp;
    }
    zSig0 = JSoftFloatUtils.estimateDiv128To64(aSig0, aSig1, bSig0);
    List<Long> list2 = JSoftFloatUtils.mul128By64To192(bSig0, bSig1, zSig0);// , term0, term1,
                                                                            // term2);
    term0 = list2.get(0);
    term1 = list2.get(1);
    term2 = list2.get(2);

    List<Long> list3 =
        JSoftFloatUtils.sub192(aSig0, aSig1, 0, term0, term1, term2);//, rem0, rem1, rem2);
    rem0 = list3.get(0);
    rem1 = list3.get(1);
    rem2 = list3.get(2);
    while (rem0 < 0) {
      --zSig0;
      List<Long> list4 =
          JSoftFloatUtils.add192(rem0, rem1, rem2, 0, bSig0, bSig1);//, rem0, rem1, rem2);
      rem0 = list4.get(0);
      rem1 = list4.get(1);
      rem2 = list4.get(2);
    }
    zSig1 = JSoftFloatUtils.estimateDiv128To64(rem1, rem2, bSig0);
    if ((zSig1 & 0x3FFF) <= 4) {
      List<Long> list4 = JSoftFloatUtils.mul128By64To192(bSig0, bSig1, zSig1);// , term1, term2,
                                                                              // term3);
      term1 = list4.get(0);
      term2 = list4.get(1);
      term3 = list4.get(2);

      List<Long> list5 =
          JSoftFloatUtils.sub192(rem1, rem2, 0, term1, term2, term3);//, rem1, rem2, rem3);
      rem1 = list5.get(0);
      rem2 = list5.get(1);
      rem3 = list5.get(2);
      while (rem1 < 0) {
        --zSig1;
        List<Long> list6 =
            JSoftFloatUtils.add192(rem1, rem2, rem3, 0, bSig0, bSig1);//, rem1, rem2, rem3);
        rem1 = list6.get(0);
        rem2 = list6.get(1);
        rem3 = list6.get(2);
      }
      zSig1 |= ((rem1 | rem2 | rem3) != 0 ? 1 : 0);
    }
    List<Long> list4 =
        JSoftFloatUtils.shift128ExtraRightJamming(zSig0, zSig1, 0, 15);//, zSig0, zSig1, zSig2);
    zSig0 = list4.get(0);
    zSig1 = list4.get(1);
    zSig2 = list4.get(2);
    return roundAndPackFloat128(zSign, zExp, zSig0, zSig1, zSig2);
  }

  /**
   * Returns the remainder of the quadruple-precision floating-point value `a' with respect to the
   * corresponding value `b'. The operation is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return the remainder of the quadruple-precision floating-point values.
   */
  public static Float128 float128_rem(final Float128 a, final Float128 b) {
    boolean aSign, zSign; // flag
    // boolean bSign;
    int aExp, bExp, expDiff; // int32
    long aSig0, aSig1, bSig0, bSig1, q, term0 = 0, term1 = 0, term2 = 0; // bits64
    long alternateASig0, alternateASig1, sigMean1 = 0; // bits64
    long sigMean0 = 0; // sbits64
    Float128 z = new Float128(); // float128

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    bSig1 = extractFloat128Frac1(b);
    bSig0 = extractFloat128Frac0(b);
    bExp = extractFloat128Exp(b);
    // bSign = extractFloat128Sign( b );

    if (aExp == 0x7FFF) {
      if ((aSig0 | aSig1) != 0 || ((bExp == 0x7FFF) && (bSig0 | bSig1) != 0)) {
        return propagateFloat128NaN(a, b);
      }
      // goto invalid;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      z.low = float128_default_nan_low;
      z.high = float128_default_nan_high;
      return z;
    }
    if (bExp == 0x7FFF) {
      if ((bSig0 | bSig1) != 0)
        return propagateFloat128NaN(a, b);
      return a;
    }
    if (bExp == 0) {
      if ((bSig0 | bSig1) == 0) {
        // invalid:
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
        z.low = float128_default_nan_low;
        z.high = float128_default_nan_high;
        return z;
      }
      List<Number> list = normalizeFloat128Subnormal(bSig0, bSig1, bExp, bSig0, bSig1);
      bExp = (Integer) list.get(0);
      bSig0 = (Long) list.get(1);
      bSig1 = (Long) list.get(2);
    }
    if (aExp == 0) {
      if ((aSig0 | aSig1) == 0)
        return a;
      List<Number> list = normalizeFloat128Subnormal(aSig0, aSig1, aExp, aSig0, aSig1);
      aExp = (Integer) list.get(0);
      aSig0 = (Long) list.get(1);
      aSig1 = (Long) list.get(2);
    }
    expDiff = aExp - bExp;
    if (expDiff < -1)
      return a;
    List<Long> list =
        JSoftFloatUtils.shortShift128Left(aSig0 | 0x0001000000000000L, aSig1,
            (short) (15 - (expDiff < 0 ? 1 : 0)));//, aSig0, aSig1);
    aSig0 = list.get(0);
    aSig1 = list.get(1);

    List<Long> list1 =
        JSoftFloatUtils.shortShift128Left(bSig0 | 0x0001000000000000L, bSig1, (short) 15);//, bSig0, bSig1);
    bSig0 = list1.get(0);
    bSig1 = list1.get(1);
    q = JSoftFloatUtils.le128(bSig0, bSig1, aSig0, aSig1) ? 1 : 0;
    if (q != 0) {
      List<Long> list2 = JSoftFloatUtils.sub128(aSig0, aSig1, bSig0, bSig1);// , aSig0, aSig1);
      aSig0 = list2.get(0);
      aSig1 = list2.get(1);
    }
    expDiff -= 64;

    while (0 < expDiff) {
      q = JSoftFloatUtils.estimateDiv128To64(aSig0, aSig1, bSig0);
      q = (Utils.compareUnsigned(4, q)) ? q - 4 : 0;
      List<Long> list2 = JSoftFloatUtils.mul128By64To192(bSig0, bSig1, q);// , term0, term1, term2);
      term0 = list2.get(0);
      term1 = list2.get(1);
      term2 = list2.get(2);

      List<Long> list3 =
          JSoftFloatUtils.shortShift192Left(term0, term1, term2, 61); //, term1, term2, allZero);
      term1 = list3.get(0);
      term2 = list3.get(1);
      //allZero = list3.get(2);
      List<Long> list4 =
          JSoftFloatUtils.shortShift128Left(aSig0, aSig1, (short) 61);//, aSig0, allZero);
      aSig0 = list4.get(0);
      //allZero = list4.get(1);
      List<Long> list5 = JSoftFloatUtils.sub128(aSig0, 0, term1, term2);// , aSig0, aSig1);
      aSig0 = list5.get(0);
      aSig1 = list5.get(1);
      expDiff -= 61;
    }

    if (-64 < expDiff) {
      q = JSoftFloatUtils.estimateDiv128To64(aSig0, aSig1, bSig0);
      q = (Utils.compareUnsigned(4, q)) ? q - 4 : 0;
      q >>>= -expDiff;

      List<Long> list2 = JSoftFloatUtils.shift128Right(bSig0, bSig1, (short) 12);//, bSig0, bSig1);
      bSig0 = list2.get(0);
      bSig1 = list2.get(1);

      expDiff += 52;
      if (expDiff < 0) {
        List<Long> list3 =
            JSoftFloatUtils.shift128Right(aSig0, aSig1, (short) -expDiff);//, aSig0, aSig1);
        aSig0 = list3.get(0);
        aSig1 = list3.get(1);
      } else {
        List<Long> list3 =
            JSoftFloatUtils.shortShift128Left(aSig0, aSig1, (short) expDiff);//, aSig0, aSig1);
        aSig0 = list3.get(0);
        aSig1 = list3.get(1);
      }
      List<Long> list3 = JSoftFloatUtils.mul128By64To192(bSig0, bSig1, q);// , term0, term1, term2);
      term0 = list3.get(0);
      term1 = list3.get(1);
      term2 = list3.get(2);

      List<Long> list4 = JSoftFloatUtils.sub128(aSig0, aSig1, term1, term2);// , aSig0, aSig1);
      aSig0 = list4.get(0);
      aSig1 = list4.get(1);
    } else {
      List<Long> list2 = JSoftFloatUtils.shift128Right(aSig0, aSig1, (short) 12);//, aSig0, aSig1);
      aSig0 = list2.get(0);
      aSig1 = list2.get(1);
      List<Long> list3 = JSoftFloatUtils.shift128Right(bSig0, bSig1, (short) 12);// bSig0, bSig1);
      bSig0 = list3.get(0);
      bSig1 = list3.get(1);
    }

    do {
      alternateASig0 = aSig0;
      alternateASig1 = aSig1;
      ++q;
      List<Long> list4 = JSoftFloatUtils.sub128(aSig0, aSig1, bSig0, bSig1);// , aSig0, aSig1);
      aSig0 = list4.get(0);
      aSig1 = list4.get(1);
    } while (0 <= aSig0);

    List<Long> list2 = JSoftFloatUtils.add128(aSig0, aSig1, alternateASig0, alternateASig1);
    sigMean0 = list2.get(0);
    sigMean1 = list2.get(1);

    if ((sigMean0 < 0) || (((sigMean0 | sigMean1) == 0) && (q & 1) != 0)) {
      aSig0 = alternateASig0;
      aSig1 = alternateASig1;
    }
    zSign = (aSig0 < 0);
    if (zSign) {
      List<Long> list4 = JSoftFloatUtils.sub128(0, 0, aSig0, aSig1);// , aSig0, aSig1);
      aSig0 = list4.get(0);
      aSig1 = list4.get(1);
    }

    return normalizeRoundAndPackFloat128(aSign ^ zSign, bExp - 4, aSig0, aSig1);
  }

  /**
   * Returns the square root of the quadruple-precision floating-point value `a'. The operation is
   * performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * 
   * @return the square root of the quadruple-precision floating-point value.
   */
  public static Float128 float128_sqrt(final Float128 a) {
    boolean aSign; // flag
    int aExp, zExp; // int32
    long aSig0, aSig1, zSig0, zSig1, zSig2 = 0, doubleZSig0; // bits64
    long rem0 = 0, rem1 = 0, rem2 = 0, rem3 = 0, term0 = 0, term1 = 0, term2 = 0, term3 = 0; // bits64
    Float128 z = new Float128(); //

    aSig1 = extractFloat128Frac1(a);
    aSig0 = extractFloat128Frac0(a);
    aExp = extractFloat128Exp(a);
    aSign = extractFloat128Sign(a);
    if (aExp == 0x7FFF) {
      if ((aSig0 | aSig1) != 0)
        return propagateFloat128NaN(a, a);
      if (!aSign)
        return a;
      // goto invalid;
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      z.low = float128_default_nan_low;
      z.high = float128_default_nan_high;
      return z;
    }
    if (aSign) {
      if ((aExp | aSig0 | aSig1) == 0)
        return a;
      // invalid:
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      z.low = float128_default_nan_low;
      z.high = float128_default_nan_high;
      return z;
    }
    if (aExp == 0) {
      if ((aSig0 | aSig1) == 0)
        return packFloat128(false, 0, 0, 0);
      List<Number> list = normalizeFloat128Subnormal(aSig0, aSig1, aExp, aSig0, aSig1);
      aExp = (Integer) list.get(0);
      aSig0 = (Long) list.get(1);
      aSig1 = (Long) list.get(2);

    }
    zExp = ((aExp - 0x3FFF) >> 1) + 0x3FFE;
    aSig0 |= 0x0001000000000000L;
    zSig0 = JSoftFloatUtils.estimateSqrt32((short) aExp, (int) aSig0 >>> 17);
    List<Long> list =
        JSoftFloatUtils.shortShift128Left(aSig0, aSig1, (short) (13 - (aExp & 1)));//, aSig0, aSig1);
    aSig0 = list.get(0);
    aSig1 = list.get(1);

    zSig0 = JSoftFloatUtils.estimateDiv128To64(aSig0, aSig1, zSig0 << 32) + (zSig0 << 30);
    doubleZSig0 = zSig0 << 1;
    List<Long> list1 = JSoftFloatUtils.mul64To128(zSig0, zSig0);// , term0, term1);
    term0 = list1.get(0);
    term1 = list1.get(1);

    List<Long> list2 = JSoftFloatUtils.sub128(aSig0, aSig1, term0, term1);// , rem0, rem1);
    rem0 = list2.get(0);
    rem1 = list2.get(1);
    while (rem0 < 0) {
      --zSig0;
      doubleZSig0 -= 2;
      List<Long> list3 = JSoftFloatUtils.add128(rem0, rem1, zSig0 >>> 63, doubleZSig0 | 1);
      rem0 = list3.get(0);
      rem1 = list3.get(1);
    }
    zSig1 = JSoftFloatUtils.estimateDiv128To64(rem1, 0, doubleZSig0);
    if ((zSig1 & 0x1FFF) <= 5) {
      if (zSig1 == 0)
        zSig1 = 1;
      List<Long> list3 = JSoftFloatUtils.mul64To128(doubleZSig0, zSig1);// , term1, term2);
      term1 = list3.get(0);
      term2 = list3.get(1);
      List<Long> list4 = JSoftFloatUtils.sub128(rem1, 0, term1, term2);// , rem1, rem2);
      rem1 = list4.get(0);
      rem2 = list4.get(1);
      List<Long> list5 = JSoftFloatUtils.mul64To128(zSig1, zSig1);// , term2, term3);
      term2 = list5.get(0);
      term3 = list5.get(1);
      List<Long> list6 = JSoftFloatUtils.sub192(rem1, rem2, 0, 0, term2, term3);//, rem1, rem2, rem3);
      rem1 = list6.get(0);
      rem2 = list6.get(1);
      rem3 = list6.get(2);
      while (rem1 < 0) {
        --zSig1;
        List<Long> list7 = JSoftFloatUtils.shortShift128Left(0, zSig1, (short) 1);//, term2, term3);
        term2 = list7.get(0);
        term3 = list7.get(1);
        term3 |= 1;
        term2 |= doubleZSig0;
        List<Long> list8 =
            JSoftFloatUtils.add192(rem1, rem2, rem3, 0, term2, term3);//, rem1, rem2, rem3);
        rem1 = list8.get(0);
        rem2 = list8.get(1);
        rem3 = list8.get(2);
      }
      zSig1 |= ((rem1 | rem2 | rem3) != 0 ? 1 : 0);
    }
    List<Long> list3 =
        JSoftFloatUtils.shift128ExtraRightJamming(zSig0, zSig1, 0, 14);//, zSig0, zSig1, zSig2);
    zSig0 = list3.get(0);
    zSig1 = list3.get(1);
    zSig2 = list3.get(2);

    return roundAndPackFloat128(false, zExp, zSig0, zSig1, zSig2);
  }

  /**
   * Returns 1 if the quadruple-precision floating-point value `a' is equal to the corresponding
   * value `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return {@code true} if a == b, {@code false} otherwise.
   */
  public static boolean float128_eq(final Float128 a, final Float128 b) {

    if (((extractFloat128Exp(a) == 0x7FFF) && (extractFloat128Frac0(a) | extractFloat128Frac1(a)) != 0)
        || ((extractFloat128Exp(b) == 0x7FFF) && (extractFloat128Frac0(b) | extractFloat128Frac1(b)) != 0)) {
      if (JSoftFloatUtils.float128_is_signaling_nan(a)
          || JSoftFloatUtils.float128_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    return (a.low == b.low)
        && ((a.high == b.high) || ((a.low == 0) && (((a.high | b.high) << 1) == 0)));

  }

  /**
   * Returns 1 if the quadruple-precision floating-point value `a' is less than or equal to the
   * corresponding value `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE
   * Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return {@code true} if a <= b, {@code false} if a > b.
   */
  public static boolean float128_le(final Float128 a, final Float128 b) {
    boolean aSign, bSign;

    if (((extractFloat128Exp(a) == 0x7FFF) && (extractFloat128Frac0(a) | extractFloat128Frac1(a)) != 0)
        || ((extractFloat128Exp(b) == 0x7FFF) && (extractFloat128Frac0(b) | extractFloat128Frac1(b)) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    aSign = extractFloat128Sign(a);
    bSign = extractFloat128Sign(b);
    if (aSign != bSign) {
      return aSign || (((((a.high | b.high) << 1)) | a.low | b.low) == 0);
    }
    return aSign ? JSoftFloatUtils.le128(b.high, b.low, a.high, a.low) : JSoftFloatUtils.le128(
        a.high, a.low, b.high, b.low);
  }

  /**
   * Returns 1 if the quadruple-precision floating-point value `a' is less than the corresponding
   * value `b', and 0 otherwise. The comparison is performed according to the IEC/IEEE Standard for
   * Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return {@code true} if a < b, {@code false} if a >= b.
   */
  public static boolean float128_lt(final Float128 a, final Float128 b) {
    boolean aSign, bSign;

    if (((extractFloat128Exp(a) == 0x7FFF) && (extractFloat128Frac0(a) | extractFloat128Frac1(a)) != 0)
        || ((extractFloat128Exp(b) == 0x7FFF) && (extractFloat128Frac0(b) | extractFloat128Frac1(b)) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    aSign = extractFloat128Sign(a);
    bSign = extractFloat128Sign(b);
    if (aSign != bSign) {
      return aSign && (((((a.high | b.high) << 1)) | a.low | b.low) != 0);
    }
    return aSign ? JSoftFloatUtils.lt128(b.high, b.low, a.high, a.low) : JSoftFloatUtils.lt128(
        a.high, a.low, b.high, b.low);
  }

  /**
   * Returns 1 if the quadruple-precision floating-point value `a' is equal to the corresponding
   * value `b', and 0 otherwise. The invalid exception is raised if either operand is a NaN.
   * Otherwise, the comparison is performed according to the IEC/IEEE Standard for Binary
   * Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return {@code true} if a == b, {@code false} otherwise.
   */
  public static boolean float128_eq_signaling(final Float128 a, final Float128 b) {
    if (((extractFloat128Exp(a) == 0x7FFF) && (extractFloat128Frac0(a) | extractFloat128Frac1(a)) != 0)
        || ((extractFloat128Exp(b) == 0x7FFF) && (extractFloat128Frac0(b) | extractFloat128Frac1(b)) != 0)) {
      float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      return false;
    }
    return (a.low == b.low)
        && ((a.high == b.high) || ((a.low == 0) && (((a.high | b.high) << 1) == 0)));
  }

  /**
   * Returns 1 if the quadruple-precision floating-point value `a' is less than or equal to the
   * corresponding value `b', and 0 otherwise. Quiet NaNs do not cause an exception. Otherwise, the
   * comparison is performed according to the IEC/IEEE Standard for Binary Floating-Point
   * Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return {@code true} if a <= b, {@code false} if a > b.
   */
  public static boolean float128_le_quiet(final Float128 a, final Float128 b) {
    boolean aSign, bSign;

    if (((extractFloat128Exp(a) == 0x7FFF) && (extractFloat128Frac0(a) | extractFloat128Frac1(a)) != 0)
        || ((extractFloat128Exp(b) == 0x7FFF) && (extractFloat128Frac0(b) | extractFloat128Frac1(b)) != 0)) {
      if (JSoftFloatUtils.float128_is_signaling_nan(a)
          || JSoftFloatUtils.float128_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    aSign = extractFloat128Sign(a);
    bSign = extractFloat128Sign(b);
    if (aSign != bSign) {
      return aSign || (((((a.high | b.high) << 1)) | a.low | b.low) == 0);
    }
    return aSign ? JSoftFloatUtils.le128(b.high, b.low, a.high, a.low) : JSoftFloatUtils.le128(
        a.high, a.low, b.high, b.low);
  }

  /**
   * Returns 1 if the quadruple-precision floating-point value `a' is less than the corresponding
   * value `b', and 0 otherwise. Quiet NaNs do not cause an exception. Otherwise, the comparison is
   * performed according to the IEC/IEEE Standard for Binary Floating-Point Arithmetic.
   * 
   * @param a the quadruple-precision floating-point value.
   * @param b the quadruple-precision floating-point value.
   * 
   * @return {@code true} if a < b, {@code false} if a >= b.
   */
  public static boolean float128_lt_quiet(final Float128 a, final Float128 b) {
    boolean aSign, bSign; // flag

    if (((extractFloat128Exp(a) == 0x7FFF) && (extractFloat128Frac0(a) | extractFloat128Frac1(a)) != 0)
        || ((extractFloat128Exp(b) == 0x7FFF) && (extractFloat128Frac0(b) | extractFloat128Frac1(b)) != 0)) {
      if (JSoftFloatUtils.float128_is_signaling_nan(a)
          || JSoftFloatUtils.float128_is_signaling_nan(b)) {
        float_raise(FloatExceptionFlags.float_flag_invalid.getValue());
      }
      return false;
    }
    aSign = extractFloat128Sign(a);
    bSign = extractFloat128Sign(b);
    if (aSign != bSign) {
      return aSign && (((((a.high | b.high) << 1)) | a.low | b.low) != 0);
    }
    return aSign ? JSoftFloatUtils.lt128(b.high, b.low, a.high, a.low) : JSoftFloatUtils.lt128(
        a.high, a.low, b.high, b.low);
  }
}
