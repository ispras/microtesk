/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.softfloat;

/**
 * The half-precision floating-point operations.
 * 
 * @author <a href="mailto:protsenko@ispras.ru">Alexander Protsenko</a>
 */

public class Float16Operations {
  /**
   * Returns the fraction bits of the half-precision floating-point value 'a'.
   * 
   * @param a the half-precision floating-point value
   * 
   * @return the fraction bits
   */
  public static int extractFloat16Frac(final short a) {
    return a & 0x03FF;
  }

  /**
   * Returns the exponent bits of the half-precision floating-point value `a'.
   * 
   * @param a the half-precision floating-point value
   * 
   * @return the exponent bits
   */
  public static int extractFloat16Exp(final short a) {
    return a >>> 10 & 0x1F;
  }

  /**
   * Returns the sign bit of the half-precision floating-point value `a'.
   * 
   * @param a the half-precision floating-point value
   * 
   * @return the sign bit
   */
  public static boolean extractFloat16Sign(final short a) {
    return a >>> 15 != 0;
  }


  






}
