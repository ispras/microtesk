/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.softfloat;
/**
 * Software IEC/IEEE floating-point types: Float80.
 * 
 * @author <a href="mailto:protsenko@ispras.ru">Alexander Protsenko</a>
 */
public class FloatX80 {
  public short high; // unsigned short high
  public long low; // unsigned long long

  public FloatX80() {};

  public FloatX80(final short high, final long low)
  {
    this.high = high;
    this.low = low;
  };

  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }

    if (obj == null) {
      return false;
    }

    if (getClass() != obj.getClass()) {
      return false;
    } else {
      if (this.high == ((FloatX80) obj).high && this.low == ((FloatX80) obj).low) {
        return true;
      }
    }
    
    return false;
  }

  @Override
  public String toString() {
    return "0x" + Integer.toHexString(0xffff&high) + "." + Long.toHexString(low);
  }
}
