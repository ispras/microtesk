/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.softfloat;

/**
 * Software IEC/IEEE floating-point types.
 * The quadruple-precision floating-point value.
 * 
 * @author <a href="mailto:protsenko@ispras.ru">Alexander Protsenko</a>
 */

public class Float128 {
  long low, high; // unsigned long long

  public Float128() {};

  public Float128(final long high, final long low)
  {
    this.high = high;
    this.low = low;
  };

  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }

    if (obj == null) {
      return false;
    }

    if (getClass() != obj.getClass()) {
      return false;
    } else {
      if (this.high == ((Float128) obj).high && this.low == ((Float128) obj).low) {
        return true;
      }
    }
    
    return false;
  }

  @Override
  public String toString() {
    return "0x" + Long.toHexString(high) + "." + Long.toHexString(low);
  }
}
