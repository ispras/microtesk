/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.softfloat;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * softfloat from project http://www.jhauser.us/arithmetic/SoftFloat.html
 * 
 * @author <a href="mailto:protsenko@ispras.ru">Alexander Protsenko</a>
 */

public class JSoftFloatUtils {
  /**
   * Returns the number of leading 0 bits before the most-significant 1 bit of `a'. If `a' is zero,
   * 32 is returned.
   * 
   * @param a bits32
   * 
   * @return int8
   */
  public static byte countLeadingZeros32(int a) {
    byte countLeadingZerosHigh[] =
        {8, 7, 6, 6, 5, 5, 5, 5, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
            3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
            2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    byte shiftCount;
    shiftCount = 0;

    if (Utils.compareUnsigned(a, 0x10000)) {// (a < 0x10000) {
      shiftCount += 16;
      a <<= 16;
    }
    if (Utils.compareUnsigned(a, 0x1000000)) { // (a < 0x1000000) {
      shiftCount += 8;
      a <<= 8;
    }

    shiftCount += countLeadingZerosHigh[a >>> 24];
    return shiftCount;
  }

  /**
   * Returns the number of leading 0 bits before the most-significant 1 bit of `a'. If `a' is zero,
   * 64 is returned.
   * 
   * @param a bits64
   * 
   * @return int8
   */
  public static byte countLeadingZeros64(long a) {
    byte shiftCount; // int8

    shiftCount = 0;
    // a < ((long) 1) << 32
    if (Utils.compareUnsigned(a, ((long) 1) << 32)) {
      shiftCount += 32;
    } else {
      a >>>= 32;
    }
    shiftCount += countLeadingZeros32((int) a);
    return shiftCount;
  }

  /**
   * Shifts `a' right by the number of bits given in `count'. If any nonzero bits are shifted off,
   * they are ``jammed'' into the least significant bit of the result by setting the least
   * significant bit to 1. The value of `count' can be arbitrarily large; in particular, if `count'
   * is greater than 32, the result will be either 0 or 1, depending on whether `a' is zero or
   * nonzero. The result is stored in the location pointed to by `zPtr'.
   * 
   * @parama a bits32
   * @param count int16
   * 
   * @return zPtr
   */
  public static int shift32RightJamming(final int a, final short count) {
    int zPtr;

    if (count == 0) {
      zPtr = a;
    } else if (count < 32) {
      zPtr = a >>> count | ((a << ((-count) & 31)) != 0 ? 1 : 0);
    } else {
      zPtr = (a != 0) ? 1 : 0;
    }

    return zPtr; // zPtr bits32
  }

  /**
   * Shifts `a' right by the number of bits given in `count'. If any nonzero bits are shifted off,
   * they are ``jammed'' into the least significant bit of the result by setting the least
   * significant bit to 1. The value of `count' can be arbitrarily large; in particular, if `count'
   * is greater than 64, the result will be either 0 or 1, depending on whether `a' is zero or
   * nonzero. The result is stored in the location pointed to by `zPtr'.
   * 
   * @param a bits64
   * @param count int16
   * @param zPtr bits64
   * 
   * @return bits64
   */
  public static long shift64RightJamming(final long a, final short count) {
    long zPtr;

    if (count == 0) {
      zPtr = a;
    } else if (count < 64) {
      zPtr = a >>> count | ((a << ((-count) & 63)) != 0 ? 1 : 0);
    } else {
      zPtr = (a != 0 ? 1 : 0);
    }

    return zPtr; // zPtr bits64
  }

  /**
   * Software IEC/IEEE floating-point rounding mode.
   */
  public enum FloatRoundingMode {
    // extern !!!int8 float_rounding_mode;
    float_round_nearest_even(0), float_round_to_zero(1), float_round_down(2), float_round_up(3);
    private int value;

    private FloatRoundingMode(final int value) {
      this.setValue(value);
    }

    public int getValue() {
      return value;
    }

    public void setValue(final int value) {
      this.value = value;
    }
  }

  /**
   * Software IEC/IEEE floating-point exception flags.
   */
  public enum FloatExceptionFlags {
    // extern !!!int8 float_exception_flags;
    float_flag_inexact(1), float_flag_underflow(2), float_flag_overflow(4), float_flag_divbyzero(8),
    float_flag_invalid(16);
    private int value;

    private FloatExceptionFlags(final int value) {
      this.value = value;
    }

    public int getValue() {
      return this.value;
    }
  };

  /**
   * Software IEC/IEEE floating-point underflow tininess-detection mode.
   */
  public enum FloatDetectTininess {
    float_tininess_after_rounding(0), float_tininess_before_rounding(1);
    private int value;

    private FloatDetectTininess(final int value) {
      this.setValue(value);
    }

    public int getValue() {
      return value;
    }

    public void setValue(final int value) {
      this.value = value;
    }
  };

  /**
   * Shifts the 128-bit value formed by concatenating `a0' and `a1' right by 64 _plus_ the number of
   * bits given in `count'. The shifted result is at most 64 nonzero bits; this is stored at the
   * location pointed to by `z0Ptr'. The bits shifted off form a second 64-bit result as follows:
   * The _last_ bit shifted off is the most-significant bit of the extra result, and the other 63
   * bits of the extra result are all zero if and only if _all_but_the_last_ bits shifted off were
   * all zero. This extra result is stored in the location pointed to by `z1Ptr'. The value of
   * `count' can be arbitrarily large. (This routine makes more sense if `a0' and `a1' are
   * considered to form a fixed-point value with binary point between `a0' and `a1'. This fixed-
   * point value is shifted right by the number of bits given in `count', and the integer part of
   * the result is returned at the location pointed to by `z0Ptr'. The fractional part of the result
   * may be slightly corrupted as described above, and is returned at the location pointed to by
   * `z1Ptr'.)
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param count int16
   * 
   * @return list{z0Ptr, z1Ptr}
   */
  public static List<Long> shift64ExtraRightJamming(final long a0, final long a1, long count) {
    long z0Ptr, z1Ptr;  // bits64
    byte negCount = (byte) ((-count) & 63); // int8

    if (count == 0) {
      z1Ptr = a1;
      z0Ptr = a0;
    } else if (count < 64) {
      z1Ptr = (a0 << negCount) | ((a1 != 0) ? 1 : 0);
      z0Ptr = a0 >>> count;
    } else {
      if (count == 64) {
        z1Ptr = a0 | (a1 != 0 ? 1 : 0);
      } else {
        z1Ptr = ((a0 | a1) != 0) ? 1 : 0;
      }
      z0Ptr = 0;
    }

    List<Long> list = new ArrayList<Long>();
    list.add(z0Ptr);
    list.add(z1Ptr);

    return list;
  }

  /**
   * Shifts the 128-bit value formed by concatenating `a0' and `a1' left by the number of bits given
   * in `count'. Any bits shifted off are lost. The value of `count' must be less than 64. The
   * result is broken into two 64-bit pieces which are stored at the locations pointed to by `z0Ptr'
   * and `z1Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param count int16
   * 
   * @return list{z0Ptr, z1Ptr}
   */
  public static List<Long> shortShift128Left(final long a0, final long a1, final short count) {
    long z0Ptr, z1Ptr; // bits 64
    z1Ptr = a1 << count;
    z0Ptr = (count == 0) ? a0 : (a0 << count) | (a1 >>> ((-count) & 63));

    List<Long> list = new ArrayList<Long>();
    list.add(z0Ptr);
    list.add(z1Ptr);

    return list;
  }

  /**
   * Adds the 128-bit value formed by concatenating `a0' and `a1' to the 128-bit value formed by
   * concatenating `b0' and `b1'. Addition is modulo 2^128, so any carry out is lost. The result is
   * broken into two 64-bit pieces which are stored at the locations pointed to by `z0Ptr' and
   * `z1Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param b0 bits64
   * @param b1 bits64
   * 
   * @return list{z0Ptr, z1Ptr}
   */
  public static List<Long> add128(final long a0, final long a1, final long b0, final long b1) {
    long z1; // bits64
    long z0Ptr;
    long z1Ptr;

    z1 = a1 + b1;
    z1Ptr = z1;
    z0Ptr = a0 + b0 + (Utils.compareUnsigned(z1, a1) ? 1 : 0);

    List<Long> list = new ArrayList<Long>();
    list.add(z0Ptr);
    list.add(z1Ptr);

    return list;
  }

  /**
   * Returns 1 if the 128-bit value formed by concatenating `a0' and `a1' is less than the 128-bit
   * value formed by concatenating `b0' and `b1'. Otherwise, returns 0.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param b0 bits64
   * @param b1 bits64
   * 
   * @return flag
   */
  public static boolean lt128(final long a0, final long a1, final long b0, final long b1) {
    // return (a0 < b0) || ((a0 == b0) && (a1 < b1));
    return (Utils.compareUnsigned(a0, b0)) || ((a0 == b0) && (Utils.compareUnsigned(a1, b1)));
  }

  /**
   * Returns 1 if the 128-bit value formed by concatenating `a0' and `a1' is equal to the 128-bit
   * value formed by concatenating `b0' and `b1'. Otherwise, returns 0.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param b0 bits64
   * @param b1 bits64
   * 
   * @return flag
   */
  public static boolean eq128(final long a0, final long a1, final long b0, final long b1) {
    return (a0 == b0) && (a1 == b1);
  }

  /**
   * Shifts the 192-bit value formed by concatenating `a0', `a1', and `a2' right by 64 _plus_ the
   * number of bits given in `count'. The shifted result is at most 128 nonzero bits; these are
   * broken into two 64-bit pieces which are stored at the locations pointed to by `z0Ptr' and
   * `z1Ptr'. The bits shifted off form a third 64-bit result as follows: The _last_ bit shifted off
   * is the most-significant bit of the extra result, and the other 63 bits of the extra result are
   * all zero if and only if _all_but_the_last_ bits shifted off were all zero. This extra result is
   * stored in the location pointed to by `z2Ptr'. The value of `count' can be arbitrarily large.
   * (This routine makes more sense if `a0', `a1', and `a2' are considered to form a fixed-point
   * value with binary point between `a1' and `a2'. This fixed-point value is shifted right by the
   * number of bits given in `count', and the integer part of the result is returned at the
   * locations pointed to by `z0Ptr' and `z1Ptr'. The fractional part of the result may be slightly
   * corrupted as described above, and is returned at the location pointed to by `z2Ptr'.)
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param a2 bits64
   * @param count int16
   * 
   * @return list{z0Ptr, z1Ptr, z2Ptr}
   */
  public static List<Long> shift128ExtraRightJamming(final long a0, final long a1, long a2,
      final int count) {
    long z0, z1, z2; // bits64
    byte negCount = (byte) ((-count) & 63); // int8

    if (count == 0) {
      z2 = a2;
      z1 = a1;
      z0 = a0;
    } else {
      if (count < 64) {
        z2 = a1 << negCount;
        z1 = (a0 << negCount) | (a1 >>> count);
        z0 = a0 >>> count;
      } else {
        if (count == 64) {
          z2 = a1;
          z1 = a0;
        } else {
          a2 |= a1;
          if (count < 128) {
            z2 = a0 << negCount;
            z1 = a0 >>> (count & 63);
          } else {
            z2 = (Long) ((count == 128) ? a0 : (a0 != 0 ? 1 : 0));
            z1 = 0;
          }
        }
        z0 = 0;
      }
      z2 |= (a2 != 0) ? 1 : 0;
    }

    List<Long> list = new ArrayList<Long>();
    list.add(z0); // z0Ptr
    list.add(z1); // z1Ptr
    list.add(z2); // z2Ptr

    return list;
  }

  /**
   * Shifts the 128-bit value formed by concatenating `a0' and `a1' right by the number of bits
   * given in `count'. Any bits shifted off are lost. The value of `count' can be arbitrarily large;
   * in particular, if `count' is greater than 128, the result will be 0. The result is broken into
   * two 64-bit pieces which are stored at the locations pointed to by `z0Ptr' and `z1Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param count int16
   * 
   * @return z0Ptr, z1Ptr
   */
  public static List<Long> shift128Right(final long a0, final long a1, final short count) {
    long z0, z1; // bits64
    byte negCount = (byte) ((-count) & 63); // int8

    if (count == 0) {
      z1 = a1;
      z0 = a0;
    } else if (count < 64) {
      z1 = (a0 << negCount) | (a1 >>> count);
      z0 = a0 >>> count;
    } else {
      z1 = (count < 64) ? (a0 >>> (count & 63)) : 0;
      z0 = 0;
    }

    List<Long> list = new ArrayList<Long>();
    list.add(z0); // z0Ptr bits64
    list.add(z1); // z1Ptr bits64

    return list;
  }

  /**
   * Returns an approximation to the 64-bit integer quotient obtained by dividing `b' into the
   * 128-bit value formed by concatenating `a0' and `a1'. The divisor `b' must be at least 2^63. If
   * q is the exact quotient truncated toward zero, the approximation returned lies between q and q
   * + 2 inclusive. If the exact quotient q is larger than 64 bits, the maximum positive 64-bit
   * unsigned integer is returned.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param b bits64
   * 
   * @return z bits64
   */
  public static long estimateDiv128To64(final long a0, final long a1, final long b) {
    // long b0, b1; // bits64

    long rem0 = 0, rem1 = 0, term0 = 0, term1 = 0; // bits64
    // long z; // bits64
    BigInteger z;
    BigInteger b0, b1;

    if (Utils.compareUnsigned(b, a0) || b == a0) // b <= a0
      return 0xFFFFFFFFFFFFFFFFL;

    // b0 = b >>> 32;
    b0 = BigInteger.valueOf(b);
    b0 = b0.shiftRight(32).and(BigInteger.valueOf(0xffffffffL));

    // z = (b0 << 32 <= a0) ? 0xFFFFFFFF00000000L : (a0 / b0) << 32;
    long b0Long = b0.shiftLeft(32).longValue();

    ByteBuffer buffer0 = ByteBuffer.allocate(JSoftFloat.LONG_BYTES);
    buffer0.putLong(a0);

    BigInteger a0Big = new BigInteger(1, buffer0.array());

    z = (Utils.compareUnsigned(b0Long, a0) || b0Long == a0) ?
        BigInteger.valueOf(0xFFFFFFFF00000000L) : (a0Big.divide(b0)).shiftLeft(32);

    List<Long> list = mul64To128(b, z.longValue());// , term0, term1);
    term0 = list.get(0);
    term1 = list.get(1);

    List<Long> list3 = sub128(a0, a1, term0, term1);// , rem0, rem1);
    rem0 = list3.get(0);
    rem1 = list3.get(1);

    while (rem0 < 0) {
      // z -= 0x100000000L;
      z = z.subtract(BigInteger.valueOf(0x100000000L));
      // b1 = b << 32;
      b1 = BigInteger.valueOf(b);
      b1 = b1.shiftLeft(32);

      List<Long> list2 = add128(rem0, rem1, b0.longValue(), b1.longValue()); // , rem0, rem1
      rem0 = list2.get(0);
      rem1 = list2.get(1);
    }

    rem0 = (rem0 << 32) | (rem1 >>> 32);
    // z |= (b0 << 32 <= rem0) ? 0xFFFFFFFF : rem0 / b0;

    b0Long = b0.shiftLeft(32).longValue();

    ByteBuffer buffer = ByteBuffer.allocate(JSoftFloat.LONG_BYTES);
    buffer.putLong(rem0);

    BigInteger rem0Big = new BigInteger(1, buffer.array());

    z = z.or((Utils.compareUnsigned(b0Long, rem0) || b0Long == rem0) ? BigInteger
            .valueOf(0xFFFFFFFF) : rem0Big.divide(b0));

    return z.longValue();
  }

  /**
   * Multiplies `a' by `b' to obtain a 128-bit product. The product is broken into two 64-bit pieces
   * which are stored at the locations pointed to by `z0Ptr' and `z1Ptr'.
   * 
   * @param a bits64
   * @param b bits64
   * 
   * @return list{z0Ptr, z1Ptr} bits64
   */
  public static List<Long> mul64To128(final long a, final long b) {
    // long aHigh, aLow, bHigh, bLow; // bits32
    BigInteger aHigh, aLow, bHigh, bLow; // bits32
    // long z0, zMiddleA, zMiddleB, z1; // bits64
    BigInteger z0, zMiddleA, zMiddleB, z1; // bits64

    aLow = BigInteger.valueOf(a & 0xffffffffL); // aLow = a;
    aHigh = BigInteger.valueOf(a >>> 32); // aHigh = (a >>> 32);
    bLow = BigInteger.valueOf(b & 0xffffffffL); // bLow = b;
    bHigh = BigInteger.valueOf(b >>> 32); // bHigh = (b >>> 32);

    z1 = aLow.multiply(bLow); // z1 = aLow * bLow;
    zMiddleA = aLow.multiply(bHigh); // zMiddleA = aLow * bHigh;
    zMiddleB = aHigh.multiply(bLow); // zMiddleB = aHigh * bLow;
    z0 = aHigh.multiply(bHigh);
    zMiddleA = zMiddleA.add(zMiddleB); // zMiddleA += zMiddleB;

    BigInteger temp =
        BigInteger.valueOf((Utils.compareUnsigned(zMiddleA.longValue(), zMiddleB.longValue()) ? 1L
            : 0L) << 32);
    temp = temp.add(zMiddleA.shiftRight(32).and(BigInteger.valueOf(0xffffffffL)));
    z0 = z0.add(temp);
    zMiddleA = zMiddleA.shiftLeft(32);
    z1 = z1.add(zMiddleA);

    temp =
        BigInteger.valueOf((Utils.compareUnsigned(z1.longValue(), zMiddleA.longValue())) ? 1L : 0L);
    z0 = z0.add(temp);

    List<Long> list = new ArrayList<Long>();
    list.add(z0.longValue()); // z0Ptr bits64
    list.add(z1.longValue()); // z1Ptr bits64
    return list;
  }

  /**
   * Subtracts the 128-bit value formed by concatenating `b0' and `b1' from the 128-bit value formed
   * by concatenating `a0' and `a1'. Subtraction is modulo 2^128, so any borrow out (carry out) is
   * lost. The result is broken into two 64-bit pieces which are stored at the locations pointed to
   * by `z0Ptr' and `z1Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param b0 bits64
   * @param b1 bits64
   * 
   * @return list
   */
  public static List<Long> sub128(final long a0, final long a1, final long b0, final long b1) {
    BigInteger a0BigInt, b0BigInt, z0PtrB;
    BigInteger a1BigInt, b1BigInt, z1PtrB;

    a0BigInt = BigInteger.valueOf(a0);
    b0BigInt = BigInteger.valueOf(b0 + (Utils.compareUnsigned(a1, b1) ? 1 : 0));

    a1BigInt = BigInteger.valueOf(a1);
    b1BigInt = BigInteger.valueOf(b1);

    // z1Ptr = a1 - b1;
    z1PtrB = a1BigInt.subtract(b1BigInt);
    // a0 - b0 - (compareUnsigned(a1, b1) ? 1 : 0);
    z0PtrB = a0BigInt.subtract(b0BigInt);

    List<Long> list = new ArrayList<Long>();
    list.add(z0PtrB.longValue()); // z0Ptr bits64
    list.add(z1PtrB.longValue()); // z1Ptr bits64
    return list;
  }

  /**
   * Returns an approximation to the square root of the 32-bit significand given by `a'. Considered
   * as an integer, `a' must be at least 2^31. If bit 0 of `aExp' (the least significant bit) is 1,
   * the integer returned approximates 2^31*sqrt(`a'/2^31), where `a' is considered an integer. If
   * bit 0 of `aExp' is 0, the integer returned approximates 2^31*sqrt(`a'/2^30). In either case,
   * the approximation returned lies strictly within +/-2 of the exact value.
   * 
   * @param aExp int16
   * @param a bits32
   * 
   * @return bits32
   */
  static int estimateSqrt32(short aExp, int a) {
    final short sqrtOddAdjustments[] =
        {0x0004, 0x0022, 0x005D, 0x00B1, 0x011D, 0x019F, 0x0236, 0x02E0, 0x039C, 0x0468, 0x0545,
            0x0631, 0x072B, 0x0832, 0x0946, 0x0A67};
    final short sqrtEvenAdjustments[] =
        {0x0A2D, 0x08AF, 0x075A, 0x0629, 0x051A, 0x0429, 0x0356, 0x029E, 0x0200, 0x0179, 0x0109,
            0x00AF, 0x0068, 0x0034, 0x0012, 0x0002};
    byte index; // int 8
    // int z; // bits32
    index = (byte) ((a >>> 27) & 15);

    BigInteger aBigInteger = Utils.getUnsignedBigInteger(a);
    BigInteger zBigInteger = BigInteger.ZERO;

    if ((aExp & 1) != 0) {
      // z = 0x4000 + (a >>> 17) - sqrtOddAdjustments[index];
      zBigInteger =
          zBigInteger.add(Utils.getUnsignedBigInteger(0x4000)).add(aBigInteger.shiftRight(17))
              .subtract(Utils.getUnsignedBigInteger(sqrtOddAdjustments[index]));
      // z = ((a / z) << 14) + (z << 15);
      zBigInteger = aBigInteger.divide(zBigInteger).shiftLeft(14).add(zBigInteger.shiftLeft(15));
      // a >>>= 1;
      aBigInteger = aBigInteger.shiftRight(1);
      // z = zBigInteger.intValue();
    } else {
      // z = 0x8000 + (a >>> 17) - sqrtEvenAdjustments[index];
      zBigInteger =
          zBigInteger.add(Utils.getUnsignedBigInteger(0x8000)).add(aBigInteger.shiftRight(17))
              .subtract(Utils.getUnsignedBigInteger(sqrtEvenAdjustments[index]));
      // z = a / z + z;
      zBigInteger = aBigInteger.divide(zBigInteger).add(zBigInteger);
      // z = (0x20000 <= z) ? 0xFFFF8000 : (z << 15);
      zBigInteger =
          (Utils.compareUnsigned(0x20000, zBigInteger.intValue()) || 0x20000 == zBigInteger
              .intValue()) ? BigInteger.valueOf(0xFFFF8000) : (zBigInteger.shiftLeft(15));
      // if ( z <= a )
      if (Utils.compareUnsigned(zBigInteger.intValue(), aBigInteger.intValue())
          || zBigInteger.intValue() == aBigInteger.intValue()) {
        // return (int) (a >> 1); // >> not ">>>", a - cost sbits32
        return aBigInteger.shiftRight(1).or(aBigInteger.and(Utils.SIGNED_BIT_32)).intValue();
      }
    }
    // return ((int) ((((long) a) << 31) / z)) + (z >>> 1);
    return aBigInteger.shiftLeft(31).divide(zBigInteger).add(zBigInteger.shiftRight(1)).intValue();
  }

  /**
   * Shifts the 128-bit value formed by concatenating `a0' and `a1' right by the number of bits
   * given in `count'. If any nonzero bits are shifted off, they are ``jammed'' into the least
   * significant bit of the result by setting the least significant bit to 1. The value of `count'
   * can be arbitrarily large; in particular, if `count' is greater than 128, the result will be
   * either 0 or 1, depending on whether the concatenation of `a0' and `a1' is zero or nonzero. The
   * result is broken into two 64-bit pieces which are stored at the locations pointed to by `z0Ptr'
   * and `z1Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param count int16
   * 
   * @return list{z0Ptr, z1Ptr}
   */
  public static List<Long> shift128RightJamming(long a0, long a1, short count) {
    long z0, z1; // bits64
    byte negCount = (byte) ((-count) & 63); // int8

    if (count == 0) {
      z1 = a1;
      z0 = a0;
    } else if (count < 64) {
      z1 = (a0 << negCount) | (a1 >>> count) | ((a1 << negCount) != 0 ? 1 : 0);
      z0 = a0 >>> count;
    } else {
      if (count == 64) {
        z1 = a0 | (a1 != 0 ? 1 : 0);
      } else if (count < 128) {
        z1 = (a0 >>> (count & 63)) | (((a0 << negCount) | a1) != 0 ? 1 : 0);
      } else {
        z1 = ((a0 | a1) != 0 ? 1 : 0);
      }
      z0 = 0;
    }

    List<Long> list = new ArrayList<Long>();
    list.add(z0); // z0Ptr bits64
    list.add(z1); // z1Ptr bits64
    return list;
  }

  /**
   * Returns 1 if the 128-bit value formed by concatenating `a0' and `a1' is less than or equal to
   * the 128-bit value formed by concatenating `b0' and `b1'. Otherwise, returns 0.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param b0 bits64
   * @param b1 bits64
   * 
   * @return flag
   */
  public static boolean le128(final long a0, final long a1, final long b0, final long b1) {
    return (Utils.compareUnsigned(a0, b0) || ((a0 == b0) && (Utils.compareUnsigned(a1, b1) || (a1 == b1))));
  }

  /**
   * Returns 1 if the 128-bit value formed by concatenating `a0' and `a1' is not equal to the
   * 128-bit value formed by concatenating `b0' and `b1'. Otherwise, returns 0.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param b0 bits64
   * @param b1 bits64
   * 
   * @return flag
   */
  public static boolean ne128(final long a0, final long a1, final long b0, final long b1) {
    return (a0 != b0) || (a1 != b1);
  }


  /**
   * Subtracts the 192-bit value formed by concatenating `b0', `b1', and `b2' from the 192-bit value
   * formed by concatenating `a0', `a1', and `a2'. Subtraction is modulo 2^192, so any borrow out
   * (carry out) is lost. The result is broken into three 64-bit pieces which are stored at the
   * locations pointed to by `z0Ptr', `z1Ptr', and `z2Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param a2 bits64
   * @param b0 bits64
   * @param b1 bits64
   * @param b2 bits64
   * 
   * @return list{z0Ptr, z1Ptr, z2Ptr}
   */
  public static List<Long> sub192(final long a0, final long a1, final long a2, final long b0,
      final long b1, final long b2) {
    long z0, z1, z2; // bits64
    byte borrow0, borrow1; // int8

    z2 = a2 - b2;
    borrow1 = (byte) ((a2 < b2) ? 1 : 0);
    z1 = a1 - b1;
    borrow0 = (byte) ((a1 < b1) ? 1 : 0);
    z0 = a0 - b0;
    z0 -= (z1 < borrow1) ? 1 : 0;
    z1 -= borrow1;
    z0 -= borrow0;

    List<Long> list = new ArrayList<Long>();
    list.add(z0);
    list.add(z1);
    list.add(z2);
    return list;
  }

  /**
   * Adds the 192-bit value formed by concatenating `a0', `a1', and `a2' to the 192-bit value formed
   * by concatenating `b0', `b1', and `b2'. Addition is modulo 2^192, so any carry out is lost. The
   * result is broken into three 64-bit pieces which are stored at the locations pointed to by
   * `z0Ptr', `z1Ptr', and `z2Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param a2 bits64
   * @param b0 bits64
   * @param b1 bits64
   * @param b2 bits64
   * 
   * @return list{z0Ptr, z1Ptr, z2Ptr}
   */
  public static List<Long> add192(final long a0, final long a1, final long a2, final long b0,
      final long b1, final long b2) {
    long z0, z1, z2; // bits64
    byte carry0, carry1; // int8

    z2 = a2 + b2;
    carry1 = (byte) ((z2 < a2) ? 1 : 0);
    z1 = a1 + b1;
    carry0 = (byte) ((z1 < a1) ? 1 : 0);
    z0 = a0 + b0;
    z1 += carry1;
    z0 += (z1 < carry1) ? 1 : 0;
    z0 += carry0;

    List<Long> list = new ArrayList<Long>();
    list.add(z0);
    list.add(z1);
    list.add(z2);
    return list;
  }

  /**
   * Returns 1 if the quadruple-precision floating-point value `a' is a signaling NaN; otherwise
   * returns 0.
   * 
   * @param a float128
   * 
   * @return flag
   */
  public static boolean float128_is_signaling_nan(final Float128 a) {
    return (((a.high >>> 47) & 0xFFFF) == 0xFFFE)
        && (a.low != 0 || (a.high & 0x00007FFFFFFFFFFFL) != 0);
  }

  /**
   * Returns 1 if the quadruple-precision floating-point value `a' is a NaN; otherwise returns 0.
   * 
   * @param a float128
   * 
   * @return flag
   */
  public static boolean float128_is_nan(final Float128 a) {
    return (0xFFFE000000000000L <= (a.high << 1))
        && (a.low != 0 || (a.high & 0x0000FFFFFFFFFFFFL) != 0);
  }

  /**
   * Multiplies the 128-bit value formed by concatenating `a0' and `a1' to the 128-bit value formed
   * by concatenating `b0' and `b1' to obtain a 256-bit product. The product is broken into four
   * 64-bit pieces which are stored at the locations pointed to by `z0Ptr', `z1Ptr', `z2Ptr', and
   * `z3Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param b0 bits64
   * @param b1 bits64
   * 
   * @return list{z0Ptr, z1Ptr, z2Ptr, z3Ptr}
   */
  public static List<Long> mul128To256(final long a0, final long a1, final long b0, final long b1) {
    long z0 = 0, z1 = 0, z2 = 0, z3 = 0; // bits64
    long more1 = 0, more2 = 0; // bits64

    List<Long> list1 = mul64To128(a1, b1);// , z2, z3);
    z2 = list1.get(0);
    z3 = list1.get(1);

    List<Long> list2 = mul64To128(a1, b0);// , z1, more2);
    z1 = list2.get(0);
    more2 = list2.get(1);

    List<Long> list3 = add128(z1, more2, 0, z2); // , z1, z2);
    z1 = list3.get(0);
    z2 = list3.get(1);

    List<Long> list4 = mul64To128(a0, b0);// , z0, more1);
    z0 = list4.get(0);
    more1 = list4.get(1);

    List<Long> list5 = add128(z0, more1, 0, z1); // , z0, z1);
    z0 = list5.get(0);
    z1 = list5.get(1);

    List<Long> list6 = mul64To128(a0, b1);// , more1, more2);
    more1 = list6.get(0);
    more2 = list6.get(1);

    List<Long> list7 = add128(more1, more2, 0, z2); // , more1, z2);
    more1 = list7.get(0);
    z2 = list7.get(1);

    List<Long> list8 = add128(z0, z1, 0, more1); // , z0, z1);
    z0 = list8.get(0);
    z1 = list8.get(1);

    List<Long> list = new ArrayList<Long>();
    list.add(z0);
    list.add(z1);
    list.add(z2);
    list.add(z3);
    return list;
  }

  /**
   * Multiplies the 128-bit value formed by concatenating `a0' and `a1' by `b' to obtain a 192-bit
   * product. The product is broken into three 64-bit pieces which are stored at the locations
   * pointed to by `z0Ptr', `z1Ptr', and `z2Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param b bits64
   * 
   * @return list{z0Ptr, z1Ptr, z2Ptr}
   */
  public static List<Long> mul128By64To192(final long a0, final long a1, final long b) {
    long z0 = 0, z1 = 0, z2 = 0, more1 = 0; // bits64

    List<Long> list0 = mul64To128(a1, b);// , z1, z2);
    z1 = list0.get(0);
    z2 = list0.get(1);

    List<Long> list1 = mul64To128(a0, b);// , z0, more1);
    z0 = list1.get(0);
    more1 = list1.get(1);

    List<Long> list2 = add128(z0, more1, 0, z1); // , z0, z1);
    z0 = list2.get(0);
    z1 = list2.get(1);

    List<Long> list = new ArrayList<Long>();
    list.add(z0);
    list.add(z1);
    list.add(z2);
    return list;
  }

  /**
   * Shifts the 192-bit value formed by concatenating `a0', `a1', and `a2' left by the number of
   * bits given in `count'. Any bits shifted off are lost. The value of `count' must be less than
   * 64. The result is broken into three 64-bit pieces which are stored at the locations pointed to
   * by `z0Ptr', `z1Ptr', and `z2Ptr'.
   * 
   * @param a0 bits64
   * @param a1 bits64
   * @param a2 bits64
   * @param count int16
   * 
   * @return list{z0Ptr, z1Ptr, z2Ptr}
   */
  public static List<Long> shortShift192Left(final long a0, final long a1, final long a2,
      final long count) {
    long z0, z1, z2; // bits64
    byte negCount; // int8

    z2 = a2 << count;
    z1 = a1 << count;
    z0 = a0 << count;
    if (0 < count) {
      negCount = (byte) ((-count) & 63);
      z1 |= a2 >>> negCount;
      z0 |= a1 >>> negCount;
    }

    List<Long> list = new ArrayList<Long>();
    list.add(z0);
    list.add(z1);
    list.add(z2);
    return list;
  }
}
