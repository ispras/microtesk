package ru.ispras.softfloat;

import java.util.ArrayList;
import java.util.Random;

import org.junit.Test;

import ru.ispras.softfloat.JSoftFloat;
import ru.ispras.softfloat.jni.CSoftFloat;

/**
 * Tests for jsoftfloat (vs original softfloat)
 * 
 * @author <a href="mailto:protsenko@ispras.ru">Alexander Protsenko</a>
 */
public class SoftfloatTestCase {

  private static final int ARRAY_RANDOM_SIZE = 100;

  private static final boolean PRINT_TESTS_NUMBER = true;
  private static final boolean RUN_LONGTIME_TESTS = false;

  private static final Random rand = new Random();

  private static final ArrayList<Double> doubleArray = new ArrayList<Double>();
  private static final ArrayList<Float> floatArray = new ArrayList<Float>();

  private static void initTestArray() {
    // Init array of double values
    doubleArray.add(Double.NaN);
    doubleArray.add(Double.NEGATIVE_INFINITY);
    doubleArray.add(Double.POSITIVE_INFINITY);
    doubleArray.add(Double.MAX_VALUE);
    doubleArray.add(Double.MIN_VALUE);
    doubleArray.add(Double.MIN_NORMAL);
    doubleArray.add(Double.longBitsToDouble(-1));
    doubleArray.add(Double.longBitsToDouble(0));
    doubleArray.add(Double.longBitsToDouble(1));
    doubleArray.add(Double.longBitsToDouble(0x7facb75a00000000L)); // NaN
    doubleArray.add(Double.longBitsToDouble(0x7fe0000000000000L));

    for (int i = 0; i < ARRAY_RANDOM_SIZE; i++)
      doubleArray.add(Double.longBitsToDouble(rand.nextLong()));

    // Init array of float values
    floatArray.add(Float.NaN);
    floatArray.add(Float.NEGATIVE_INFINITY);
    floatArray.add(Float.POSITIVE_INFINITY);
    floatArray.add(Float.MAX_VALUE);
    floatArray.add(Float.MIN_VALUE);
    floatArray.add(Float.MIN_NORMAL);
    floatArray.add(Float.intBitsToFloat(-1));
    floatArray.add(Float.intBitsToFloat(0));
    floatArray.add(Float.intBitsToFloat(1));
    floatArray.add(Float.intBitsToFloat(0x7facb75a)); // NaN
    floatArray.add(Float.intBitsToFloat(0xff000000));
    for (int i = 0; i < ARRAY_RANDOM_SIZE; i++)
      floatArray.add(Float.intBitsToFloat(rand.nextInt()));
  }

  private static double getDoubleValue(final int i) {
    return doubleArray.get(i);
  }

  private static long getLongValue(final int i) {
    return Double.doubleToRawLongBits(doubleArray.get(i));
  }

  private static float getFloatValue(final int i) {
    return floatArray.get(i);
  }

  private static int getIntValue(final int i) {
    return Float.floatToRawIntBits(floatArray.get(i));
  }

  private static short getShortValue(final int i) {
    return (short) (0xffff & Float.floatToRawIntBits(floatArray.get(i)));
  }

  @SuppressWarnings("unused")
  private static void packFloat32Test(final boolean zSign, final short zExp, final int zSig) {
    System.out.println("packFloat32Test");
    final float float32 = JSoftFloat.packFloat32(zSign, zExp, zSig);
    System.out.println(float32 + " , Binary = "
        + Integer.toBinaryString(Float.floatToRawIntBits(float32)));
  }

  @SuppressWarnings("unused")
  private static void normalizeRoundAndPackFloat32Test(final boolean zSign, final short zExp,
      final int zSig) {
    System.out.println("normalizeRoundAndPackFloat32");
    final float float32 = JSoftFloat.roundAndPackFloat32(true, (short) 1, 1);
    // float float32_2 = SoftFloatJniWrapper.roundAndPackFloat32(true,(short) 1, 1);

    System.out.println(float32 + " , Hex = 0x"
        + Integer.toBinaryString(Float.floatToRawIntBits(float32)));
  }

  /*
   * Branch test: floatX to intX, intX to floatX
   */

  private static void int32ToFloat32Test(final int inputValue) {
    System.out.print("int32ToFloat32Test InputValue = " + inputValue);

    final float temp = JSoftFloat.int32_to_float32(inputValue);
    final float temp2 = CSoftFloat.int_to_float(inputValue);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));
    if (temp != temp2) {
      System.out.println("J vs C: " + Integer.toHexString(Float.floatToRawIntBits(temp)) + " == "
          + Integer.toHexString(Float.floatToRawIntBits(temp2)));
      System.out.println("J vs C: " + Integer.toBinaryString(Float.floatToRawIntBits(temp)) + " == "
          + Integer.toBinaryString(Float.floatToRawIntBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void int32ToFloat64Test(final int inputValue) {
    System.out.print("int32ToFloat64Test InputValue = " + inputValue);

    final double temp = JSoftFloat.int32_to_float64(inputValue);
    final double temp2 = CSoftFloat.int_to_double(inputValue);
    System.out.println("J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64ToInt32Test(final double inputValue) {
    System.out.print("float64ToInt32Test InputValue = " + inputValue);

    final int temp = JSoftFloat.float64_to_int32(inputValue);
    final int temp2 = CSoftFloat.double_to_int(inputValue);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64ToInt64Test(final double inputValue) {
    System.out.print("float64ToInt64Test InputValue = " + inputValue);

    final long temp = JSoftFloat.float64_to_int64(inputValue);
    final long temp2 = CSoftFloat.double_to_long(inputValue);
    System.out.println("J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32ToInt32Test(final float inputValue) {
    System.out.print("float32ToInt32Test InputValue = " + inputValue + " = 0x"
        + Integer.toHexString(Float.floatToRawIntBits(inputValue)));

    final int temp = JSoftFloat.float32_to_int32(inputValue);
    final int temp2 = CSoftFloat.float_to_int(inputValue);
    System.out.println("J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      System.out.println("J vs C: " + Integer.toHexString(temp) + " == "
          + Integer.toHexString(temp2));
      System.out.println("J vs C: " + Integer.toBinaryString(temp) + " == "
          + Integer.toBinaryString(temp2));

      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32ToInt64Test(final float inputValue) {
    System.out.print("float32ToInt64Test InputValue = " + inputValue + " = 0x"
        + Integer.toHexString(Float.floatToRawIntBits(inputValue)));

    final long temp = JSoftFloat.float32_to_int64(inputValue);
    final long temp2 = CSoftFloat.float_to_long(inputValue);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      System.out.println("J vs C: " + Long.toHexString(temp) + " == " + Long.toHexString(temp2));
      System.out.println("J vs C: " + Long.toBinaryString(temp) + " == "
          + Long.toBinaryString(temp2));

      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void int64ToFloat32Test(final long inputValue) {
    System.out.print("int64ToFloat32Test InputValue = " + inputValue);

    final float temp = JSoftFloat.int64_to_float32(inputValue);
    final float temp2 = CSoftFloat.long_to_float(inputValue);
    System.out.println("J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void int64ToFloat64Test(final long inputValue) {
    System.out.print("int64ToFloat64Test InputValue = " + inputValue);

    final double temp = JSoftFloat.int64_to_float64(inputValue);
    final double temp2 = CSoftFloat.long_to_double(inputValue);
    System.out.println("J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64ToFloat32Test(final double inputValue) {
    System.out.print("float64ToFloat32Test InputValue = " + inputValue + " = 0x"
        + Long.toHexString(Double.doubleToRawLongBits(inputValue)));

    final float temp = JSoftFloat.float64_to_float32(inputValue);
    final float temp2 = CSoftFloat.double_to_float(inputValue);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (Float.floatToRawIntBits(temp) != Float.floatToRawIntBits(temp2)) {
      System.out.println("J vs C: " + Integer.toHexString(Float.floatToRawIntBits(temp)) + " == "
          + Integer.toHexString(Float.floatToRawIntBits(temp2)));
      System.out.println("J vs C: " + Integer.toBinaryString(Float.floatToRawIntBits(temp)) + " == "
          + Integer.toBinaryString(Float.floatToRawIntBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  /*
   * Branch test: Round To Zero
   */

  private static void float32ToInt32RoundToZeroTest(final float inputValue) {
    System.out.print("float32ToInt32RoundToZeroTest value = " + inputValue);

    final int temp = JSoftFloat.float32_to_int32_round_to_zero(inputValue);
    final int temp2 = CSoftFloat.float_to_int_round_to_zero(inputValue);
    System.out.println("J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32ToInt64RoundToZeroTest(final float inputValue) {
    System.out.print("float32ToInt64RoundToZeroTest value = " + inputValue);

    final long temp = JSoftFloat.float32_to_int64_round_to_zero(inputValue);
    final long temp2 = CSoftFloat.float_to_long_round_to_zero(inputValue);
    System.out.println("J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64ToInt32RoundToZeroTest(final double inputValue) {
    System.out.print("float64ToInt32RoundToZeroTest value = " + inputValue);

    final int temp = JSoftFloat.float64_to_int32_round_to_zero(inputValue);
    final int temp2 = CSoftFloat.double_to_int_round_to_zero(inputValue);
    System.out.println("J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64ToInt64RoundToZeroTest(final double inputValue) {
    System.out.print("float64ToInt64RoundToZeroTest value = " + inputValue);

    final long temp = JSoftFloat.float64_to_int64_round_to_zero(inputValue);
    final long temp2 = CSoftFloat.double_to_long_round_to_zero(inputValue);
    System.out.println("J vs C: " + temp + " == " + temp2 + " - " + (temp == temp2));

    if (temp != temp2) {
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  /*
   * Branch test: arithmetic
   */

  /*
   * Test for float32_add(float,float)
   */
  private static void float32AddTest(final float a, final float b) {
    System.out.print("float32AddTest a = " + a + ", b = " + b);

    final float temp = JSoftFloat.float32_add(a, b);
    final float temp2 = CSoftFloat.float_add(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + (Float.floatToRawIntBits(temp) == Float.floatToRawIntBits(temp2)));

    if (Float.floatToRawIntBits(temp) != Float.floatToRawIntBits(temp2)) {
      System.out.println("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)) + ", b = 0x"
          + Integer.toHexString(Float.floatToRawIntBits(b)));
      System.out.println("J vs C: 0x" + Integer.toHexString(Float.floatToRawIntBits(temp)) + " == 0x"
          + Integer.toHexString(Float.floatToRawIntBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32SubTest(final float a, final float b) {
    System.out.print("float32SubTest a = " + a + ", b = " + b);

    final float temp = JSoftFloat.float32_sub(a, b);
    final float temp2 = CSoftFloat.float_sub(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + (Float.floatToRawIntBits(temp) == Float.floatToRawIntBits(temp2)));

    if (Float.floatToRawIntBits(temp) != Float.floatToRawIntBits(temp2)) {
      System.out.println("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)) + ", b = 0x"
          + Integer.toHexString(Float.floatToRawIntBits(b)));
      System.out.println("J vs C: 0x" + Integer.toHexString(Float.floatToRawIntBits(temp)) + " == 0x"
          + Integer.toHexString(Float.floatToRawIntBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32MulTest(final float a, final float b) {
    System.out.print("float32MulTest a = " + a + ", b = " + b);

    final float temp = JSoftFloat.float32_mul(a, b);
    final float temp2 = CSoftFloat.float_mul(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + (Float.floatToRawIntBits(temp) == Float.floatToRawIntBits(temp2)));

    if (Float.floatToRawIntBits(temp) != Float.floatToRawIntBits(temp2)) {
      System.out.println("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)) + ", b = 0x"
          + Integer.toHexString(Float.floatToRawIntBits(b)));
      System.out.println("J vs C: 0x" + Integer.toHexString(Float.floatToRawIntBits(temp)) + " == 0x"
          + Integer.toHexString(Float.floatToRawIntBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32DivTest(final float a, final float b) {
    System.out.print("float32DivTest a = " + a + ", b = " + b);

    float temp = JSoftFloat.float32_div(a, b);
    float temp2 = CSoftFloat.float_div(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + (Float.floatToRawIntBits(temp) == Float.floatToRawIntBits(temp2)));

    if (Float.floatToRawIntBits(temp) != Float.floatToRawIntBits(temp2)) {
      System.out.println("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)) + ", b = 0x"
          + Integer.toHexString(Float.floatToRawIntBits(b)));
      System.out.println("J vs C: 0x" + Integer.toHexString(Float.floatToRawIntBits(temp)) + " == 0x"
          + Integer.toHexString(Float.floatToRawIntBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32RemTest(final float a, final float b) {
    System.out.print("float32RemTest a = " + a + ", b = " + b);

    float temp = JSoftFloat.float32_rem(a, b);
    float temp2 = CSoftFloat.float_rem(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + (Float.floatToRawIntBits(temp) == Float.floatToRawIntBits(temp2)));

    if (Float.floatToRawIntBits(temp) != Float.floatToRawIntBits(temp2)) {
      System.out.println("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)) + ", b = 0x"
          + Integer.toHexString(Float.floatToRawIntBits(b)));
      System.out.println("Result J vs C: 0x" + Integer.toHexString(Float.floatToRawIntBits(temp))
          + " == 0x" + Integer.toHexString(Float.floatToRawIntBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32SqrtTest(final float a) {
    System.out.print("float32SqrtTest a = " + a + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));

    float temp = JSoftFloat.float32_sqrt(a);
    float temp2 = CSoftFloat.float_sqrt(a);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + (Float.floatToRawIntBits(temp) == Float.floatToRawIntBits(temp2)));

    if (Float.floatToRawIntBits(temp) != Float.floatToRawIntBits(temp2)) {
      System.out.println("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
      System.out.println("Result J vs C: 0x" + Integer.toHexString(Float.floatToRawIntBits(temp))
          + " == 0x" + Integer.toHexString(Float.floatToRawIntBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32EqTest(final float a, final float b) {
    System.out.print("float32EqTest a = " + a + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
    System.out.print(", b = " + b + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));

    boolean temp = JSoftFloat.float32_eq(a, b);
    boolean temp2 = CSoftFloat.float_eq(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.print("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
      System.out.println(", b = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32LeTest(final float a, final float b) {
    System.out.print("float32LeTest a = " + a + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
    System.out.print(", b = " + b + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));

    boolean temp = JSoftFloat.float32_le(a, b);
    boolean temp2 = CSoftFloat.float_le(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.print("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
      System.out.println(", b = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32LtTest(final float a, final float b) {
    System.out.print("float32LtTest a = " + a + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
    System.out.print(", b = " + b + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));

    boolean temp = JSoftFloat.float32_lt(a, b);
    boolean temp2 = CSoftFloat.float_lt(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.print("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
      System.out.println(", b = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32EqSignalingTest(final float a, final float b) {
    System.out.print("float32EqSignalingTest a = " + a + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
    System.out.print(", b = " + b + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));

    boolean temp = JSoftFloat.float32_eq_signaling(a, b);
    boolean temp2 = CSoftFloat.float_eq_signaling(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.print("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
      System.out.println(", b = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32LeQuietTest(final float a, final float b) {
    System.out.print("float32LeQuietTest a = " + a + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
    System.out.print(", b = " + b + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));

    boolean temp = JSoftFloat.float32_le_quiet(a, b);
    boolean temp2 = CSoftFloat.float_le_quiet(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.print("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
      System.out.println(", b = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32LtQuietTest(final float a, final float b) {
    System.out.print("float32LtQuietTest a = " + a + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
    System.out.print(", b = " + b + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));

    boolean temp = JSoftFloat.float32_lt_quiet(a, b);
    boolean temp2 = CSoftFloat.float_lt_quiet(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.print("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
      System.out.println(", b = 0x" + Integer.toHexString(Float.floatToRawIntBits(b)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float32IsSignalingNanTest(final float a) {
    System.out.print("float32IsSignalingNanTest a = " + a + " = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));

    boolean temp = JSoftFloat.float32_is_signaling_nan(a);
    boolean temp2 = CSoftFloat.float_is_signaling_nan(a);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.print("a = 0x" + Integer.toHexString(Float.floatToRawIntBits(a)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  /* 64 */
  private static void float64AddTest(final double a, final double b) {
    System.out.print("float64AddTest a = " + a + ", b = " + b);

    double temp = JSoftFloat.float64_add(a, b);
    double temp2 = CSoftFloat.double_add(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + Long.toHexString(Double.doubleToRawLongBits(temp)) + "=="
        + Long.toHexString(Double.doubleToRawLongBits(temp2)));

    if (Double.doubleToRawLongBits(temp) != Double.doubleToRawLongBits(temp2)) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: 0x" + Long.toHexString(Double.doubleToRawLongBits(temp)) + " == 0x"
          + Long.toHexString(Double.doubleToRawLongBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64SubTest(final double a, final double b) {
    System.out.print("float64SubTest a = " + a + ", b = " + b);

    double temp = JSoftFloat.float64_sub(a, b);
    double temp2 = CSoftFloat.double_sub(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + Long.toHexString(Double.doubleToRawLongBits(temp)) + "=="
        + Long.toHexString(Double.doubleToRawLongBits(temp2)));

    if (Double.doubleToRawLongBits(temp) != Double.doubleToRawLongBits(temp2)) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: 0x" + Long.toHexString(Double.doubleToRawLongBits(temp)) + " == 0x"
          + Long.toHexString(Double.doubleToRawLongBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64MulTest(final double a, final double b) {
    System.out.print("float64MulTest a = " + a + ", b = " + b);

    double temp = JSoftFloat.float64_mul(a, b);
    double temp2 = CSoftFloat.double_mul(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + Long.toHexString(Double.doubleToRawLongBits(temp)) + "=="
        + Long.toHexString(Double.doubleToRawLongBits(temp2)));

    if (Double.doubleToRawLongBits(temp) != Double.doubleToRawLongBits(temp2)) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: 0x" + Long.toBinaryString(Double.doubleToRawLongBits(temp))
          + " == 0x" + Long.toBinaryString(Double.doubleToRawLongBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64DivTest(final double a, final double b) {
    System.out.print("float64DivTest a = " + a + ", b = " + b);

    double temp = JSoftFloat.float64_div(a, b);
    double temp2 = CSoftFloat.double_div(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + Long.toHexString(Double.doubleToRawLongBits(temp)) + "=="
        + Long.toHexString(Double.doubleToRawLongBits(temp2)));

    if (Double.doubleToRawLongBits(temp) != Double.doubleToRawLongBits(temp2)) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: 0x" + Long.toBinaryString(Double.doubleToRawLongBits(temp))
          + " == 0x" + Long.toBinaryString(Double.doubleToRawLongBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64RemTest(final double a, final double b) {
    System.out.print("float64RemTest a = " + a + ", b = " + b);

    double temp = JSoftFloat.float64_rem(a, b);
    double temp2 = CSoftFloat.double_rem(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + Long.toHexString(Double.doubleToRawLongBits(temp)) + "=="
        + Long.toHexString(Double.doubleToRawLongBits(temp2)));

    if (Double.doubleToRawLongBits(temp) != Double.doubleToRawLongBits(temp2)) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: 0x" + Long.toBinaryString(Double.doubleToRawLongBits(temp))
          + " == 0x" + Long.toBinaryString(Double.doubleToRawLongBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64SqrtTest(final double a) {
    System.out.print("float64SqrtTest a = " + a);

    double temp = JSoftFloat.float64_sqrt(a);
    double temp2 = CSoftFloat.double_sqrt(a);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - "
        + Long.toHexString(Double.doubleToRawLongBits(temp)) + "=="
        + Long.toHexString(Double.doubleToRawLongBits(temp2)));

    if (Double.doubleToRawLongBits(temp) != Double.doubleToRawLongBits(temp2)) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)));

      System.out.println("J vs C: 0x" + Long.toBinaryString(Double.doubleToRawLongBits(temp))
          + " == 0x" + Long.toBinaryString(Double.doubleToRawLongBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64EqTest(final double a, final double b) {
    System.out.print("float64EqTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float64_eq(a, b);
    boolean temp2 = CSoftFloat.double_eq(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64LeTest(final double a, final double b) {
    System.out.print("float64LeTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float64_le(a, b);
    boolean temp2 = CSoftFloat.double_le(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64LtTest(final double a, final double b) {
    System.out.print("float64LtTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float64_lt(a, b);
    boolean temp2 = CSoftFloat.double_lt(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64EqSignalingTest(final double a, final double b) {
    System.out.print("float64EqSignalingTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float64_eq_signaling(a, b);
    boolean temp2 = CSoftFloat.double_eq_signaling(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64LtQuietTest(final double a, final double b) {
    System.out.print("float64LtQuietTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float64_lt_quiet(a, b);
    boolean temp2 = CSoftFloat.double_lt_quiet(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64LeQuietTest(final double a, final double b) {
    System.out.print("float64LeQuietTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float64_le_quiet(a, b);
    boolean temp2 = CSoftFloat.double_le_quiet(a, b);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)) + ", b = 0x"
          + Long.toHexString(Double.doubleToRawLongBits(b)));
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float64IsSignalingNanTest(final double a) {
    System.out.print("float64IsSignalingNanTest a = " + a);

    boolean temp = JSoftFloat.float64_is_signaling_nan(a);
    boolean temp2 = CSoftFloat.double_is_signaling_nan(a);
    System.out.println(" J vs C: " + temp + " == " + temp2 + " - " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + Long.toHexString(Double.doubleToRawLongBits(a)));
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  // Floatx80

  private static void floatx80ToInt32Test(final FloatX80 a) {
    System.out.print("floatx80ToIntTest a = " + a);

    int temp = JSoftFloat.floatx80_to_int32(a);
    int temp2 = CSoftFloat.floatx80_to_int(a);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void floatx80ToInt32RoundToZeroTest(final FloatX80 a) {
    System.out.print("floatx80ToIntRoundToZeroTest a = " + a);

    int temp = JSoftFloat.floatx80_to_int32_round_to_zero(a);
    int temp2 = CSoftFloat.floatx80_to_int_round_to_zero(a);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }
  
  private static void floatx80ToInt64Test(final FloatX80 a) {
    System.out.print("floatx80ToLongTest a = " + a);

    long temp = JSoftFloat.floatx80_to_int64(a);
    long temp2 = CSoftFloat.floatx80_to_long(a);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }
  
  private static void floatx80ToInt64RoundToZeroTest(final FloatX80 a) {
    System.out.print("floatx80ToInt64RoundToZeroTest a = " + a);

    long temp = JSoftFloat.floatx80_to_int64_round_to_zero(a);
    long temp2 = CSoftFloat.floatx80_to_long_round_to_zero(a);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }
  
  private static void floatx80ToFloat32Test(final FloatX80 a) {
    System.out.print("floatx80ToFloat32Test a = " + a);

    float temp = JSoftFloat.floatx80_to_float32(a);
    float temp2 = CSoftFloat.floatx80_to_float(a);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (Float.floatToRawIntBits(temp) != Float.floatToRawIntBits(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }
  
  private static void floatx80ToFloat64Test(final FloatX80 a) {
    System.out.print("floatx80ToFloat64Test a = " + a);

    double temp = JSoftFloat.floatx80_to_float64(a);
    double temp2 = CSoftFloat.floatx80_to_double(a);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (Double.doubleToRawLongBits(temp) != Double.doubleToRawLongBits(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + Long.toHexString(Double.doubleToRawLongBits(temp)) + " == " + Long.toHexString(Double.doubleToRawLongBits(temp2)));
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }
  
  private static void floatx80ToFloat128Test(final FloatX80 a) {
    System.out.print("floatx80ToFloat128Test a = " + a);

    Float128 temp = JSoftFloat.floatx80_to_float128(a);
    Float128 temp2 = CSoftFloat.floatx80_to_float128_c(a);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void floatx80RoundToInt32Test(final FloatX80 a) {
    System.out.print("floatx80RoundToInt32Test a = " + a);

    FloatX80 temp = JSoftFloat.floatx80_round_to_int(a);
    FloatX80 temp2 = CSoftFloat.floatx80_round_to_int_c(a);
    System.out.println(" J vs C: " + temp + " == " + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void floatx80AddTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80AddTest a = " + a + ", b = " + b);

    FloatX80 temp = JSoftFloat.floatx80_add(a, b);
    FloatX80 temp2 = CSoftFloat.floatx80_add_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void floatx80SubTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80SubTest a = " + a + ", b = " + b);

    FloatX80 temp = JSoftFloat.floatx80_sub(a, b);
    FloatX80 temp2 = CSoftFloat.floatx80_sub_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void floatx80MulTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80MulTest a = " + a + ", b = " + b);

    FloatX80 temp = JSoftFloat.floatx80_mul(a, b);
    FloatX80 temp2 = CSoftFloat.floatx80_mul_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void floatx80DivTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80DivTest a = " + a + ", b = " + b);

    FloatX80 temp = JSoftFloat.floatx80_div(a, b);
    FloatX80 temp2 = CSoftFloat.floatx80_div_c(a, b);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s, %s)", temp, temp2, a, b));
    }
  }

  private static void floatx80RemTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80RemTest a = " + a + ", b = " + b);

    FloatX80 temp = JSoftFloat.floatx80_rem(a, b);
    FloatX80 temp2 = CSoftFloat.floatx80_rem_c(a, b);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s, %s)", temp, temp2, a, b));
    }
  }
  
  private static void floatx80SqrtTest(final FloatX80 a) {
    System.out.print("floatx80SqrtTest a = " + a);

    FloatX80 temp = JSoftFloat.floatx80_sqrt(a);
    FloatX80 temp2 = CSoftFloat.floatx80_sqrt_c(a);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s)", temp, temp2, a));
    }
  }
  

  private static void floatx80EqTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80EqTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.floatx80_eq(a, b);
    boolean temp2 = CSoftFloat.floatx80_eq_c(a, b);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s, %s)", temp, temp2, a, b));
    }
  }

  private static void floatx80LeTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80LeTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.floatx80_le(a, b);
    boolean temp2 = CSoftFloat.floatx80_le_c(a, b);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s, %s)", temp, temp2, a, b));
    }
  }

  private static void floatx80LtTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80LtTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.floatx80_lt(a, b);
    boolean temp2 = CSoftFloat.floatx80_lt_c(a, b);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s, %s)", temp, temp2, a, b));
    }
  }

  private static void floatx80EqSignalingTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80EqSignalingTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.floatx80_eq_signaling(a, b);
    boolean temp2 = CSoftFloat.floatx80_eq_signaling_c(a, b);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s, %s)", temp, temp2, a, b));
    }
  }

  private static void floatx80LeQuietTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80LeQuietTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.floatx80_le_quiet(a, b);
    boolean temp2 = CSoftFloat.floatx80_le_quiet_c(a, b);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s, %s)", temp, temp2, a, b));
    }
  }

  private static void floatx80LtQuietTest(final FloatX80 a, final FloatX80 b) {
    System.out.print("floatx80LtQuietTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.floatx80_lt_quiet(a, b);
    boolean temp2 = CSoftFloat.floatx80_lt_quiet_c(a, b);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s, %s)", temp, temp2, a, b));
    }
  }

  private static void floatx80IsSignalingNaNTest(final FloatX80 a) {
    System.out.print("floatx80IsSignalingNaNTest a = " + a);

    boolean temp = JSoftFloat.floatx80_is_signaling_nan(a);
    boolean temp2 = CSoftFloat.floatx80_is_signaling_nan_c(a);
    System.out.println("1 J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s (input: %s, %s)", temp, temp2, a));
    }
  }
  
  // Float128
  

  private static void float128ToInt32Test(final Float128 a) {
    System.out.print("float128ToInt32Test a = " + a);

    int temp = JSoftFloat.float128_to_int32(a);
    int temp2 = CSoftFloat.float128_to_int(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128ToInt32RoundToZeroTest(final Float128 a) {
    System.out.print("float128ToInt32RoundToZeroTest a = " + a);

    int temp = JSoftFloat.float128_to_int32_round_to_zero(a);
    int temp2 = CSoftFloat.float128_to_int_round_to_zero(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128ToInt64Test(final Float128 a) {
    System.out.print("float128ToInt64Test a = " + a);

    long temp = JSoftFloat.float128_to_int64(a);
    long temp2 = CSoftFloat.float128_to_long(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128ToInt64RoundToZeroTest(final Float128 a) {
    System.out.print("float128ToInt64RoundToZeroTest a = " + a);

    long temp = JSoftFloat.float128_to_int64_round_to_zero(a);
    long temp2 = CSoftFloat.float128_to_long_round_to_zero(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128ToFloat32Test(final Float128 a) {
    System.out.print("float128ToFloat32Test a = " + a);

    float temp = JSoftFloat.float128_to_float32(a);
    float temp2 = CSoftFloat.float128_to_float(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (Float.floatToRawIntBits(temp) != Float.floatToRawIntBits(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128ToFloat64Test(final Float128 a) {
    System.out.print("float128ToFloat64Test a = " + a);

    double temp = JSoftFloat.float128_to_float64(a);
    double temp2 = CSoftFloat.float128_to_double(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (Double.doubleToRawLongBits(temp) != Double.doubleToRawLongBits(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128ToFloat80Test(final Float128 a) {
    System.out.print("float128ToFloat80Test a = " + a);

    FloatX80 temp = JSoftFloat.float128_to_floatx80(a);
    FloatX80 temp2 = CSoftFloat.float128_to_floatx80_c(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128RoundToIntTest(final Float128 a) {
    System.out.print("float128RoundToIntTest a = " + a);

    Float128 temp = JSoftFloat.float128_round_to_int(a);
    Float128 temp2 = CSoftFloat.float128_round_to_int_c(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128AddTest(final Float128 a, final Float128 b) {
    System.out.print("float128AddTest a = " + a + ", b = " + b);

    Float128 temp = JSoftFloat.float128_add(a, b);
    Float128 temp2 = CSoftFloat.float128_add_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128SubTest(final Float128 a, final Float128 b) {
    System.out.print("float128SubTest a = " + a + ", b = " + b);

    Float128 temp = JSoftFloat.float128_sub(a, b);
    Float128 temp2 = CSoftFloat.float128_sub_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128MulTest(final Float128 a, final Float128 b) {
    System.out.print("float128MulTest a = " + a + ", b = " + b);

    Float128 temp = JSoftFloat.float128_mul(a, b);
    Float128 temp2 = CSoftFloat.float128_mul_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128DivTest(final Float128 a, final Float128 b) {
    System.out.print("float128DivTest a = " + a + ", b = " + b);

    Float128 temp = JSoftFloat.float128_div(a, b);
    Float128 temp2 = CSoftFloat.float128_div_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128RemTest(final Float128 a, final Float128 b) {
    System.out.print("float128RemTest a = " + a + ", b = " + b);

    Float128 temp = JSoftFloat.float128_rem(a, b);
    Float128 temp2 = CSoftFloat.float128_rem_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s, a = %s, b = %s", temp, temp2, a, b));
    }
  }

  private static void float128SqrtTest(final Float128 a) {
    System.out.print("float128SqrtTest a = " + a);

    Float128 temp = JSoftFloat.float128_sqrt(a);
    Float128 temp2 = CSoftFloat.float128_sqrt_c(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (!temp.equals(temp2)) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128EqTest(final Float128 a, final Float128 b) {
    System.out.print("float128EqTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float128_eq(a, b);
    boolean temp2 = CSoftFloat.float128_eq_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128LeTest(final Float128 a, final Float128 b) {
    System.out.print("float128LeTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float128_le(a, b);
    boolean temp2 = CSoftFloat.float128_le_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128LtTest(final Float128 a, final Float128 b) {
    System.out.print("float128LtTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float128_lt(a, b);
    boolean temp2 = CSoftFloat.float128_lt_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128EqSignalingTest(final Float128 a, final Float128 b) {
    System.out.print("float128EqSignalingTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float128_eq_signaling(a, b);
    boolean temp2 = CSoftFloat.float128_eq_signaling_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128LeQuietTest(final Float128 a, final Float128 b) {
    System.out.print("float128LeQuietTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float128_le_quiet(a, b);
    boolean temp2 = CSoftFloat.float128_le_quiet_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128LtQuietTest(final Float128 a, final Float128 b) {
    System.out.print("float128LtQuietTest a = " + a + ", b = " + b);

    boolean temp = JSoftFloat.float128_lt_quiet(a, b);
    boolean temp2 = CSoftFloat.float128_lt_quiet_c(a, b);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  private static void float128IaSignalingNaNTest(final Float128 a) {
    System.out.print("float128IaSignalingNaNTest a = " + a);

    boolean temp = JSoftFloatUtils.float128_is_signaling_nan(a);
    boolean temp2 = CSoftFloat.float128_is_signaling_nan_c(a);
    System.out.println(" J vs C: " + temp + "==" + temp2);

    if (temp != temp2) {
      System.out.println("a = 0x" + a);
      System.out.println("J vs C: " + temp + " == " + temp2);
      throw new IllegalStateException(String.format("%s =/= %s", temp, temp2));
    }
  }

  @Test
  public void runTest() {
    initTestArray();

    // Test: arithmetic
    for (int i = 0; i < floatArray.size(); i++) {
      for (int j = 0; j < floatArray.size(); j++) {
        //if (j == 0) break; // TODO
        if (PRINT_TESTS_NUMBER) System.out.println("Test = " + (j + i*floatArray.size()) + " ");

        float32AddTest(getFloatValue(i), getFloatValue(j));
        float32SubTest(getFloatValue(i), getFloatValue(j));
        float32MulTest(getFloatValue(i), getFloatValue(j));
        float32DivTest(getFloatValue(i), getFloatValue(j));

        float32RemTest(getFloatValue(i), getFloatValue(j));
        float32EqTest(getFloatValue(i), getFloatValue(j));
        float32LeTest(getFloatValue(i), getFloatValue(j));
        float32LtTest(getFloatValue(i), getFloatValue(j));

        float32EqSignalingTest(getFloatValue(i), getFloatValue(j));
        float32LeQuietTest(getFloatValue(i), getFloatValue(j));
        float32LtQuietTest(getFloatValue(i), getFloatValue(j));
        
        float64AddTest(getDoubleValue(i), getDoubleValue(j));
        float64SubTest(getDoubleValue(i), getDoubleValue(j));
        float64MulTest(getDoubleValue(i), getDoubleValue(j));
        float64DivTest(getDoubleValue(i), getDoubleValue(j));

        float64RemTest(getDoubleValue(i), getDoubleValue(j));
        float64EqTest(getDoubleValue(i), getDoubleValue(j));
        float64LeTest(getDoubleValue(i), getDoubleValue(j));
        float64LtTest(getDoubleValue(i), getDoubleValue(j));
        
        float64EqSignalingTest(getDoubleValue(i), getDoubleValue(j));
        float64LtQuietTest(getDoubleValue(i), getDoubleValue(j));
        float64LeQuietTest(getDoubleValue(i), getDoubleValue(j));

        // FloatX80 

        FloatX80 float80_0 = new FloatX80(getShortValue(i), getLongValue(i));
        FloatX80 float80_1 = new FloatX80(getShortValue(i), getLongValue(j));
        FloatX80 float80_2 = new FloatX80(getShortValue(j), getLongValue(i));
        FloatX80 float80_3 = new FloatX80(getShortValue(j), getLongValue(j));

        floatx80ToInt32Test(float80_0);
        floatx80ToInt32Test(float80_1);
        floatx80ToInt32Test(float80_2);
        floatx80ToInt32Test(float80_3);

        floatx80ToInt32RoundToZeroTest(float80_0);
        floatx80ToInt32RoundToZeroTest(float80_1);
        floatx80ToInt32RoundToZeroTest(float80_2);
        floatx80ToInt32RoundToZeroTest(float80_3);

        floatx80ToInt64Test(float80_0);
        floatx80ToInt64Test(float80_1);
        floatx80ToInt64Test(float80_2);
        floatx80ToInt64Test(float80_3);

        floatx80ToInt64RoundToZeroTest(float80_0);
        floatx80ToInt64RoundToZeroTest(float80_1);
        floatx80ToInt64RoundToZeroTest(float80_2);
        floatx80ToInt64RoundToZeroTest(float80_3);

        floatx80ToFloat32Test(float80_0);
        floatx80ToFloat32Test(float80_1);
        floatx80ToFloat32Test(float80_2);
        floatx80ToFloat32Test(float80_3);

        floatx80ToFloat64Test(float80_0);
        floatx80ToFloat64Test(float80_1);
        floatx80ToFloat64Test(float80_2);
        floatx80ToFloat64Test(float80_3);

        floatx80ToFloat128Test(float80_0);
        floatx80ToFloat128Test(float80_1);
        floatx80ToFloat128Test(float80_2);
        floatx80ToFloat128Test(float80_3);

        floatx80RoundToInt32Test(float80_0);
        floatx80RoundToInt32Test(float80_1);
        floatx80RoundToInt32Test(float80_2);
        floatx80RoundToInt32Test(float80_3);

        floatx80AddTest(float80_0, float80_0);
        floatx80AddTest(float80_0, float80_1);
        floatx80AddTest(float80_0, float80_2);
        floatx80AddTest(float80_0, float80_3);

        floatx80SubTest(float80_0, float80_0);
        floatx80SubTest(float80_0, float80_1);
        floatx80SubTest(float80_0, float80_2);
        floatx80SubTest(float80_0, float80_3);

        floatx80MulTest(float80_0, float80_0);
        floatx80MulTest(float80_0, float80_1);
        floatx80MulTest(float80_0, float80_2);
        floatx80MulTest(float80_0, float80_3);

        floatx80RemTest(float80_0, float80_0);
        floatx80RemTest(float80_0, float80_1);
        floatx80RemTest(float80_0, float80_2);
        floatx80RemTest(float80_0, float80_3);

        floatx80EqTest(float80_0, float80_0);
        floatx80EqTest(float80_0, float80_1);
        floatx80EqTest(float80_0, float80_2);
        floatx80EqTest(float80_0, float80_3);

        floatx80LeTest(float80_0, float80_0);
        floatx80LeTest(float80_0, float80_1);
        floatx80LeTest(float80_0, float80_2);
        floatx80LeTest(float80_0, float80_3);

        floatx80LtTest(float80_0, float80_0);
        floatx80LtTest(float80_0, float80_1);
        floatx80LtTest(float80_0, float80_2);
        floatx80LtTest(float80_0, float80_3);

        floatx80EqSignalingTest(float80_0, float80_0);
        floatx80EqSignalingTest(float80_0, float80_1);
        floatx80EqSignalingTest(float80_0, float80_2);
        floatx80EqSignalingTest(float80_0, float80_3);

        floatx80LeQuietTest(float80_0, float80_0);
        floatx80LeQuietTest(float80_0, float80_1);
        floatx80LeQuietTest(float80_0, float80_2);
        floatx80LeQuietTest(float80_0, float80_3);

        floatx80LtQuietTest(float80_0, float80_0);
        floatx80LtQuietTest(float80_0, float80_1);
        floatx80LtQuietTest(float80_0, float80_2);
        floatx80LtQuietTest(float80_0, float80_3);

        floatx80IsSignalingNaNTest(float80_0);
        floatx80IsSignalingNaNTest(float80_1);
        floatx80IsSignalingNaNTest(float80_2);
        floatx80IsSignalingNaNTest(float80_3);

        // Float128
        
        Float128 float128_0 = new Float128(getLongValue(i), getLongValue(i));
        Float128 float128_1 = new Float128(getLongValue(i), getLongValue(j));
        Float128 float128_2 = new Float128(getLongValue(j), getLongValue(i));
        Float128 float128_3 = new Float128(getLongValue(j), getLongValue(j));

        float128ToInt32Test(float128_0);
        float128ToInt32Test(float128_1);
        float128ToInt32Test(float128_2);
        float128ToInt32Test(float128_3);

        float128ToInt32RoundToZeroTest(float128_0);
        float128ToInt32RoundToZeroTest(float128_1);
        float128ToInt32RoundToZeroTest(float128_2);
        float128ToInt32RoundToZeroTest(float128_3);

        float128ToInt64Test(float128_0);
        float128ToInt64Test(float128_1);
        float128ToInt64Test(float128_2);
        float128ToInt64Test(float128_3);

        float128ToInt64RoundToZeroTest(float128_0);
        float128ToInt64RoundToZeroTest(float128_1);
        float128ToInt64RoundToZeroTest(float128_2);
        float128ToInt64RoundToZeroTest(float128_3);

        float128ToFloat32Test(float128_0);
        float128ToFloat32Test(float128_1);
        float128ToFloat32Test(float128_2);
        float128ToFloat32Test(float128_3);

        float128ToFloat64Test(float128_0);
        float128ToFloat64Test(float128_1);
        float128ToFloat64Test(float128_2);
        float128ToFloat64Test(float128_3);

        float128ToFloat80Test(float128_0);
        float128ToFloat80Test(float128_1);
        float128ToFloat80Test(float128_2);
        float128ToFloat80Test(float128_3);

        float128RoundToIntTest(float128_0);
        float128RoundToIntTest(float128_1);
        float128RoundToIntTest(float128_2);
        float128RoundToIntTest(float128_3);

        float128AddTest(float128_0, float128_0);
        float128AddTest(float128_0, float128_1);
        float128AddTest(float128_0, float128_2);
        float128AddTest(float128_0, float128_3);

        float128SubTest(float128_0, float128_0);
        float128SubTest(float128_0, float128_1);
        float128SubTest(float128_0, float128_2);
        float128SubTest(float128_0, float128_3);

        float128MulTest(float128_0, float128_0);
        float128MulTest(float128_0, float128_1);
        float128MulTest(float128_0, float128_2);
        float128MulTest(float128_0, float128_3);

        float128RemTest(float128_0, float128_0);
        float128RemTest(float128_0, float128_1);
        float128RemTest(float128_0, float128_2);
        float128RemTest(float128_0, float128_3);


        float128EqTest(float128_0, float128_0);
        float128EqTest(float128_0, float128_1);
        float128EqTest(float128_0, float128_2);
        float128EqTest(float128_0, float128_3);

        float128LeTest(float128_0, float128_0);
        float128LeTest(float128_0, float128_1);
        float128LeTest(float128_0, float128_2);
        float128LeTest(float128_0, float128_3);

        float128LtTest(float128_0, float128_0);
        float128LtTest(float128_0, float128_1);
        float128LtTest(float128_0, float128_2);
        float128LtTest(float128_0, float128_3);

        float128EqSignalingTest(float128_0, float128_0);
        float128EqSignalingTest(float128_0, float128_1);
        float128EqSignalingTest(float128_0, float128_2);
        float128EqSignalingTest(float128_0, float128_3);

        float128LeQuietTest(float128_0, float128_0);
        float128LeQuietTest(float128_0, float128_1);
        float128LeQuietTest(float128_0, float128_2);
        float128LeQuietTest(float128_0, float128_3);

        float128LtQuietTest(float128_0, float128_0);
        float128LtQuietTest(float128_0, float128_1);
        float128LtQuietTest(float128_0, float128_2);
        float128LtQuietTest(float128_0, float128_3);

        float128IaSignalingNaNTest(float128_0);
        float128IaSignalingNaNTest(float128_1);
        float128IaSignalingNaNTest(float128_2);
        float128IaSignalingNaNTest(float128_3);

        if (RUN_LONGTIME_TESTS) {
          floatx80DivTest(float80_0, float80_0);
          floatx80DivTest(float80_0, float80_1);
          floatx80DivTest(float80_0, float80_2);
          floatx80DivTest(float80_0, float80_3);

          floatx80SqrtTest(float80_0);
          floatx80SqrtTest(float80_1);
          floatx80SqrtTest(float80_2);
          floatx80SqrtTest(float80_3);

          float128DivTest(float128_0, float128_0);
          float128DivTest(float128_0, float128_1);
          float128DivTest(float128_0, float128_2);
          float128DivTest(float128_0, float128_3);

          float128SqrtTest(float128_0);
          float128SqrtTest(float128_1);
          float128SqrtTest(float128_2);
          float128SqrtTest(float128_3);
        }
      }
    }

    for (int i = 0; i < floatArray.size(); i++) {
      //if (i == 0) break; // TODO

      if (PRINT_TESTS_NUMBER) System.out.println("Conversion test = " + i + " ");

      // Test: Conversion test

      int32ToFloat32Test(getIntValue(i));
      int32ToFloat64Test(getIntValue(i));

      int64ToFloat32Test(getLongValue(i));
      int64ToFloat64Test(getLongValue(i));

      float32ToInt32Test(getFloatValue(i));
      float32ToInt64Test(getFloatValue(i));

      float64ToInt32Test(getDoubleValue(i));
      float64ToFloat32Test(getDoubleValue(i));
      float64ToInt64Test(getDoubleValue(i));

      // Test: Round To Zero

      float32ToInt32RoundToZeroTest(getFloatValue(i));
      float32ToInt64RoundToZeroTest(getFloatValue(i));
      float64ToInt32RoundToZeroTest(getDoubleValue(i));
      float64ToInt64RoundToZeroTest(getDoubleValue(i));

      // Test: arithmetic
      float32SqrtTest(getFloatValue(i));
      float32IsSignalingNanTest(getFloatValue(i));
      float64SqrtTest(getDoubleValue(i));
      float64IsSignalingNanTest(getDoubleValue(i));
    }
  }
}
