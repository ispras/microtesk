/*
 * Copyright 2014-2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase;

import static ru.ispras.fortress.util.InvariantChecks.checkNotNull;

import java.util.Map;
import java.util.HashMap;
import java.util.Collections;

import ru.ispras.testbase.storage.TestBaseStorage;
import ru.ispras.testbase.storage.StoredTestData;
import ru.ispras.testbase.storage.DataConverter;

public class TestBase {
  private final TestBaseStorage storage;
  private final Map<String, DataConverter> converters;

  public TestBase(TestBaseStorage storage) {
    checkNotNull(storage);

    this.storage = storage;
    this.converters = new HashMap<String, DataConverter>();
  }

  public DataConverter addDataConverter(DataConverter converter) {
    checkNotNull(converter);

    return converters.put(converter.getName(), converter);
  }

  public TestBaseQueryResult executeQuery(TestBaseQuery query) {
    checkNotNull(query);

    final StoredTestData data = storage.fetch(query);
    final DataConverter converter = converters.get(data.getConverterName());

    if (converters == null) {
      return TestBaseQueryResult.reportErrors(
          Collections.singletonList("Missing required converter"));
    }
    final TestDataProvider dataProvider = converter.convert(data, query);
    return TestBaseQueryResult.success(dataProvider);
  }
}
