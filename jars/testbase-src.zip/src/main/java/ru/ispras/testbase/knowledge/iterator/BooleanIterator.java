/*
 * Copyright 2008-2015 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.iterator;

/**
 * {@link BooleanIterator} implements an iterator of boolean values {{@code false}, {@code true}}.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class BooleanIterator implements BoundedIterator<Boolean> {
  /** The current value. */
  private boolean value = false;
  /** Flag that reflects availability of the value. */
  private boolean hasValue = true;

  /**
   * Constructs a boolean iterator.
   */
  public BooleanIterator() {}

  /**
   * Constructs a copy of the boolean iterator.
   * 
   * @param r the iterator to be copied.
   */
  private BooleanIterator(final BooleanIterator r) {
    value = r.value;
    hasValue = r.hasValue;
  }

  /**
   * Sets the current value of the iterator.
   * 
   * @param value the value to be set.
   */
  public void setValue(final boolean value) {
    this.value = value;
  }

  @Override
  public void init() {
    value = false;
    hasValue = true;
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public Boolean value() {
    return Boolean.valueOf(value);
  }

  @Override
  public void next() {
    if (value) {
      hasValue = false;
    }

    value = true;
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public int size() {
    return 2;
  }

  @Override
  public BooleanIterator clone() {
    return new BooleanIterator(this);
  }
}
