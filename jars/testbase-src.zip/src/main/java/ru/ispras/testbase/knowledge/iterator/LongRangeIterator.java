/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.iterator;

/**
 * {@link LongRangeIterator} implements an  iterator over given range.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class LongRangeIterator implements Iterator<Long> {
  /** The lower bound. */
  private long min;
  /** The upper bound. */
  private long max;
  /** The increment value (step). */
  private long inc;

  /** The current value. */
  private long value;

  /** Flag that reflects availability of the value. */
  private boolean hasValue;

  /**
   * Constructs an  range iterator.
   * 
   * @param min the lower bound.
   * @param max the upper bound.
   * @param inc the increment value (step).
   */
  public LongRangeIterator(long min, long max, long inc) {
    if (min > max) {
      throw new IllegalArgumentException("min is greater than max");
    }

    if (inc <= 0) {
      throw new IllegalArgumentException("inc is non-positive");
    }

    this.min = min;
    this.max = max;
    this.inc = inc;

    init();
  }

  /**
   * Constructs an long number range iterator with the increment value equal to one.
   * 
   * @param min the lower bound.
   * @param max the upper bound.
   */
  public LongRangeIterator(long min, long max) {
    this(min, max, 1);
  }

  /**
   * Constructs an long number range iterator with the lower bound equal to zero and the increment
   * value equal to one.
   * 
   * @param max the upper bound.
   */
  public LongRangeIterator(long max) {
    this(0, max, 1);
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  protected LongRangeIterator(final LongRangeIterator r) {
    min = r.min;
    max = r.max;
    inc = r.inc;

    value = r.value;
    hasValue = r.hasValue;
  }

  /**
   * Sets the current value.
   * 
   * @param value the value to set.
   */
  public void setValue(long value) {
    if (value < min || value > max) {
      throw new IllegalArgumentException("The value is out of range");
    }

    this.value = value;
  }

  @Override
  public void init() {
    value = min;
    hasValue = true;
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public Long value() {
    return value;
  }

  @Override
  public void next() {
    if (value > max - inc) {
      hasValue = false;
    } else {
      value += inc;
    }
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public LongRangeIterator clone() {
    return new LongRangeIterator(this);
  }
}
