package ru.ispras.testbase.storage;

import ru.ispras.testbase.TestBaseQuery;

public interface DataLoader
{
    String getFormatName();
    Class<? extends TestBaseStorage> getStorageClass();
    StoredTestData load(TestBaseStorage storage, TestBaseQuery query);
}
