package ru.ispras.testbase;

import ru.ispras.testbase.generator.DataGenerator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static ru.ispras.fortress.util.InvariantChecks.checkNotNull;

public final class TestBaseRegistry {
  private static final class GeneratorRegistry {
    final Map<String, List<DataGenerator>> registry = new HashMap<>();
  
    public boolean add(final String name, final DataGenerator generator) {
      checkNotNull(name);
      checkNotNull(generator);
  
      List<DataGenerator> list = registry.get(name);
      if (list == null) {
        list = new ArrayList<>();
        list.add(generator);
        registry.put(name, list);
      } else {
        for (final DataGenerator stored : list) {
          if (stored.equals(generator)) {
            return false;
          }
        }
        list.add(generator);
      }
      return true;
    }
  
    public List<DataGenerator> getNamed(final String name) {
      checkNotNull(name);
      final List<DataGenerator> list = registry.get(name);
      if (list == null) {
        return Collections.emptyList();
      }
      return Collections.unmodifiableList(list);
    }
  }

  private final GeneratorRegistry generators = new GeneratorRegistry();

  public boolean registerGenerator(final String name, final DataGenerator generator) {
    return generators.add(name, generator);
  }

  public Collection<DataGenerator> getNamedGenerators(final String name) {
    return generators.getNamed(name);
  }
}
