/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.iterator;

import java.util.ArrayList;
import java.util.Collection;

import ru.ispras.fortress.randomizer.Randomizer;

/**
 * {@link RandomValueIterator} implements a single-value iterator.
 * 
 * @param <T> the item type.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class RandomValueIterator<T> implements BoundedIterator<T> {
  /** The array that stores possible values. */
  private final ArrayList<T> items;

  /** The flag that reflects availability of the value. */
  private boolean hasValue;

  /**
   * Constructs a random-value iterator.
   * 
   * @param array the array that stores possible values.
   */
  public RandomValueIterator(final T[] array) {
    if (array == null || array.length == 0) {
      throw new IllegalArgumentException("The array is empty");
    }

    items = new ArrayList<>();
    for (final T item : array) {
      items.add(item);
    }

    init();
  }

  /**
   * Constructs a random value iterator.
   * 
   * @param array the array list that stores possible values.
   */
  public RandomValueIterator(final Collection<T> array) {
    if (array == null || array.size() == 0) {
      throw new IllegalArgumentException("The array list is empty");
    }

    items = new ArrayList<>(array);

    init();
}

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  protected RandomValueIterator(final RandomValueIterator<T> r) {
    items = new ArrayList<T>(r.items);
    hasValue = r.hasValue;
  }

  @Override
  public void init() {
    hasValue = true;
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public T value() {
    return Randomizer.get().choose(items);
  }

  @Override
  public void next() {
    hasValue = false;
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public int size() {
    return 1;
  }

  @Override
  public RandomValueIterator<T> clone() {
    return new RandomValueIterator<T>(this);
  }
}
