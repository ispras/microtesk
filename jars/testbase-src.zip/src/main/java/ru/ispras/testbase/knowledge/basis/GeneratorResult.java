/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.basis;

/**
 * This class represents a result of test data generation for some operation.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class GeneratorResult<T> {
  /** Generation status. */
  public boolean status;
  /** Operation operands. */
  public T[] operands;

  /**
   * Constructs a generation result.
   * 
   * @param status the generation status.
   * @param operands the operation operands.
   */
  public GeneratorResult(boolean status, final T[] operands) {
    this.status = status;
    this.operands = operands;
  }

  @Override
  public boolean equals(Object o) {
    if (!(o instanceof GeneratorResult<?>)) {
      return false;
    }

    final GeneratorResult<?> r = (GeneratorResult<?>) o;

    if (status != r.status || operands.length != r.operands.length) {
      return false;
    }

    for (int i = 0; i < operands.length; i++) {
      if (!(operands[i] == null && r.operands[i] == null ||
            operands[i] != null && operands[i].equals(r.operands[i]))) {
        return false;
      }
    }

    return true;
  }

  @Override
  public int hashCode() {
    int hash = Boolean.valueOf(status).hashCode();

    for (int i = 0; i < operands.length; i++) {
      if (operands[0] != null) {
        hash = 31 * hash + operands[i].hashCode();
      }
    }

    return hash;
  }

  @Override
  public GeneratorResult<T> clone() {
    return new GeneratorResult<T>(status, operands);
  }

  @Override
  public String toString() {
    final StringBuffer buffer = new StringBuffer();

    buffer.append(String.valueOf(status));

    for (int i = 0; i < operands.length; i++) {
      buffer.append(":");
      buffer.append(operands[i]);
    }

    return buffer.toString();
  }
}
