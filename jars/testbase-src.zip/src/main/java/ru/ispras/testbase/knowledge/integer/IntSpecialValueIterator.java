/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.integer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import ru.ispras.testbase.knowledge.iterator.ArrayIterator;

/**
 * {@link IntSpecialValueIterator} implements a special value iterator for integer types.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class IntSpecialValueIterator extends ArrayIterator<IntNumber> {
  /** The special values cache. */
  private static final Map<IntFormat, ArrayList<IntNumber>> cache = new HashMap<>();

  /**
   * Returns special values for the given integer format.
   * 
   * @param format the format.
   */
  private static ArrayList<IntNumber> getSpecialValues(final IntFormat format) {
    ArrayList<IntNumber> cachedValues = cache.get(format);

    if (cachedValues != null) {
      return cachedValues;
    }

    final int n = format.getLength();
    final long m = format.getMask();

    final Set<IntNumber> specialValues = new HashSet<>();

    for (int i = 1; i <= n; i = (i == n ? i + 1 : (2*i > n ? n : 2*i))) {
      final long a = (1 << (i - 1));
      final long b = (1 << (i - 1)) - 1;
      final long c = ((1 << i) - 1);
      final long d = ((1 << i) - 1) - 1;

      specialValues.add(new IntNumber(format, a));
      specialValues.add(new IntNumber(format, b));
      specialValues.add(new IntNumber(format, c));
      specialValues.add(new IntNumber(format, d));

      specialValues.add(new IntNumber(format, ~a & m));
      specialValues.add(new IntNumber(format, ~b & m));
      specialValues.add(new IntNumber(format, ~c & m));
      specialValues.add(new IntNumber(format, ~d & m));
    }

    cache.put(format, cachedValues = new ArrayList<IntNumber>(specialValues));
    return cachedValues;
  }

  /**
   * Constructs a special value iterator for the given integer format.
   * 
   * @param format the format.
   */
  public IntSpecialValueIterator(final IntFormat format) {
    super(getSpecialValues(format));
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  protected IntSpecialValueIterator(IntSpecialValueIterator r) {
    super(r);
  }

  @Override
  public IntSpecialValueIterator clone() {
    return new IntSpecialValueIterator(this);
  }
}
