/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.integer;

/**
 * This class represents an integer number format.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class IntFormat {
  /** 1-bit integer numbers. */ 
  public static final IntFormat INT1 = new IntFormat(1);
  /** 8-bit integer numbers. */ 
  public static final IntFormat INT8 = new IntFormat(8);
  /** 16-bit integer numbers. */ 
  public static final IntFormat INT16 = new IntFormat(16);
  /** 32-bit integer numbers. */ 
  public static final IntFormat INT32 = new IntFormat(32);
  /** 64-bit integer numbers. */ 
  public static final IntFormat INT64 = new IntFormat(64);

  /** The number length. */
  private int length;
  /** The number mask. */
  private long mask;

  /**
   * Constructs an integer number format.
   * 
   * @param length the length (in bits).
   */
  public IntFormat(int length) {
    this.length = length;
    this.mask = length == Long.SIZE ? -1L : (1L << length) - 1;
  }

  /**
   * Returns the bit length of a number.
   * 
   * @return the length.
   */
  public int getLength() {
    return length;
  }

  /**
   * Returns the bit mask of a number.
   * 
   * @return the mask.
   */
  public long getMask() {
    return mask;
  }

  /**
   * Returns the minimal value (signed).
   * 
   * @return the minimal value.
   */
  public long getMinValue() {
    return -1L << (length - 1); 
  }

  /**
   * Returns the maximal value (signed).
   * 
   * @return the maximal value.
   */
  public long getMaxValue() {
    return (1L << (length - 1)) - 1;
  }

  @Override
  public boolean equals(Object o) {
    if (!(o instanceof IntNumber)) {
      return false;
    }

    final IntFormat r = (IntFormat) o;

    return length == r.length;
  }

  @Override
  public int hashCode() {
    return length;
  }

  @Override
  public String toString() {
    return String.format("int%d", length);
  }
}
