/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.integer.sub;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.integer.IntExceptionGenerator;
import ru.ispras.testbase.knowledge.integer.IntFormat;
import ru.ispras.testbase.knowledge.integer.IntNumber;
import ru.ispras.testbase.knowledge.integer.add.IntAddExceptionGenerator;

/**
 * This class implements a random generator targeted at the integer subtraction exceptions.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class IntSubExceptionGenerator extends IntExceptionGenerator {

  /**
   * Reverses the sign of the second operand.
   *
   * @param operands the operands to be transformed.
   * @return the transformed operands.
   */
  private static IntNumber[] reverse(final IntNumber[] operands) {
    final IntNumber x = operands[0];
    final IntNumber y = operands[1];

    return new IntNumber[] {x, y != null ?
        new IntNumber(y.getFormat(), ~(y.getValue() - 1L) & y.getFormat().getMask()) : null};
  }

  /**
   * Reverses the sign of the second operand of the generation result.
   *
   * @param result the generation result to be transformed.
   * @return the transformed result.
   */
  private static GeneratorResult<IntNumber> reverse(final GeneratorResult<IntNumber> result) {
    return new GeneratorResult<IntNumber>(result.status,
        result.status ? reverse(result.operands) : result.operands);
  }

  /** The internal generator targeted at the integer addition exception. */
  private IntAddExceptionGenerator addGenerator;


  /**
   * Constructs a random generator targeted at the integer addition exceptions.
   * 
   * @param format the operand format.
   */
  public IntSubExceptionGenerator(final IntFormat format) {
    this.addGenerator = new IntAddExceptionGenerator(format);
  }

  //------------------------------------------------------------------------------------------------
  // Normal Behavior
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkNormal(final IntNumber[] operands) {
    return addGenerator.checkNormal(reverse(operands));
  }

  @Override
  public GeneratorResult<IntNumber> generateNormal(final IntNumber[] operands) {
    return reverse(addGenerator.generateNormal(reverse(operands)));
  }

  //------------------------------------------------------------------------------------------------
  // Overflow Exception
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkOverflow(final IntNumber[] operands) {
    return addGenerator.checkOverflow(reverse(operands));
  }

  @Override
  public GeneratorResult<IntNumber> generateOverflow(final IntNumber[] operands) {
    return reverse(addGenerator.generateOverflow(reverse(operands)));
  }
}
