/*
 * Copyright 2014-2015 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.iterator;

import java.util.LinkedHashSet;

/**
 * {@link FilteringIterator} implements an iterator filter based on a cache of values.
 * 
 * @param <T> the item type.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class FilteringIterator<T> implements Iterator<T> {

  /**
   * This enumeration contains equality checking types.
   */
  public static enum Type {
    /** Standard {@code equals} to be used for checking. */
    STANDARD_CHECK,
    /** Custom {@code equals} to be used for checking. */
    CUSTOM_CHECK
  }

  /** The base iterator. */
  private final Iterator<T> iterator;
  /** The equality checking type. */
  private final Type type;
  /** The cache size. */
  private final int size;
  /** The cache of values. */
  private final LinkedHashSet<T> cache = new LinkedHashSet<T>();

  /**
   * Constructs a filtering iterator.
   * 
   * @param iterator the base iterator.
   * @param type the equality checking type.
   * @param size the cache size.
   */
  public FilteringIterator(final Iterator<T> iterator, final Type type, final int size) {
    this.iterator = iterator;
    this.type = type;
    this.size = size;
  }

  /**
   * Constructs a filtering iterator with the unlimited cache size.
   * 
   * @param iterator the base iterator.
   * @param type the equality checking type.
   */
  public FilteringIterator(final Iterator<T> iterator, final Type type) {
    this(iterator, type, -1);
  }

  /**
   * Constructs a filtering iterator.
   * 
   * @param iterator the base iterator.
   * @param size the cache size.
   */
  public FilteringIterator(final Iterator<T> iterator, final int size) {
    this(iterator, Type.STANDARD_CHECK, size);
  }

  /**
   * Constructs a filtering iterator with the unlimited cache size.
   * 
   * @param iterator the base iterator.
   */
  public FilteringIterator(final Iterator<T> iterator) {
    this(iterator, Type.STANDARD_CHECK);
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  public FilteringIterator(final FilteringIterator<T> r) {
    iterator = r.iterator.clone();
    type = r.type;
    size = r.size;
  }

  /**
   * Checks whether two values are equal (can be overloaded in a subclass).
   * 
   * @param lhs the left-hand-side value.
   * @param rhs the right-hand-side value.
   * @return {@code true} if the value are equal; {@code false} otherwise.
   */
  protected boolean equals(final T lhs, final T rhs) {
    return lhs == null && rhs == null || lhs != null && lhs.equals(rhs);
  }

  /**
   * Checks whether the value is new.
   *
   * @param value the value to be checked.
   * @return {@code true} if the value is new; {@code false} otherwise.
   */
  private boolean checkValue(final T value) {
    // Try to use the standard check.
    if (cache.contains(value)) {
      // Old value.
      return false;
    }

    // Try to use the custom check.
    if (type == Type.CUSTOM_CHECK) {
      for (final T item : cache) {
        if (equals(value, item)) {
          // Old value.
          return false;
        }
      }
    }

    // The cache is full; eviction is required.
    if (size >= 0 && cache.size() >= size) {
      cache.remove(cache.iterator().next());
    }

    cache.add(value);

    // New value.
    return true;
  }

  @Override
  public void init() {
    iterator.init();

    if (iterator.hasValue()) {
      checkValue(iterator.value());
    }
  }

  @Override
  public boolean hasValue() {
    return iterator.hasValue();
  }

  @Override
  public T value() {
    return iterator.value();
  }

  @Override
  public void next() {
    boolean newValue = false;

    while (iterator.hasValue() && !newValue) {
      iterator.next();

      if (iterator.hasValue()) {
        newValue = checkValue(iterator.value());
      }
    }
  }

  @Override
  public void stop() {
    iterator.stop();
  }

  @Override
  public FilteringIterator<T> clone() {
    return new FilteringIterator<T>(this);
  }
}
