/*
 * Copyright 2007-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.div;

/**
 * This class represents an fraction (<code>n/d</code>, where <code>n</code> and <code>d</code>
 * are integer numbers).
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
final class Fraction {
  /** The numerator. */
  public long n;

  /** The denominator. */
  public long d;

  /**
   * Constructs a fraction.
   * 
   * @param n the numerator.
   * @param d> the denominator.
   */
  public Fraction(long n, long d) {
    this.n = n;
    this.d = d;
  }

  /**
   * Constructs the <code>0/0</code> fraction.
   */
  public Fraction() {
    this(0, 0);
  }

  /**
   * Constructs a copy of the fraction.
   * 
   * @param r the fraction to be copied.
   */
  private Fraction(final Fraction r) {
    n = r.n;
    d = r.d;
  }

  /**
   * Returns the numerator of the fraction.
   * 
   * @return the numerator of the fraction.
   */
  public long getNumerator() {
    return n;
  }

  /**
   * Sets the numerator of the fraction.
   * 
   * @param n the numerator of the fraction.
   */
  public void setNumerator(long n) {
    this.n = n;
  }

  /**
   * Returns the denominator of the fraction.
   * 
   * @return the denominator of the fraction.
   */
  public long getDenominator() {
    return d;
  }

  /**
   * Sets the denominator of the fraction.
   * 
   * @param d the denominator of the fraction.
   */
  public void setDenominator(long d) {
    this.d = d;
  }

  /**
   * Returns the greatest common divisor (GCD) of the numerator and the denominator.
   * 
   * @return the greatest common divisor of the numerator and the denominator.
   */
  public long getGreatestCommonDivisor() {
    long n = this.n;
    long d = this.d;

    if (n < 0 || d < 0) {
      throw new IllegalArgumentException("Negative number");
    }

    long k = n;

    if (n < d) {
      k = d;
      d = n;
    }

    while (d >= 1 && (n = k) != d) {
      d = (n % (k = d));
    }

    return (d != 0) ? d : k;
  }

  /**
   * Checks if the fraction is irreducible, i.e. GCD(n, d) = 1.
   * 
   * @return <code>true</code> if the fraction is irreducible; <code>false</code> otherwise.
   */
  public boolean isIrreducible() {
    return getGreatestCommonDivisor() == 1;
  }

  /**
   * Reduces the fraction (divides the numerator and the denominator by the GCD).
   */
  public void reduce() {
    long gcd = getGreatestCommonDivisor();

    if (gcd != 1) {
      n /= gcd;
      d /= gcd;
    }
  }

  /**
   * Checks if this fraction is simpler than the other fraction.
   * 
   * @param rhs the other fraction.
   * 
   * @return <code>true</code> if this fraction is simpler than the other fraction;
   *         <code>false</code> otherwise.
   */
  public boolean isSimplerThan(final Fraction rhs) {
    return n <= rhs.n && d <= rhs.d && !equals(rhs);
  }

  /**
   * Returns the mediant of the fractions: <code>mediant(n1/d1, n2/d2) = (n1 + n2)/(d1 + d2)</code>.
   * 
   * @param rhs the other fraction.
   * 
   * @return the mediant of the fractions.
   */
  public Fraction getMediant(final Fraction rhs) {
    return new Fraction(n + rhs.n, d + rhs.d);
  }

  /**
   * Calculates the parent partition of the fraction.
   * 
   * @param <code>sp</code> the simplest parent (output).
   * @param <code>cp</code> the common parent (output).
   */
  public void parentPartition(final Fraction sp, final Fraction cp) {
    long q_n_1, q_n_2;
    long p_n_1, p_n_2;

    long n = this.n;
    long d = this.d;

    long a, b;

    boolean reverse = n > d;

    if (reverse) {
      a = d;
      d = n;
      n = a;
    }

    a = d / n;
    b = d % n;

    d = n;
    n = b;

    q_n_1 = a;
    q_n_2 = 1;

    p_n_1 = 1;
    p_n_2 = 0;

    while (n != 1) {
      a = d / n;
      b = d % n;

      d = n;
      n = b;

      q_n_1 = a * (b = q_n_1) + q_n_2;
      q_n_2 = b;

      p_n_1 = a * (b = p_n_1) + p_n_2;
      p_n_2 = b;
    }

    if (reverse) {
      b = p_n_1;
      p_n_1 = q_n_1;
      q_n_1 = b;
    }

    if (a != 1) {
      sp.n = p_n_1;
      sp.d = q_n_1;

      cp.n = this.n - p_n_1;
      cp.d = this.d - q_n_1;
    } else {
      cp.n = p_n_1;
      cp.d = q_n_1;

      sp.n = this.n - p_n_1;
      sp.d = this.d - q_n_1;
    }
  }

  @Override
  public boolean equals(Object o) {
    if (!(o instanceof Fraction)) {
      return false;
    }

    final Fraction r = (Fraction) o;

    return n == r.n && d == r.d;
  }

  @Override
  public int hashCode() {
    return (int) (31 * Long.valueOf(n).hashCode() + Long.valueOf(d).hashCode());
  }

  @Override
  public Fraction clone() {
    return new Fraction(this);
  }
}
