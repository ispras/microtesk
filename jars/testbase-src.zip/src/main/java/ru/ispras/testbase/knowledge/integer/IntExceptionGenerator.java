/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.integer;

import ru.ispras.testbase.knowledge.basis.Generator;
import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.integer.IntNumber;

/**
 * {@link IntExceptionGenerator} is a base interface for random generators targeted at the integer
 * arithmetic exceptions.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public abstract class IntExceptionGenerator implements Generator<IntNumber, IntException> {

  @Override
  public final boolean check(final IntException situation, final IntNumber[] operands) {
    switch(situation) {
      case NORMAL:
        return checkNormal(operands);
      case OVERFLOW:
        return checkOverflow(operands);
      default:
        throw new IllegalArgumentException(String.format("Illegal situation: %s", situation));
    }
  }

  @Override
  public final GeneratorResult<IntNumber> generate(final IntException situation,
      final IntNumber[] operands) {
    switch(situation) {
      case NORMAL:
        return generateNormal(operands);
      case OVERFLOW:
        return generateOverflow(operands);
      default:
        throw new IllegalArgumentException(String.format("Illegal situation: %s", situation));
    }
  }

  //------------------------------------------------------------------------------------------------
  // Normal Behavior
  //------------------------------------------------------------------------------------------------

  /**
   * Checks whether the operation does not cause exceptions.
   * 
   * @param operands the operation operands.
   * @return {@code true} if the operation does not cause exceptions; {@code false}
   *         otherwise.
   */
  protected abstract boolean checkNormal(final IntNumber[] operands);

  /**
   * Tries to generate operands that do not cause exceptions.
   * 
   * @param operands the operation operands ({@code operand[i] == null} if the i-th operation
   *        is not fixed; otherwise {@code operand[i]} contains the operand value).
   * @return the operation operands.
   */
  protected abstract GeneratorResult<IntNumber> generateNormal(final IntNumber[] operands);

  //------------------------------------------------------------------------------------------------
  // Overflow Exception
  //------------------------------------------------------------------------------------------------

  /**
   * Checks whether the operation causes the overflow exception.
   * 
   * @param operands the operation operands.
   * @return {@code true} if the operation causes the exception; {@code false} otherwise.
   */
  protected abstract boolean checkOverflow(final IntNumber[] operands);

  /**
   * Tries to generate operands that cause the overflow exception.
   * 
   * @param operands the operation operands ({@code operand[i] == null} if the i-th operation
   *        is not fixed; otherwise {@code operand[i]} contains the operand value).
   * @return the operation operands.
   */
  protected abstract GeneratorResult<IntNumber> generateOverflow(final IntNumber[] operands);
}
