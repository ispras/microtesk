/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.sqrt;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;

/**
 * {@link ResultAdapter} transforms an integer into a floating-point number.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
final class ResultAdapter {
  /** The format of floating-point numbers. */
  private FpFormat format;

  /** The integer number to be transformed. */
  private long value;

  /** The even exponent indicator. */
  private boolean evenExponent;

  /**
   * Checks whether two values are equal (equivalent).
   * 
   * @param lhs the left-hand-side value.
   * @param rhs the right-hand-side value.
   * @return {@code true} if the value are equal; {@code false} otherwise.
   */
  public static boolean equals(final GeneratorResult<FpNumber> lhs,
      final GeneratorResult<FpNumber> rhs) {
    return lhs.operands[0].getFraction() == rhs.operands[0].getFraction();
  }

  /**
   * Constructs a fraction adapter.
   * 
   * @param format the format of floating-point numbers.
   * @param value the integer to be transformed.
   * @param evenExponent the even exponent indicator.
   */
  public ResultAdapter(final FpFormat format, long value, boolean evenExponent) {
    this.format = format;
    this.value = value;
    this.evenExponent = evenExponent;
  }

  /**
   * Transforms the fraction into a pair of floating-point numbers.
   * 
   * @return a pair of floating-point numbers.
   */
  public GeneratorResult<FpNumber> get() {
    final long bias = format.getExponentBias();

    final long sign = 0;
    final long exponent = 2 * format.getPrecision() - 1;
    final long fraction = format.valueOfUnsigned(value).getFraction();

    // The exponent is either 2*n - 1 or 2*n - 2 (as in the paper).
    final long realExponent = (evenExponent ? (exponent & ~1L) : (exponent | 1L)) + bias; 

    final FpNumber operand = new FpNumber(format, sign, realExponent, fraction);
    return new GeneratorResult<FpNumber>(true, new FpNumber[] { operand });
  }
}
