/*
 * Copyright 2008-2015 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.iterator;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link ProductIterator} implements a product iterator, a composite iterator that generates all
 * possible combinations of items produced by simpler iterators.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class ProductIterator<T> implements Iterator<List<T>> {
  /** The list of registered iterators. */
  private final ArrayList<Iterator<T>> iterators = new ArrayList<>();

  /** The flag that reflects availability of the value. */
  private boolean hasValue = true;

  /**
   * Constructs a product iterator.
   */
  public ProductIterator() {}

  /**
   * Constructs a copy of the product iterator.
   * 
   * @param r the iterator to be copied.
   */
  protected ProductIterator(final ProductIterator<T> r) {
    for (int i = 0; i < r.iterators.size(); i++) {
      final Iterator<T> iterator = r.iterators.get(i);
      iterators.add(iterator.clone());
    }

    hasValue = r.hasValue();
  }

  /**
   * Registers the iterator.
   * 
   * @param iterator the iterator to be registered.
   */
  public void registerIterator(final Iterator<T> iterator) {
    iterators.add(iterator);
  }

  /**
   * Removes all registered iterators.
   */
  public void clear() {
    iterators.clear();
  }

  /**
   * Returns the number of the registered iterators.
   * 
   * @return the number of the registered iterators.
   */
  public int size() {
    return iterators.size();
  }

  /**
   * Returns the i-th iterator of the list.
   * 
   * @param i the iterator index.
   * @return the i-th iterator of the list.
   */
  public Iterator<T> iterator(int i) {
    return iterators.get(i);
  }

  @Override
  public void init() {
    hasValue = true;

    for (final Iterator<T> iterator : iterators) {
      iterator.init();
      hasValue &= iterator.hasValue();
    }
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  /**
   * Returns the value of the i-th iterator.
   * 
   * @param i the iterator index.
   * @return the value of the i-th iterator.
   */
  public T value(final int i) {
    final Iterator<T> iterator = iterators.get(i);
    return iterator.value();
  }

  @Override
  public List<T> value() {
    final ArrayList<T> list = new ArrayList<>(iterators.size());

    for (final Iterator<T> iterator : iterators) {
      list.add(iterator.value());
    }

    return list;
  }

  @Override
  public void next() {
    for (int i = iterators.size() - 1; i >= 0; i--) {
      final Iterator<T> iterator = iterators.get(i);

      if (iterator.hasValue()) {
        iterator.next();

        if (iterator.hasValue()) {
          return;
        }
      }

      iterator.init();
    }

    hasValue = false;
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public ProductIterator<T> clone() {
    return new ProductIterator<T>(this);
  }
}
