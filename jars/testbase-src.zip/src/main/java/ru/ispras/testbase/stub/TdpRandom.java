/*
 * Copyright 2014-2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.stub;

import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;

import ru.ispras.fortress.data.DataType;
import ru.ispras.fortress.data.DataTypeId;
import ru.ispras.fortress.data.types.bitvector.BitVector;
import ru.ispras.fortress.expression.Node;
import ru.ispras.fortress.expression.NodeValue;
import ru.ispras.fortress.randomizer.Randomizer;
import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestData;

final class TdpRandom extends TdpBase {
  public static final String NAME = "random";

  public TdpRandom() {
    super(NAME);
  }

  @Override
  protected TestData generateData(final TestBaseQuery query) {
    final BigInteger min = getParameterAsBigInteger(query, "min");
    final BigInteger max = getParameterAsBigInteger(query, "max");

    final Map<String, Node> unknowns = Utils.extractUnknown(query);
    final Map<String, Node> outputData = new LinkedHashMap<>();

    for (final Map.Entry<String, Node> e : unknowns.entrySet()) {
      final String name = e.getKey();
      final DataType type = e.getValue().getDataType();

      final Node value;
      if (DataTypeId.BIT_VECTOR == type.getTypeId()) {
        final BitVector bv;
        if (min != null && max != null) {
          final BigInteger bi = Randomizer.get().nextBigIntegerRange(min, max);
          bv = BitVector.valueOf(bi, type.getSize());
        } else {
          bv = BitVector.newEmpty(type.getSize());
          Randomizer.get().fill(bv);
        }
        value = NodeValue.newBitVector(bv);
      } else {
        throw new IllegalArgumentException(String.format(
            "The %s variable has unupported type: %s", name, type));
      }

      outputData.put(name, value);
    }

    return new TestData(outputData);
  }

  private static BigInteger getParameterAsBigInteger(
      final TestBaseQuery query,
      final String name) {

    final Object parameter = Utils.getParameter(query, name);
    if (parameter == null) {
      return null;
    }

    if (parameter instanceof BigInteger) {
      return (BigInteger) parameter;
    }

    if (parameter instanceof Long) {
      return BigInteger.valueOf(((Long) parameter).longValue());
    }

    if (parameter instanceof Integer) {
      return BigInteger.valueOf(((Integer) parameter).longValue());
    }

    if (parameter instanceof String) {
      return new BigInteger((String) parameter);
    }

    throw new NumberFormatException(String.format(
        "The %s parameter (%s) cannot be converted to BigInteger.",
        name, parameter.getClass().getSimpleName()));
  }
}
