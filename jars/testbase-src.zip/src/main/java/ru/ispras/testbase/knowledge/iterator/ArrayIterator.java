/*
 * Copyright 2008-2015 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.iterator;

import java.util.ArrayList;

/**
 * {@link ArrayIterator} implements a simple array-based iterator.
 * 
 * @param <T> the item type.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class ArrayIterator<T> implements BoundedIterator<T> {
  /** The array whose items are being iterated. */
  private final ArrayList<T> items;

  /** The index of the current item. */
  private int index;
  /** The flag that reflects availability of the value. */
  private boolean hasValue;

  /**
   * Constructs an array iterator.
   * 
   * @param array the array to be iterated.
   */
  public ArrayIterator(final T[] array) {
    if (array == null || array.length == 0) {
      throw new IllegalArgumentException("The array is empty");
    }

    items = new ArrayList<>();
    for (final T item : array) {
      items.add(item);
    }

    init();
  }

  /**
   * Constructs an array iterator.
   * 
   * @param array the array list to be iterated.
   */
  public ArrayIterator(final ArrayList<T> array) {
    if (array == null || array.size() == 0) {
      throw new IllegalArgumentException("The array list is empty");
    }

    items = new ArrayList<>(array);

    init();
}

  /**
   * Constructs a copy of the array iterator.
   * 
   * @param r the iterator to be copied.
   */
  protected ArrayIterator(final ArrayIterator<T> r) {
    items = new ArrayList<T>(r.items);
    index = r.index;
    hasValue = r.hasValue;
  }

  @Override
  public void init() {
    index = 0;
    hasValue = true;
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public T value() {
    return items.get(index);
  }

  @Override
  public void next() {
    if (index == items.size() - 1) {
      hasValue = false;
    } else {
      index++;
    }
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public int size() {
    return items.size();
  }

  @Override
  public ArrayIterator<T> clone() {
    return new ArrayIterator<T>(this);
  }
}
