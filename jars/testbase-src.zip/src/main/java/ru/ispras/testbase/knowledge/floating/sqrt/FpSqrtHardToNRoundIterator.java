/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.sqrt;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;
import ru.ispras.testbase.knowledge.iterator.ArrayIterator;
import ru.ispras.testbase.knowledge.iterator.FilteringIterator;
import ru.ispras.testbase.knowledge.iterator.Iterator;

/**
 * Class <code>SqrtNearestRoundIterator</code> implements iteration of hard-to-round cases for the
 * square root operation in round-to-nearest mode.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
final class FpSqrtHardToNRoundInternalIterator implements Iterator<GeneratorResult<FpNumber>> {
  /** The upper bound of |k|. */
  private static final int MAX_K_VALUE = 1024;

  /** Format of floating-point numbers. */
  private FpFormat format;

  /** Flag that reflects availability of the value. */
  private boolean hasValue;

  /** <code>z_n</code>. */
  private long z_n;
  /** <code>R_n</code>. */
  private long r_n;

  /** The iterator of integers <code>k</code>, such that <code>k = 1 mod 8</code>. */
  private Iterator<Integer> kIterator = new Int1Mod8Iterator(MAX_K_VALUE);
  /** The iterator of cases: <code>{0, 1}</code>. */
  private Iterator<Integer> cIterator = new ArrayIterator<Integer>(new Integer[] {0, 1});

  /** The current value. */
  private GeneratorResult<FpNumber> result;

  /**
   * Constructs a square root hard-to-round iterator.
   * 
   * @param format the format.
   */
  public FpSqrtHardToNRoundInternalIterator(final FpFormat format) {
    this.format = format;

    init();
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  private FpSqrtHardToNRoundInternalIterator(FpSqrtHardToNRoundInternalIterator r) {
    kIterator = kIterator.clone();
    cIterator = cIterator.clone();

    format = r.format;
    hasValue = r.hasValue;
    result = r.result.clone();
  }

  @Override
  public void init() {
    kIterator.init();
    cIterator.init();

    init(kIterator.value());

    hasValue = true;
    result = null;
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public GeneratorResult<FpNumber> value() {
    // Between two next()'s calls the method value() should return the same value.
    if (result != null) {
      return result;
    }

    final int n = format.getPrecision();

    long value = 0L;
    boolean evenExponent = false; // TODO:

    if (cIterator.value() == 0) {
      value = (1L << n) + (r_n - z_n);
    } else {
      value = (1L << (n - 1)) + (2 * r_n + z_n);
    }

    return new ResultAdapter(format, value, evenExponent).get();
  }

  /**
   * Initializes <code>z_n</code> and <code>r_n</code> according to the <code>k</code> value.
   * 
   * <code>
   * z_3 = 1;
   * R_3 = (z_3^2 - k) / 2^3 = (1 - k) / 8;
   * for j = 4, ..., n
   *   if R_j-1 is even
   *     R_j = 1/2 * R_j-1;
   *     z_j = z_j-1;
   *   else
   *     R_j = 2^(j-4) + 1/2 * (R_j-1 - z_j-1);
   *     z_j = 2^(j-2) - z_j-1;
   *  </code>
   * 
   * @param k the <code>k</code> value.
   */
  private void init(int k) {
    final int n = format.getPrecision();

    // z_3 = 1.
    z_n = 1;
    // R_3 = (1 - k) / 8.
    r_n = (1 - k) / 8;

    for (int j = 4; j <= n + 2; j++) {
      if ((r_n & 1L) != 0) {
        r_n = (1L << (j - 4)) + (r_n - z_n) / 2;
        z_n = (1L << (j - 2)) - z_n;
      } else {
        r_n = r_n / 2;
      }
    }
  }

  @Override
  public void next() {
    // Invalidate the result.
    result = null;

    if (!hasValue()) {
      return;
    }

    if (cIterator.hasValue()) {
      cIterator.next();

      if (cIterator.hasValue()) {
        return;
      }
    }

    cIterator.init();

    if (kIterator.hasValue()) {
      kIterator.next();

      if (kIterator.hasValue()) {
        init(kIterator.value());
        return;
      }
    }

    kIterator.init();

    stop();
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public FpSqrtHardToNRoundInternalIterator clone() {
    return new FpSqrtHardToNRoundInternalIterator(this);
  }
}

/**
 * This class in addition to {@link FpSqrtHardToNRoundInternalIterator} performs filtration of
 * values (removes duplicates).
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class FpSqrtHardToNRoundIterator extends FilteringIterator<GeneratorResult<FpNumber>> {
  /** The filter cache size. */
  private static final int FILTER_SIZE = 4;

  /**
   * Constructs a copy of the square root hard-to-round iterator.
   * 
   * @param format the format.
   */
  public FpSqrtHardToNRoundIterator(final FpFormat format) {
    super(new FpSqrtHardToDRoundInternalIterator(format), Type.CUSTOM_CHECK, FILTER_SIZE);
    init();
  }

  @Override
  protected boolean equals(final GeneratorResult<FpNumber> lhs,
      final GeneratorResult<FpNumber> rhs) {
    return ResultAdapter.equals(lhs, rhs);
  }
}