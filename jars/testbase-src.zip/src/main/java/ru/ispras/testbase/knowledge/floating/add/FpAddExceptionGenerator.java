/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.add;

import ru.ispras.fortress.randomizer.Randomizer;
import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpExceptionGenerator;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;

/**
 * This class implements a random generator targeted at the exceptions in the floating-point
 * addition operation.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 * @author <a href="mailto:chupilko@ispras.ru">Mikhail Chupilko</a>
 */
public final class FpAddExceptionGenerator extends FpExceptionGenerator {

  /** The random number generator. */
  private Randomizer random = Randomizer.get();

  /** The floating-point number format. */
  private FpFormat format;

  /**
   * Constructs a random generator.
   *  
   * @param format the operand format.
   */
  public FpAddExceptionGenerator(final FpFormat format) {
    this.format = format;
  }

  //------------------------------------------------------------------------------------------------
  // Normal Behavior
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkNormal(final FpNumber[] operands) {
    return !checkOverflow(operands)
        && !checkUnderflow(operands)
        && !checkInexact(operands);
  }

  @Override
  public GeneratorResult<FpNumber> generateNormal(final FpNumber[] operands) {
    final FpNumber[] result = new FpNumber[] { operands[0], operands[1] };

    // If both of the operands are fixed, return them as a result.
    if (result[0] != null && result[1] != null) {
      return new GeneratorResult<FpNumber>(checkNormal(result), result);
    }

    final long minExponent = format.getMinNormalizedExponent();
    final long maxExponent = format.getMaxNormalizedExponent();

    // If both of the operands are free, assigns a random value to one of them.
    if (result[0] == null && result[1] == null) {
      final long sign     = random.nextLong() & format.getSignMask();
      final long exponent = random.nextLongRange(minExponent, maxExponent);
      final long fraction = random.nextLong() & format.getFractionMask();

      result[random.nextInt() & 1] = new FpNumber(format, sign, exponent, fraction);
    }

    final int i = result[0] != null ? 0 : 1;
    final int j = 1 - i;

    final FpNumber x = result[i];

    // If one of the operands is not normalized, the situation is not considered as being normal.
    if (!x.isZero() && !x.isNormalized()) {
      return new GeneratorResult<FpNumber>(false, result);
    }

    // The fixed operand.
    final long xSign     = x.getSign();
    final long xExponent = x.getExponent();
    final long xFraction = x.getFraction();

    // The operand to be generated.
    long ySign     = random.nextLong() & format.getSignMask();
    long yExponent = xExponent; // yExponent <= xExponent.

    final int fractionLength = format.getFractionLength();

    long xValue = (1L << fractionLength) | xFraction;
    long yValue; // To be generated.
    long zValue = (1L << fractionLength) | (random.nextLong() & format.getFractionMask());

    // Equal signs: (x + y) = z => y = (z - x).
    if (xSign == ySign) {
      if (zValue < xValue) {
        if (xExponent < maxExponent) {
          // This means that z's exponent is x's exponent + 1.
          zValue <<= 1;
        } else {
          // If the exponent cannot be increased, (z - x) should be small.
          zValue = random.nextLongRange(xValue, xValue + (format.getFractionMask() - xFraction));
        }
      }

      yValue = zValue - xValue;

    // Different signs: (x - y) = z => y = (x - z).
    } else {
      if (zValue > xValue) {
        if (xExponent > minExponent) {
          // This means that z's exponent is x's exponent - 1.
          zValue >>>= 1;
        } else {
          // If the exponent cannot be decreased, z should be zero (otherwise, underflow).
          zValue = 0;
        }
      }

      yValue = xValue - zValue;
    }

    while (yValue != 0 && ((1L << fractionLength) & yValue) == 0) {
      yValue <<= 1;
      // If y's exponent cannot be decreased, y to be zero.
      if (--yExponent == 0) {
        yValue = 0;
      }
    }

    result[j] = new FpNumber(format, ySign, yExponent, yValue & ~(1L << fractionLength));
    return new GeneratorResult<FpNumber>(true, result); 
  }

  //------------------------------------------------------------------------------------------------
  // Overflow Exception
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkOverflow(final FpNumber[] operands) {
    final FpNumber x = operands[0];
    final FpNumber y = operands[1];

    if (!x.isNormalized() || !y.isNormalized() || x.getSign() != y.getSign()) {
      return false;
    }

    final long maxExponent = format.getMaxNormalizedExponent();

    final long xDelta = maxExponent - x.getExponent();
    final long yDelta = maxExponent - y.getExponent();

    final int fractionLength = format.getFractionLength();

    if (xDelta > fractionLength || yDelta > fractionLength || (xDelta > 0 && yDelta > 0)) {
      return false;
    }

    final long xValue = (1L << fractionLength) | x.getFraction();
    final long yValue = (1L << fractionLength) | y.getFraction();

    return ((xValue >> xDelta) + (yValue >> yDelta) >= (1L << (fractionLength + 1)));
  }

  @Override
  public GeneratorResult<FpNumber> generateOverflow(final FpNumber[] operands) {
    final FpNumber[] result = new FpNumber[] { operands[0], operands[1] };

    // If both of the operands are fixed, return them as a result.
    if (result[0] != null && result[1] != null) {
      return new GeneratorResult<FpNumber>(checkOverflow(result), result);
    }

    // If one of the operands is zero, the operation does not cause the exception.
    if (result[0] != null && result[0].isZero() || result[1] != null && result[1].isZero()) {
      return new GeneratorResult<FpNumber>(false, result);
    }

    final int fractionLength = format.getFractionLength();
    final long maxExponent = format.getMaxNormalizedExponent();

    // If both of the operands are free, assigns a random value to one of them.
    if (result[0] == null && result[1] == null) {
      final long sign     = random.nextLong() & format.getSignMask();
      final long exponent = maxExponent; // The maximal exponent.
      final long fraction = random.nextLong() & format.getFractionMask();

      result[random.nextInt() & 1] = new FpNumber(format, sign, exponent, fraction);
    }

    final int i = result[0] != null ? 0 : 1;
    final int j = 1 - i;

    final FpNumber x = result[i];

    // The fixed operand.
    final long xSign     = x.getSign();
    final long xExponent = x.getExponent();
    final long xFraction = x.getFraction();

    if (!x.isNormalized() || xExponent < maxExponent - fractionLength) {
      return new GeneratorResult<FpNumber>(false, result);
    }

    // The operand to be generated.
    long ySign     = xSign; // The same sign.
    long yExponent = maxExponent;
    long yFraction = random.nextLong() & format.getFractionMask();

    if (xExponent == maxExponent) {
      // Calculate the number of upper units in the fraction.
      final long yUpperUnits =
          Long.numberOfLeadingZeros(~(xFraction << (Long.SIZE - fractionLength)));

      // If there are some units, the exponent can be decreased.
      yExponent -= random.nextLongRange(0, yUpperUnits);
    } else {
      final long xDelta = maxExponent - xExponent;
      final long yUpperUnits = random.nextLongRange(0, xDelta);
      final long yFractionMask = ~((1 << (fractionLength - yUpperUnits)) - 1);

      yFraction = (~yFractionMask | random.nextLong()) & format.getFractionMask();
    }

    result[j] = new FpNumber(format, ySign, yExponent, yFraction);
    return new GeneratorResult<FpNumber>(true, result);
  }

  //------------------------------------------------------------------------------------------------
  // Underflow Exception
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkUnderflow(final FpNumber[] operands) {
    final FpNumber x = operands[0];
    final FpNumber y = operands[1];

    if (!x.isNormalized() || !y.isNormalized() || x.getSign() == y.getSign()) {
      return false;
    }

    final long minExponent = format.getMinNormalizedExponent();

    // To generate underflow, both exponents should be minimal.
    if (x.getExponent() != minExponent || y.getExponent() != minExponent) {
      return false;
    }

    // If the fractions are equal, while the signs are opposite, the result is exactly zero.
    if (x.getFraction() == y.getFraction()) {
      return false;
    }

    final int fractionLength = format.getFractionLength();

    final long xValue = (1L << fractionLength) | x.getFraction();
    final long yValue = (1L << fractionLength) | y.getFraction();

    return (Math.abs(xValue - yValue) < (1L << fractionLength));
  }

  @Override
  public GeneratorResult<FpNumber> generateUnderflow(final FpNumber[] operands) {
    final FpNumber[] result = new FpNumber[] { operands[0], operands[1] };

    // If both of the operands are fixed, return them as a result.
    if (result[0] != null && result[1] != null) {
      return new GeneratorResult<FpNumber>(checkUnderflow(result), result);
    }

    // If one of the operands is zero, the operation does not cause the exception.
    if (result[0] != null && result[0].isZero() || result[1] != null && result[1].isZero()) {
      return new GeneratorResult<FpNumber>(false, result);
    }

    final long minExponent = format.getMinNormalizedExponent();

    // If both of the operands are free, assigns a random value to one of them.
    if (result[0] == null && result[1] == null) {
      final long sign     = random.nextLong() & format.getSignMask();
      final long exponent = minExponent; // The minimal exponent.
      final long fraction = random.nextLong() & format.getFractionMask();

      result[random.nextInt() & 1] = new FpNumber(format, sign, exponent, fraction);
    }

    final int i = result[0] != null ? 0 : 1;
    final int j = 1 - i;

    final FpNumber x = result[i];

    // The fixed operand.
    final long xSign     = x.getSign();
    final long xExponent = x.getExponent();
    final long xFraction = x.getFraction();

    if (xExponent != minExponent) {
      return new GeneratorResult<FpNumber>(false, result);
    }

    // The operands to be generated.
    long ySign     = 1 - xSign;
    long yExponent = minExponent;
    long yFraction = random.nextLong() & format.getFractionMask();

    // Change the fraction if it is equal to the fixed one.
    if (xFraction == yFraction) {
      yFraction = (yFraction & 2L) == 0L ? yFraction + 1 : yFraction - 1;
    }

    result[j] = new FpNumber(format, ySign, yExponent, yFraction);
    return new GeneratorResult<FpNumber>(true, result);
  }

  //------------------------------------------------------------------------------------------------
  // Inexact Exception
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkInexact(final FpNumber[] operands) {
    final FpNumber x = operands[0];
    final FpNumber y = operands[1];

    if (!x.isNormalized() || !y.isNormalized()) {
      return false;
    }

    final long xExponent = x.getExponent();
    final long xFraction = x.getExponent();

    final long yExponent = y.getExponent();
    final long yFraction = y.getExponent();

    if (xFraction == 0 || yFraction == 0 || xExponent == yExponent) {
      return false;
    }

    final long maxExponent = xExponent > yExponent ? xExponent : yExponent;
    final long minExponent = xExponent > yExponent ? yExponent : xExponent;

    return (maxExponent - minExponent) >= format.getFractionLength();
  }

  @Override
  public GeneratorResult<FpNumber> generateInexact(final FpNumber[] operands) {
    final FpNumber[] result = new FpNumber[] { operands[0], operands[1] };

    // If both of the operands are fixed, return them as a result.
    if (result[0] != null && result[1] != null) {
      return new GeneratorResult<FpNumber>(checkInexact(result), result);
    }

    // If one of the operands is zero, the operation does not cause the exception.
    if (result[0] != null && result[0].isZero() || result[1] != null && result[1].isZero()) {
      return new GeneratorResult<FpNumber>(false, result);
    }

    final int fractionLength = format.getFractionLength();
    final long maxExponent = format.getMaxNormalizedExponent();

    // If both of the operands are free, assigns a random value to one of them.
    if (result[0] == null && result[1] == null) {
      final long sign     = random.nextLong() & format.getSignMask();
      final long exponent = random.nextLongRange(fractionLength + 1, maxExponent);
      final long fraction = random.nextLong() & format.getFractionMask();

      final int index = random.nextInt() & 1;
      result[index] = new FpNumber(format, sign, exponent, fraction == 0 ? 1 : fraction);
    }

    final int i = result[0] != null ? 0 : 1;
    final int j = 1 - i;

    final FpNumber x = result[i];

    // The fixed operand.
    final long xExponent = x.getExponent();
    final long xFraction = x.getFraction();

    if (!x.isNormalized() || xFraction == 0) {
      return new GeneratorResult<FpNumber>(false, result);
    }

    // The operands to be generated.
    long ySign     = random.nextLong() & format.getSignMask();
    long yExponent = 0;
    long yFraction = random.nextLong() & format.getFractionMask();

    yFraction = yFraction == 0 ? 1 : yFraction;

    if (xExponent < format.getExponentBias()) {
      long delta = xExponent + fractionLength;
      yExponent = random.nextLongRange(delta, maxExponent - 1);
    } else {
      long delta = xExponent - fractionLength;
      yExponent = random.nextLongRange(1, delta);
    }

    result[j] = new FpNumber(format, ySign, yExponent, yFraction);
    return new GeneratorResult<FpNumber>(true, result);
  }
}
