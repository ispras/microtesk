/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.mul;

import java.util.ArrayList;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;
import ru.ispras.testbase.knowledge.iterator.ArrayIterator;
import ru.ispras.testbase.knowledge.iterator.IntRangeIterator;
import ru.ispras.testbase.knowledge.iterator.Iterator;
import ru.ispras.testbase.knowledge.iterator.LongRangeIterator;
import ru.ispras.testbase.knowledge.iterator.SequenceIterator;

/**
 * {@link FpMulHardToDRoundIterator} implements an iterator of hard-to-round test cases for the
 * multiplication operation operating in the directed round modes (toward zero, toward plus
 * infinity, and toward minus infinity).
 * 
 * <p>The implementation is based on the following work of Michael Parks:</p>
 * 
 * <ul>
 * <li>M. Parks. <i>Number-Theoretic Test Generation for Directed Rounding</i>. IEEE Transactions on
 * Computers, Volume 49. 2000.</li>
 * </ul>
 * 
 * <p>We seek n-bit integers {@code x} and {@code y} from {@code 2^(n-1) + 1} to {@code 2^n-1} whose
 * product is as close as possible to a directed rounding boundary: {@code x*y = 2^(n-i)*p + k},
 * where {@code i = 0} or {@code 1}, {@code k} is a small integer (positive or negative), and
 * {@code p} is an n-bit integer.</p>
 * 
 * <p>Given an odd {@code y} in {@code [2^(n-1)+1, 2^n-1]} and small {@code k > 0} the algorithm is
 * as follows:</p>
 * 
 * <pre>{@code
 * if k is even
 *   x_1 = 0
 *   p_1 = (1/2)*k
 * else
 *   x_1 = 1
 *   p_1 = (1/2)*(y + k)
 * end
 * 
 * for j = 2 to n
 *   if p_(j-1) is even
 *     x_j = x_(j-1)
 *     p_j = (1/2)*p_(j-1)
 *   else
 *     x_j = 2^(j-1) + x_(j-1)
 *     p_j = (1/2) * (y + p_(j-1))
 *   end
 * 
 * if (p_(n-1) <= 2^n - 1 - y) or (p_(n-1) is odd)
 *   x = 2^(n-1) + x_(n-1) // CASE 0 
 * end
 * 
 * if p_(n-1) >= 2*y - 2^n + 1
 *   x = 2^n - x_(n-1) // CASE 1
 * else if p_(n-1) is even
 *   x = 2^n - x_n // CASE 2 
 * end
 * }</pre>
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class FpMulHardToDRoundIterator implements Iterator<GeneratorResult<FpNumber>> {
  /** The number of {@code y} ({@code y'} for the extended algorithm) values. */
  private static final int Y_NUMBER = 1000;

  /** The upper bound of {@code k} ({@code k'{@code  for the extended algorithm) values). */
  private static final int MAX_K_VALUE = 100;
  /** The upper bound of {@code t} for the extended algorithm ({@code t <= n - 2}). */
  private static final int MAX_T_VALUE = 4;

  /** Format of floating-point numbers. */
  private FpFormat format;

  /** Flag that reflects availability of the value. */
  private boolean hasValue;

  /** {@code x_(n-1)}. */
  private long x_n_1;
  /** {@code x_n}. */
  private long x_n;

  /** {@code p_(n-1)}. */
  private long p_n_1;
  /** {@code p_n}. */
  private long p_n;

  /** The iterator of even {@code y} values, odd integers. */
  private SequenceIterator<Long> yIterator;

  /** The iterator of integers {@code k}, small positive values. */
  private Iterator<Integer> kIterator;
  /** The iterator of integers {@code t}, such that {@code k = 2^t*k'} (extension). */
  private Iterator<Integer> tIterator; 
  /** The iterator of cases: {@code {0, 1, 2}}. */
  private Iterator<Integer> cIterator;

  /** The current value. */
  private GeneratorResult<FpNumber> result;

  /**
   * Constructs a square root hard-to-round iterator.
   * 
   * @param format the format.
   * @param minY the minimal {@code y} value.
   * @param maxY the maximal {@code y} value.
   * @param numY the number of {@code y} values.
   * @param maxK the maximal {@code k} value.
   * @param maxT the maximal {@code t} value.
   */
  public FpMulHardToDRoundIterator(final FpFormat format,
      long minY, long maxY, int numY, int maxK, int maxT) {
    this.format = format;

    if (numY <= 0 || maxK <= 1 || maxT <= 0) {
      throw new IllegalArgumentException();
    }

    // All y values should be odd.
    minY |= 1L;
    maxY = (maxY - 1) | 1L;

    final long step = ((maxY - minY) + 2) / numY;
    final long incY = step > 2 ? step & ~1L : 2;

    yIterator = new SequenceIterator<Long>();
    yIterator.registerIterator(new LongRangeIterator(minY, maxY, incY));

    // To include the maximal value.
    if ((maxY - minY) % incY != 0) {
      yIterator.registerIterator(new LongRangeIterator(maxY, maxY, 2));
    }

    kIterator = new IntRangeIterator(1, maxK);
    tIterator = new IntRangeIterator(maxT);

    init();
  }

  /**
   * Constructs a square root hard-to-round iterator.
   * 
   * @param format the format.
   */
  public FpMulHardToDRoundIterator(final FpFormat format) {
    this(format, 1L, (1L << format.getPrecision()) - 1, Y_NUMBER, MAX_K_VALUE, MAX_T_VALUE);
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  private FpMulHardToDRoundIterator(final FpMulHardToDRoundIterator r) {
    x_n_1 = r.x_n_1;
    x_n = r.x_n;

    p_n_1 = r.p_n_1;
    p_n = r.p_n;

    yIterator = yIterator.clone();
    kIterator = kIterator.clone();
    tIterator = tIterator.clone();
    cIterator = cIterator.clone();

    format = r.format;
    hasValue = r.hasValue;

    result = r.result.clone();
  }

  @Override
  public void init() {
    yIterator.init();
    kIterator.init();
    tIterator.init();

    init(yIterator.value(), kIterator.value(), tIterator.value());

    hasValue = true;
    result = null;
  }

  /**
   * Initializes {@code x_n_1}, {@code p_n_1}, {@code x_n} and {@code p_n}
   * according to the {@code y}, {@code k} and {@code t} values.
   * 
   * <pre> 
   * if k is even,
   *   x_1 = 0;
   *   p_1 = (1/2)*k;
   * else
   *   x_1 = 1;
   *   p_1 = (1/2)*(y + k);
   * end;
   * 
   * for j = 2 to n
   *   if p_(j-1) is even
   *     x_j = x_(j-1)
   *     p_j = (1/2)*p_(j-1)
   *   else
   *     x_j = 2^(j-1) + x_(j-1)
   *     p_j = (1/2) * (y + p_(j-1))
   *   end
   * </pre>
   * 
   * @param k the {@code k} value.
   * @param t the {@code t} value (for the extended algorithm).
   */
  private boolean init(long y, int k, int t) {
    final int n = format.getPrecision() - t; // Extension.

    // Extension: y = 2^t * y' (variable y stores y').
    y &= (1L << n) - 1;

    if ((k & 1) == 0) {
      x_n_1 = 0;
      p_n_1 = (k >> 1);
    } else {
      x_n_1 = 1;
      p_n_1 = (y + k) >> 1;
    }

    for (int j = 2; j <= n - 1; j++) {
      if ((p_n_1 & 1) == 0) {
        p_n_1 = p_n_1 >> 1;
      } else {
        x_n_1 = (1L << (j - 1)) + x_n_1;
        p_n_1 = (y + p_n_1) >> 1;
      }
    }

    if ((p_n_1 & 1) == 0) {
      x_n = x_n_1;
      p_n = p_n_1 >> 1;
    } else {
      x_n = (1L << (n - 1)) + x_n_1;
      p_n = (y + p_n_1) >> 1;
    }

    final ArrayList<Integer> cases = new ArrayList<>();

    // Extension: y = 2^t * y' (variable y stores y).
    y <<= t;

    // CASE 0: if p_(n-1) <= 2^n - 1 - y or p_(n-1) is odd.
    if ((p_n_1 <= (1L << n) - 1 - y) || (p_n_1 & 1) != 0) {
      cases.add(0);
    }
    // CASE 1: if p_(n-1) >= 2*y - 2^n + 1.
    if (p_n_1 >= 2*y - (1L << n) + 1) {
      cases.add(1);
    // CASE 2: else if p_(n-1) is even.
    } else if ((p_n_1 & 1) == 0) {
      cases.add(2);
    }

    cIterator = new ArrayIterator<Integer>(cases);
    cIterator.init();

    return cIterator.hasValue();
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public GeneratorResult<FpNumber> value() {
    // Between two next()'s calls the method value() should return the same value.
    if (result != null) {
      return result;
    }

    final int n = format.getPrecision();
    final int t = tIterator.value();

    long x = 0L;
    long y = (yIterator.value() << t) & ((1L << n) - 1);

    switch (cIterator.value()) {
      case 0:
        // x = 2^(n-1) + x_(n-1).
        x = (1L << (n - 1)) + x_n_1;
        break;
      case 1:
        // x = 2^n - x_(n-1).
        x = (1L << n) - x_n_1;
        break;
      case 2:
        // x = 2^n - x_n.
        x = (1L << n) - x_n;
        break;
    }

    return result = new ResultAdapter(format, x, y).get();
  }

  @Override
  public void next() {
    // Invalidate the result.
    result = null;

    if (!hasValue()) {
      return;
    }

    if (cIterator.hasValue()) {
      cIterator.next();

      if (cIterator.hasValue()) {
        return;
      }
    }

    cIterator.init();

    if (tIterator.hasValue()) {
      tIterator.next();

      if (tIterator.hasValue()) {
        if (init(yIterator.value(), kIterator.value(), tIterator.value())) {
          return;
        }
      }
    }

    tIterator.init();

    if (kIterator.hasValue()) {
      kIterator.next();

      if (kIterator.hasValue()) {
        if (init(yIterator.value(), kIterator.value(), tIterator.value())) {
          return;
        }
      }
    }

    kIterator.init();

    while (yIterator.hasValue()) {
      yIterator.next();

      if (yIterator.hasValue()) {
        if (init(yIterator.value(), kIterator.value(), tIterator.value())) {
          return;
        }
      }
    }

    stop();
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public FpMulHardToDRoundIterator clone() {
    return new FpMulHardToDRoundIterator(this);
  }
}
