/*
 * Copyright 2014-2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.stub;

import static ru.ispras.fortress.util.InvariantChecks.checkNotNull;

import java.util.LinkedHashMap;
import java.util.Map;

import ru.ispras.fortress.data.DataTypeId;
import ru.ispras.fortress.expression.Node;
import ru.ispras.fortress.expression.NodeVariable;
import ru.ispras.testbase.TestBaseQuery;

public final class Utils {
  private Utils() {}

  public static Object getParameter(TestBaseQuery query, String name) {
    checkNotNull(query);
    checkNotNull(name);
    return query.getParameters().get(name);
  }

  public static int getParameterAsInt(TestBaseQuery query, String name) {
    final Object parameter = getParameter(query, name);

    if (parameter == null) {
      throw new IllegalArgumentException("No such parameter: " + name);
    }

    if (parameter instanceof Number) {
      return ((Number) parameter).intValue();
    }

    if (parameter instanceof String) {
      return Integer.valueOf((String) parameter);
    }

    throw new NumberFormatException(String.format(
        "The %s parameter (%s) cannot be converted to int.",
        name, parameter.getClass().getSimpleName()));
  }

  public static boolean checkContextAttribute(TestBaseQuery query, String name, String value) {
    checkNotNull(query);
    checkNotNull(name);
    checkNotNull(value);
    return value.equals(query.getContext().get(name));
  }

  public static Map<String, Node> extractUnknown(TestBaseQuery query) {
    checkNotNull(query);
    final Map<String, Node> result = new LinkedHashMap<String, Node>();
    for (Map.Entry<String, Node> e : query.getBindings().entrySet()) {
      final Node value = e.getValue();
      if (isUnknownVariable(value)) {
        result.put(e.getKey(), value);
      }
    }
    return result;
  }

  public static Map<String, Node> extractUnknownImms(TestBaseQuery query) {
    checkNotNull(query);
    final Map<String, Node> result =  new LinkedHashMap<String, Node>();
    for (Map.Entry<String, Node> e : query.getBindings().entrySet()) {
      final Node value = e.getValue();
      if (isUnknownVariable(value) &&
          value.getDataType().getTypeId() == DataTypeId.LOGIC_INTEGER) {
        result.put(e.getKey(), value);
      }
    }
    return result;
  }

  private static boolean isUnknownVariable(Node node) {
    checkNotNull(node);
    if (node.getKind() != Node.Kind.VARIABLE) {
      return false;
    }

    if (((NodeVariable) node).getVariable().hasValue()) {
      return false;
    }

    return true;
  }
}
