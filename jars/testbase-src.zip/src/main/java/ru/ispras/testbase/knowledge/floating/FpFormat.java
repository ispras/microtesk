/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating;

/**
 * {@link FpFormat} represents a floating-point number format.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class FpFormat {
  /** The IEEE 754 single-precision format. */ 
  public static final FpFormat SINGLE = new FpFormat(8, 23);
  /** The IEEE 754 double-precision format. */ 
  public static final FpFormat DOUBLE = new FpFormat(11, 52);

  /** The fraction length. */
  private int fractionLength;
  /** The fraction mask (not shifted). */
  private long fractionMask;
  /** The fraction offset. */
  private int fractionShift;

  /** The exponent length. */
  private int exponentLength;
  /** The exponent mask (not shifted). */
  private long exponentMask;
  /** The exponent offset. */
  private int exponentShift;

  /** The sign length. */
  private int signLength;
  /** The sign mask (not shifted). */
  private long signMask;
  /** The sign offset. */
  private int signShift;

  //------------------------------------------------------------------------------------------------
  // Basic Methods
  //------------------------------------------------------------------------------------------------

  /**
   * Returns the mask for the given length.
   * 
   * @param length the bit width.
   * @return the mask.
   */
  private static long mask(int length) {
    return length < Long.SIZE ? (1L << length) - 1 : -1L;
  }

  /**
   * Constructs a floating-point number format.
   * 
   * @param exponentLength the exponent length.
   * @param fractionLength the fraction length.
   */
  public FpFormat(int exponentLength, int fractionLength) {
    this.fractionLength = fractionLength;
    this.fractionMask = mask(fractionLength);
    this.fractionShift = 0;

    this.exponentLength = exponentLength;
    this.exponentMask = mask(exponentLength);
    this.exponentShift = fractionShift + fractionLength;

    this.signLength = 1;
    this.signMask = mask(signLength);
    this.signShift = exponentShift + exponentLength;
  }

  /**
   * Returns the bit length of a floating-point number.
   * 
   * @return the length.
   */
  public int getLength() {
    return fractionLength + exponentLength + signLength;
  }

  /**
   * Returns the fraction length.
   * 
   * @return the fraction length.
   */
  public int getFractionLength() {
    return fractionLength;
  }

  /**
   * Returns the exponent length.
   * 
   * @return the exponent length.
   */
  public int getExponentLength() {
    return exponentLength;
  }

  /**
   * Returns the sign length.
   * 
   * @return the sign length.
   */
  public int getSignLength() {
    return signLength;
  }

  /**
   * Returns the fraction mask.
   * 
   * @return the fraction mask.
   */
  public long getFractionMask() {
    return fractionMask;
  }

  /**
   * Returns the exponent mask.
   * 
   * @return the exponent mask.
   */
  public long getExponentMask() {
    return exponentMask;
  }

  /**
   * Returns the sign length.
   * 
   * @return the sign length.
   */
  public long getSignMask() {
    return signMask;
  }

  /**
   * Returns the precision (the fraction length plus one).
   * 
   * @return the precision.
   */
  public int getPrecision() {
    return fractionLength + 1;
  }

  /**
   * Returns the exponent bias.
   * 
   * @return the exponent bias.
   */
  public long getExponentBias() {
    return exponentMask >> 1;
  }

  /**
   * Returns the minimal exponent of a normalized floating-point number.
   * 
   * @return the minimal normalized exponent.
   */
  public long getMinNormalizedExponent() {
    return 1;
  }

  /**
   * Returns the maximal exponent of a normalized floating-point number.
   * 
   * @return the maximal normalized exponent.
   */
  public long getMaxNormalizedExponent() {
    return exponentMask - 1;
  }

  /**
   * Returns the fraction of the given floating-point number.
   * 
   * @param bits the bits representing the floating-point number.
   * @return the fraction.
   */
  public long getFraction(long bits) {
    return (bits << fractionShift) & fractionMask;
  }

  /**
   * Returns the exponent of the given floating-point number.
   * 
   * @param bits the bits representing the floating-point number.
   * @return the exponent.
   */
  public long getExponent(long bits) {
    return (bits << exponentShift) & exponentMask;
  }

  /**
   * Returns the sign of the given floating-point number.
   * 
   * @param bits the bits representing the floating-point number.
   * @return the exponent.
   */
  public long getSign(long bits) {
    return (bits << signShift) & signMask;
  }

  /**
   * Returns the bit representation of the floating-point number.
   * 
   * @param sign the sign.
   * @param exponent the exponent.
   * @param fraction the fraction.
   * @return the bits representing the floating-point number.
   */
  public long getBits(long sign, long exponent, long fraction) {
    return (sign & signMask) << signShift
         | (exponent & exponentMask) << exponentShift
         | (fraction & fractionMask) << fractionShift; 
  }

  //------------------------------------------------------------------------------------------------
  // Constructors of Floating-Point Numbers
  //------------------------------------------------------------------------------------------------

  /**
   * Constructs a floating-point number.
   * 
   * @param sign the sign.
   * @param exponent the exponent.
   * @param fraction the fraction.
   * @return the the floating-point number.
   */
  public FpNumber valueOf(long sign, long exponent, long fraction) {
    return new FpNumber(this, sign, exponent, fraction);
  }

  /**
   * Constructs a floating-point number.
   * 
   * @param bits the bit representation.
   * @return the the floating-point number.
   */
  public FpNumber valueOfBits(long bits) {
    return new FpNumber(this, bits);
  }

  /**
   * Constructs a floating-point number.
   * 
   * @param value the unsigned integer value.
   * @return the the floating-point number.
   */
  public FpNumber valueOfUnsigned(long value) {
    if (value == 0) {
      return new FpNumber(this, 0, 0, 0);
    }

    final int precision = getPrecision();
    final int shift = Long.numberOfLeadingZeros(value);

    long sign = 0;
    long exponent = getExponentBias() + (Long.SIZE - (shift + 1));
    long fraction = value << shift;

    // Remove the tacit unit.
    fraction <<= 1;
    // Truncate the fraction.
    fraction >>>= (Long.SIZE + 1) - precision;

    return new FpNumber(this, sign, exponent, fraction);
  }
}
