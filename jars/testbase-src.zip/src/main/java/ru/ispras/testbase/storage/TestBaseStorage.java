package ru.ispras.testbase.storage;

import ru.ispras.testbase.TestBaseQuery;

public interface TestBaseStorage
{
    StoredTestData fetch(TestBaseQuery query);
}
