package ru.ispras.testbase.storage;

public class StoredTestData
{
    private final String converterName;
    private final Object data;

    public StoredTestData(String converterName, Object data)
    {
        if (converterName == null)
            throw new NullPointerException();

        if (data == null)
            throw new NullPointerException();

        this.converterName = converterName;
        this.data = data;
    }

    public String getConverterName()
    {
        return converterName;
    }

    public Object getData()
    {
        return data;
    }
}
