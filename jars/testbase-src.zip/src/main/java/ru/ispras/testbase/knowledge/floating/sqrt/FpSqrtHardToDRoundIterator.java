/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.sqrt;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;
import ru.ispras.testbase.knowledge.iterator.ArrayIterator;
import ru.ispras.testbase.knowledge.iterator.FilteringIterator;
import ru.ispras.testbase.knowledge.iterator.IntRangeIterator;
import ru.ispras.testbase.knowledge.iterator.Iterator;

/**
 * This class implements an iterator of hard-to-round test cases for the square root operation
 * operating in the directed round modes (toward zero, toward plus infinity, and toward minus
 * infinity).
 * 
 * The implementation is based on the following work of Michael Parks:
 * 
 * M. Parks. Number-Theoretic Test Generation for Directed Rounding. IEEE Transactions on Computers,
 * Volume 49. 2000.
 * 
 * <code>sqrt(x) = z + epsilon</code>, where </code>z</code> is an <code>n</code>-bit integer and
 * <code>epsilon</code> is tiny => <code>x = z^2 - k</code>, where <code>k</code> is a small integer
 * of either sign (<code>n</code> is the precision of floating-point numbers).
 * 
 * <code>x = 0 mod 2^(n-i)</code>, where <code>i=0, 1</code> (<code>x</code> is expressible using at
 * most <code>n</code> bits) => <code>z^2 = k mod 2^(n-i)</code>, and the smaller <code>|k|</code>
 * is, the closer <code>sqrt(x)</code> to a directed rounding boundary.
 * 
 * Suppose <code>k</code> is odd, then <code>z</code> must be odd also, and consequently
 * <code>k = 1 mod 8</code> {@link Int1Mod8Iterator}. To generate test integers, choose
 * <code>k</code> and produce <code>z</code> by solving <code>z^2 = k mod 2^j</code> for
 * <code>j = 1, ..., n</code> (for any <code>k</code> there are infinitely many positive solutions).
 * if <code>z_j</code> is the smallest, then the four smallest solutions are
 * <code>{z_j, 2^(j-1) - z_j, 2^(j-1) + z_j, 2^j - z_j}</code>.
 * 
 * Note that no <code>k</code> produces four test integers. Either two or three integers are
 * produced for each <code>k</code>.
 * 
 * The following solutions for x are suggested:
 * 0) 2^(n-1) * (2^(n-1) + (R_n-1 + 2*z_n-1));
 * 1) 2^(n-1) * (9*2^(n-3) + (R_n-1 - 3*z_n-1));
 * 2) 2^n * (2^(n-2) + (R_n + z_n));
 * 3) 2^n * (2^n + (R_n - 2*z_n)).
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
final class FpSqrtHardToDRoundInternalIterator implements Iterator<GeneratorResult<FpNumber>> {
  /** The upper bound of <code>|k|</code>. */
  private static final int MAX_K_VALUE = 1024;
  /** The upper bound of <code>t</code> for the extended algorithm (<code>t <= (n - 1)/2</code>). */
  private static final int MAX_T_VALUE = 2;

  /** Format of floating-point numbers. */
  private FpFormat format;

  /** Flag that reflects availability of the value. */
  private boolean hasValue;

  /** <code>z_n-1</code>. */
  private long z_n_1;
  /** <code>z_n</code>. */
  private long z_n;

  /** <code>R_n-1</code>. */
  private long r_n_1;
  /** <code>R_n</code>. */
  private long r_n;

  /** The iterator of integers <code>k</code>, such that <code>k = 1 mod 8</code>. */
  private Iterator<Integer> kIterator = new Int1Mod8Iterator(MAX_K_VALUE);
  /** The iterator of integers <code>t</code>, such that <code>k = 4^t*k'</code> (extension). */
  private Iterator<Integer> tIterator = new IntRangeIterator(MAX_T_VALUE); 
  /** The iterator of cases: <code>{0, 1, 2, 3}</code>. */
  private Iterator<Integer> cIterator = new ArrayIterator<Integer>(new Integer[] {0, 1, 2, 3});

  /** The current value. */
  private GeneratorResult<FpNumber> result;

  /**
   * Constructs a square root hard-to-round iterator.
   * 
   * @param format the format.
   */
  public FpSqrtHardToDRoundInternalIterator(final FpFormat format) {
    this.format = format;

    init();
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  private FpSqrtHardToDRoundInternalIterator(final FpSqrtHardToDRoundInternalIterator r) {
    z_n_1 = r.z_n_1;
    z_n = r.z_n;

    r_n_1 = r.r_n_1;
    r_n = r.r_n;

    kIterator = kIterator.clone();
    tIterator = tIterator.clone();
    cIterator = cIterator.clone();

    format = r.format;
    hasValue = r.hasValue;
    result = r.result.clone();
  }

  @Override
  public void init() {
    kIterator.init();
    tIterator.init();
    cIterator.init();

    init(kIterator.value(), tIterator.value());

    hasValue = true;
    result = null;
  }

  /**
   * Initializes <code>z_n_1</code>, <code>r_n_1</code>, <code>z_n</code> and <code>r_n</code>
   * according to the <code>k</code> value.
   * 
   * <code>
   * z_3 = 1;
   * R_3 = (z_3^2 - k) / 2^3 = (1 - k) / 8;
   * for j = 4, ..., n
   *   if R_j-1 is even
   *     R_j = 1/2 * R_j-1;
   *     z_j = z_j-1;
   *   else
   *     R_j = 2^(j-4) + 1/2 * (R_j-1 - z_j-1);
   *     z_j = 2^(j-2) - z_j-1;
   *  </code>
   * 
   * @param k the <code>k</code> value.
   * @param t the <code>t</code> value (for the extended algorithm).
   */
  private void init(int k, int t) {
    final int n = format.getPrecision() - 2*t; // Extension.

    // z_3 = 1.
    z_n_1 = 1;
    // R_3 = (1 - k) / 8.
    r_n_1 = (1 - k) / 8;

    for (int j = 4; j <= (n - 1); j++) {
      if ((r_n_1 & 1L) == 0) {
        r_n_1 = r_n_1 / 2;
      } else {
        r_n_1 = (1L << (j - 4)) + (r_n_1 - z_n_1) / 2;
        z_n_1 = (1L << (j - 2)) - z_n_1;
      }
    }

    if ((r_n_1 & 1L) == 0) {
      r_n = r_n_1 / 2;
      z_n = z_n_1;
    } else {
      r_n = (1L << (n - 4)) + (r_n_1 - z_n_1) / 2;
      z_n = (1L << (n - 2)) - z_n_1;
    }

    // Extension (z_n-1 <= 2^t * z_(n-1-2t), z_n <= 2^t * z_(n-2t)).
    z_n_1 <<= t;
    z_n <<= t;
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public GeneratorResult<FpNumber> value() {
    // Between two next()'s calls the method value() should return the same value.
    if (result != null) {
      return result;
    }

    final int n = format.getPrecision();

    long value = 0L;
    boolean evenExponent = false;

    switch (cIterator.value()) {
      case 0: {
        // 2^(n-1) + z_n-1 => 2^(n-1) * (2^(n-1) + (R_n-1 + 2*z_n-1)).
        value = (1L << (n - 1)) + (r_n_1 + 2 * z_n_1);
        evenExponent = true;
        break;
      }
      case 1: {
        // 3*2^(n-2) - z_n-1 => 2^(n-1) * (9*2^(n-3) + (R_n-1 - 3*z_n-1)).
        value = 9 * (1L << (n - 3)) + (r_n_1 - 3 * z_n_1);
        evenExponent = true;
        break;
      }
      case 2: {
        // 2^(n-1) + z_n => 2^n * (2^(n-2) + (R_n + z_n)).
        value = (1L << (n - 2)) + (r_n + z_n);
        evenExponent = false;
        break;
      }
      case 3: {
        // 2^n - z^n => 2^n * (2^n + (R_n - 2*z_n)).
        value = (1L << n) + (r_n - 2 * z_n);
        evenExponent = false;
        break;
      }
    }

    return result = new ResultAdapter(format, value, evenExponent).get();
  }

  @Override
  public void next() {
    // Invalidate the result.
    result = null;

    if (!hasValue()) {
      return;
    }

    if (cIterator.hasValue()) {
      cIterator.next();

      if (cIterator.hasValue()) {
        return;
      }
    }

    cIterator.init();

    if (tIterator.hasValue()) {
      tIterator.next();
      
      if (tIterator.hasValue()) {
        init(kIterator.value(), tIterator.value());
        return;
      }
    }

    tIterator.init();

    if (kIterator.hasValue()) {
      kIterator.next();

      if (kIterator.hasValue()) {
        init(kIterator.value(), tIterator.value());
        return;
      }
    }

    kIterator.init();

    stop();
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public FpSqrtHardToDRoundInternalIterator clone() {
    return new FpSqrtHardToDRoundInternalIterator(this);
  }
}

/**
 * This class in addition to {@link FpSqrtHardToDRoundInternalIterator} performs filtration of
 * values (removes duplicates).
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class FpSqrtHardToDRoundIterator extends FilteringIterator<GeneratorResult<FpNumber>> {
  /** The filter cache size. */
  private static final int FILTER_SIZE = 4;

  /**
   * Constructs a copy of the square root hard-to-round iterator.
   * 
   * @param format the format.
   */
  public FpSqrtHardToDRoundIterator(final FpFormat format) {
    super(new FpSqrtHardToDRoundInternalIterator(format), Type.CUSTOM_CHECK, FILTER_SIZE);
    init();
  }

  @Override
  protected boolean equals(final GeneratorResult<FpNumber> lhs,
      final GeneratorResult<FpNumber> rhs) {
    return ResultAdapter.equals(lhs, rhs);
  }
}