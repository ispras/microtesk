/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.sub;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpExceptionGenerator;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;
import ru.ispras.testbase.knowledge.floating.add.FpAddExceptionGenerator;

/**
 * {@link FpSubExceptionGenerator} implements a random generator targeted at the exceptions in the
 * floating-point subtraction operation.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class FpSubExceptionGenerator extends FpExceptionGenerator {

  /**
   * Reverses the sign of the second operand.
   *
   * @param operands the operands to be transformed.
   * @return the transformed operands.
   */
  private static FpNumber[] reverse(final FpNumber[] operands) {
    final FpNumber x = operands[0];
    final FpNumber y = operands[1];

    return new FpNumber[] {x, y != null ?
        new FpNumber(y.getFormat(), 1L - y.getSign(), y.getExponent(), y.getFraction()) : null};
  }

  /**
   * Reverses the sign of the second operand of the generation result.
   *
   * @param result the generation result to be transformed.
   * @return the transformed result.
   */
  private static GeneratorResult<FpNumber> reverse(final GeneratorResult<FpNumber> result) {
    return new GeneratorResult<FpNumber>(result.status,
        result.status ? reverse(result.operands) : result.operands);
  }

  /** The internal generator targeted at the floating-point addition exception. */
  private FpAddExceptionGenerator addGenerator;

  /**
   * Constructs a random generator.
   *  
   * @param format the operand format.
   */
  public FpSubExceptionGenerator(final FpFormat format) {
    this.addGenerator = new FpAddExceptionGenerator(format);
  }

  //------------------------------------------------------------------------------------------------
  // Normal Behavior
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkNormal(final FpNumber[] operands) {
    return addGenerator.checkNormal(reverse(operands));
  }

  @Override
  public GeneratorResult<FpNumber> generateNormal(final FpNumber[] operands) {
    return reverse(addGenerator.generateNormal(reverse(operands)));
  }

  //------------------------------------------------------------------------------------------------
  // Overflow Exception
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkOverflow(final FpNumber[] operands) {
    return addGenerator.checkOverflow(reverse(operands));
  }

  @Override
  public GeneratorResult<FpNumber> generateOverflow(final FpNumber[] operands) {
    return reverse(addGenerator.generateOverflow(reverse(operands)));
  }

  //------------------------------------------------------------------------------------------------
  // Underflow Exception
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkUnderflow(final FpNumber[] operands) {
    return addGenerator.checkUnderflow(reverse(operands));
  }

  @Override
  public GeneratorResult<FpNumber> generateUnderflow(final FpNumber[] operands) {
    return reverse(addGenerator.generateUnderflow(reverse(operands)));
  }

  //------------------------------------------------------------------------------------------------
  // Inexact Exception
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkInexact(final FpNumber[] operands) {
    return addGenerator.checkInexact(reverse(operands));
  }

  @Override
  public GeneratorResult<FpNumber> generateInexact(final FpNumber[] operands) {
    return reverse(addGenerator.generateInexact(reverse(operands)));
  }
}
