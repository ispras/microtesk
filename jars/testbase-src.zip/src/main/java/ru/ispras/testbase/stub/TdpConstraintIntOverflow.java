/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.stub;

import static ru.ispras.testbase.stub.Utils.checkContextAttribute;
import static ru.ispras.testbase.stub.Utils.extractUnknown;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import ru.ispras.fortress.data.Data;
import ru.ispras.fortress.data.DataType;
import ru.ispras.fortress.data.DataTypeId;
import ru.ispras.fortress.data.Variable;
import ru.ispras.fortress.expression.Node;
import ru.ispras.fortress.expression.NodeOperation;
import ru.ispras.fortress.expression.NodeValue;
import ru.ispras.fortress.expression.NodeVariable;
import ru.ispras.fortress.expression.StandardOperation;
import ru.ispras.fortress.solver.Solver;
import ru.ispras.fortress.solver.SolverResult;
import ru.ispras.fortress.solver.constraint.Constraint;
import ru.ispras.fortress.solver.constraint.ConstraintBuilder;
import ru.ispras.fortress.solver.constraint.ConstraintKind;
import ru.ispras.fortress.solver.constraint.Formulas;
import ru.ispras.testbase.TestBaseContext;
import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestData;

final class TdpConstraintIntOverflow extends TdpBase {
  public static String NAME = "constraint_int_overflow";
  public static int COUNT = 1;

  private int iteration = 0;
  private TestData testData = null;

  @Override
  boolean isSuitable(final TestBaseQuery query) {
    return checkContextAttribute(query, TestBaseContext.TESTCASE, NAME);
  }

  @Override
  void initialize(final TestBaseQuery query) {
    iteration = 0;

    final Constraint constraint = new IntegerOverflow().getConstraint();
    final Solver solver = TestBase.getSolverId().getSolver();
    final SolverResult solverResult = solver.solve(constraint);

    final Iterator<Variable> varIt = solverResult.getVariables().iterator();

    final Map<String, Node> unknowns = extractUnknown(query);
    final Map<String, Node> outputData = new LinkedHashMap<String, Node>();

    for (Map.Entry<String, Node> e : unknowns.entrySet()) {
      final String name = e.getKey();
      final DataType type = e.getValue().getDataType();

      if (!varIt.hasNext()) {
        break;
      }

      if (DataTypeId.UNKNOWN == type.getTypeId() && !name.equals("rd")) {
        final Variable variable = varIt.next();
        final Data data = variable.getData();
        outputData.put(name, new NodeValue(data));
      }
    }

    testData = new TestData(outputData);
  }

  @Override
  public boolean hasNext() {
    return testData != null && iteration < COUNT;
  }

  @Override
  public TestData next() {
    if (!hasNext()) {
      throw new NoSuchElementException();
    }

    iteration++;
    return testData;
  }
}

/**
 * The constraint as described in the SMT language:
 * 
 * <pre>
 * (define-sort        Int_t () (_ BitVec 64))
 * 
 * (define-fun      INT_ZERO () Int_t (_ bv0 64))
 * (define-fun INT_BASE_SIZE () Int_t (_ bv32 64))
 * (define-fun INT_SIGN_MASK () Int_t (bvshl (bvnot INT_ZERO) INT_BASE_SIZE))
 * 
 * (define-fun IsValidPos ((x!1 Int_t)) Bool (ite (= (bvand x!1 INT_SIGN_MASK) INT_ZERO) true false))
 * (define-fun IsValidNeg ((x!1 Int_t)) Bool (ite (= (bvand x!1 INT_SIGN_MASK) INT_SIGN_MASK) true false))
 * (define-fun IsValidSignedInt ((x!1 Int_t)) Bool (ite (or (IsValidPos x!1) (IsValidNeg x!1)) true false))
 * 
 * (declare-const rs Int_t)
 * (declare-const rt Int_t)
 * 
 * ; rt and rs must contain valid sign-extended 32-bit values (bits 63..31 equal)
 * (assert (IsValidSignedInt rs))
 * (assert (IsValidSignedInt rt))
 * 
 * ; the condition for an overflow: the summation result is not a valid sign-extended 32-bit value
 * (assert (not (IsValidSignedInt (bvadd rs rt))))
 * 
 * ; just in case: rs and rt are not equal (to make the results more interesting)
 * (assert (not (= rs rt)))
 * 
 * (check-sat)
 * 
 * (echo "Values that lead to an overflow:")
 * (get-value (rs rt))
 * </pre>
 * 
 * Expected output (Values that lead to an overflow):
 * 
 * <pre>
 * sat ((rs #x000000009b91b193) (rt #x000000009b91b1b3))
 * </pre>
 */

class IntegerOverflow {
  private final int BIT_VECTOR_LENGTH = 64;
  private final DataType BIT_VECTOR_TYPE = DataType.BIT_VECTOR(BIT_VECTOR_LENGTH);

  private final NodeValue INT_ZERO = new NodeValue(BIT_VECTOR_TYPE.valueOf("0", 10));
  private final NodeValue INT_BASE_SIZE = new NodeValue(BIT_VECTOR_TYPE.valueOf("32", 10));

  private final NodeOperation INT_SIGN_MASK = new NodeOperation(StandardOperation.BVLSHL,
      new NodeOperation(StandardOperation.BVNOT, INT_ZERO), INT_BASE_SIZE);

  public Constraint getConstraint() {
    final ConstraintBuilder builder = new ConstraintBuilder();

    builder.setName("IntegerOverflow");
    builder.setKind(ConstraintKind.FORMULA_BASED);
    builder.setDescription("IntegerOverflow constraint");

    // Unknown variables
    final NodeVariable rs = new NodeVariable(builder.addVariable("rs", BIT_VECTOR_TYPE));
    final NodeVariable rt = new NodeVariable(builder.addVariable("rt", BIT_VECTOR_TYPE));

    final Formulas formulas = new Formulas();
    builder.setInnerRep(formulas);

    formulas.add(IsValidSignedInt(rs));
    formulas.add(IsValidSignedInt(rt));

    formulas.add(new NodeOperation(StandardOperation.NOT,
        IsValidSignedInt(new NodeOperation(StandardOperation.BVADD, rs, rt))));

    formulas.add(new NodeOperation(StandardOperation.NOT,
        new NodeOperation(StandardOperation.EQ, rs, rt)));

    return builder.build();
  }

  private NodeOperation IsValidPos(final Node arg) {
    return new NodeOperation(StandardOperation.EQ,
        new NodeOperation(StandardOperation.BVAND, arg, INT_SIGN_MASK), INT_ZERO);
  }

  private NodeOperation IsValidNeg(final Node arg) {
    return new NodeOperation(StandardOperation.EQ,
        new NodeOperation(StandardOperation.BVAND, arg, INT_SIGN_MASK), INT_SIGN_MASK);
  }

  private NodeOperation IsValidSignedInt(final Node arg) {
    return new NodeOperation(StandardOperation.OR, IsValidPos(arg), IsValidNeg(arg));
  }

  public Iterable<Variable> getExpectedVariables() {
    final List<Variable> result = new ArrayList<Variable>();

    result.add(new Variable("rs", BIT_VECTOR_TYPE.valueOf("000000009b91b193", 16)));
    result.add(new Variable("rt", BIT_VECTOR_TYPE.valueOf("000000009b91b1b3", 16)));

    return result;
  }
}
