/*
 * Copyright 2014-2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.stub;

import static ru.ispras.testbase.stub.Utils.extractUnknown;
import static ru.ispras.testbase.stub.Utils.getParameter;
import static ru.ispras.testbase.stub.Utils.getParameterAsInt;

import java.util.LinkedHashMap;
import java.util.Map;

import ru.ispras.fortress.data.DataType;
import ru.ispras.fortress.data.DataTypeId;
import ru.ispras.fortress.data.types.bitvector.BitVector;
import ru.ispras.fortress.expression.Node;
import ru.ispras.fortress.expression.NodeValue;
import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestData;
import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.integer.IntException;
import ru.ispras.testbase.knowledge.integer.IntExceptionGenerator;
import ru.ispras.testbase.knowledge.integer.IntNumber;

abstract class TdpIntBase extends TdpBase {
  public TdpIntBase(final String name) {
    super(name);
  }

  protected abstract IntExceptionGenerator newIntGenerator(int length);

  @Override
  protected TestData generateData(final TestBaseQuery query) {
    final int sizeAttr = getParameterAsInt(query, "size");

    final Object caseParam = getParameter(query, "case");
    final IntException caseAttr = IntException.get(caseParam.toString());

    final IntNumber[] numbers = new IntNumber[2];
    final GeneratorResult<IntNumber> result = newIntGenerator(sizeAttr).generate(caseAttr, numbers);

    final Map<String, Node> unknowns = extractUnknown(query);
    final Map<String, Node> outputData = new LinkedHashMap<String, Node>();

    int dataIndex = 0;
    for (Map.Entry<String, Node> e : unknowns.entrySet()) {
      if (dataIndex >= result.operands.length) {
        break;
      }

      final String name = e.getKey();
      final DataType type = e.getValue().getDataType();

      if (DataTypeId.UNKNOWN == type.getTypeId() && !name.equals("rd")) {
        final BitVector data = BitVector.valueOf(result.operands[dataIndex].getValue(), sizeAttr);
        outputData.put(name, NodeValue.newBitVector(data));
        dataIndex++;
      }
    }

    return new TestData(outputData);
  }
}
