/*
 * Copyright 2008-2015 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.iterator;

import java.util.ArrayList;

/**
 * {@link SequenceIterator} implements a sequence iterator, a composite iterator that concatenates
 * sequences produced by simpler iterators.
 * 
 * @param <T> the item type.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class SequenceIterator<T> implements Iterator<T> {
  /** The list of registered iterators. */
  private final ArrayList<Iterator<T>> iterators = new ArrayList<>();

  /** The flag that reflects availability of the value. */
  private boolean hasValue = true;

  /**
   * Constructs a sequence iterator.
   */
  public SequenceIterator() {}

  /**
   * Constructs a copy of the sequence iterator.
   * 
   * @param r the iterator to be copied.
   */
  protected SequenceIterator(final SequenceIterator<T> r) {
    for (int i = 0; i < r.iterators.size(); i++) {
      final Iterator<T> iterator = r.iterators.get(i);
      iterators.add(iterator.clone());
    }

    hasValue = r.hasValue();
  }

  /**
   * Registers the iterator.
   * 
   * @param iterator the iterator to be registered.
   */
  public void registerIterator(final Iterator<T> iterator) {
    iterators.add(iterator);
  }

  /**
   * Removes all registered iterators.
   */
  public void clear() {
    iterators.clear();
  }

  /**
   * Returns the number of the registered iterators.
   * 
   * @return the number of the registered iterators.
   */
  public int size() {
    return iterators.size();
  }

  /**
   * Returns the i-th iterator of the list.
   * 
   * @param i the index of iterator in the list.
   * @return the i-th iterator of the list.
   */
  public Iterator<T> iterator(int i) {
    return iterators.get(i);
  }

  @Override
  public void init() {
    hasValue = true;

    for (final Iterator<T> iterator : iterators) {
      iterator.init();
      hasValue |= iterator.hasValue();
    }
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public T value() {
    for (final Iterator<T> iterator : iterators) {
      if (iterator.hasValue()) {
        return iterator.value();
      }
    }

    return null;
  }

  @Override
  public void next() {
    for (final Iterator<T> iterator : iterators) {
      if (iterator.hasValue()) {
        iterator.next();

        if (iterator.hasValue()) {
          return;
        }
      }
    }

    stop();
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public SequenceIterator<T> clone() {
    return new SequenceIterator<T>(this);
  }
}
