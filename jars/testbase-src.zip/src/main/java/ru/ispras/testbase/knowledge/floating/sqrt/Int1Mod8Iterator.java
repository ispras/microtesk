/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.sqrt;

import ru.ispras.testbase.knowledge.iterator.Iterator;

/**
 * {@link Int1Mod8Iterator} implements an internal iterator used to generate hard-to-round test
 * cases for the square root operation. Actually, it produces positive and negatives integers
 * {@code k}, such that {@code k = 1 mod 8} and {@code |k| <= max}:
 * {@code {..., -15, -7, 1, 9, 17, ...}}.
 * 
 * <p>See the following work of Michael Parks for details:</p>
 * 
 * <ul>
 * <li>M. Parks. <i>Number-Theoretic Test Generation for Directed Rounding</i>. IEEE Transactions on
 * Computers, Volume 49. 2000.</li>
 * </ul>
 *  
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
final class Int1Mod8Iterator implements Iterator<Integer> {
  /** The upper bound of {@code |k|}. */
  private int max;
  /** The current value of {@code |k|}. */
  private int k;
  /** The current sign of {@code k}. */
  private int sign;
  /** The flag that reflects availability of a value. */
  private boolean hasValue;

  /**
   * Constructs an {@code k = 1 mod 8} iterator.
   * 
   * @param max the upper bound of {@code |k|}.
   */
  public Int1Mod8Iterator(int max) {
    this.max = max;
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  private Int1Mod8Iterator(final Int1Mod8Iterator r) {
    max = r.max;
    k = r.k;
    sign = r.sign;
    hasValue = r.hasValue;
  }

  @Override
  public void init() {
    sign = k = 1;
    hasValue = true;
  }

  @Override
  public boolean hasValue() {
    if (!hasValue) {
      return false;
    }

    return k <= max;
  }

  @Override
  public Integer value() {
    return sign != 0 ? k : -k + 2;
  }

  @Override
  public void next() {
    if (!hasValue) {
      return;
    }

    if (sign == 1 && k > 1) {
      sign = 0;
      return;
    }

    k += 8;
    sign = 1;
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public Int1Mod8Iterator clone() {
    return new Int1Mod8Iterator(this);
  }
}
