/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.sqrt;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;
import ru.ispras.testbase.knowledge.iterator.SequenceIterator;

/**
 * {@link FpSqrtHardToRoundIterator} implements an iterator of hard-to-round test cases for the
 * square root operation.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class FpSqrtHardToRoundIterator extends SequenceIterator<GeneratorResult<FpNumber>> {

  /**
   * Constructs a square root hard-to-round iterator.
   * 
   * @param format the precision.
   */
  public FpSqrtHardToRoundIterator(final FpFormat format) {
    registerIterator(new FpSqrtHardToDRoundIterator(format));
    registerIterator(new FpSqrtHardToNRoundIterator(format));
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  private FpSqrtHardToRoundIterator(final FpSqrtHardToRoundIterator r) {
    super(r);
  }

  @Override
  public FpSqrtHardToRoundIterator clone() {
    return new FpSqrtHardToRoundIterator(this);
  }
}
