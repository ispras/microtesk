/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.div;

import ru.ispras.fortress.randomizer.Randomizer;
import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;

/**
 * {@link ResultAdapter} transforms a fraction into a pair of floating-point numbers.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
final class ResultAdapter {
  /** The random number generator. */
  private Randomizer random = Randomizer.get();

  /** The format of floating-point numbers. */
  private FpFormat format;

  /** The fraction to be transformed. */
  private Fraction fraction;

  /**
   * Constructs a fraction adapter.
   * 
   * @param format the format of floating-point numbers.
   * @param fraction the fraction to be transformed.
   */
  public ResultAdapter(final FpFormat format, final Fraction fraction) {
    this.format = format;
    this.fraction = fraction;
  }

  /**
   * Transforms the fraction into a pair of floating-point numbers.
   * 
   * @return a pair of floating-point numbers.
   */
  public GeneratorResult<FpNumber> get() {
    final long minExponent = format.getMinNormalizedExponent();
    final long maxExponent = format.getMaxNormalizedExponent();

    final long xSign     = random.nextLongRange(0, 1);
    final long xExponent = random.nextLongRange(minExponent, maxExponent);
    final long xFraction = format.valueOfUnsigned(fraction.n).getFraction();
    final FpNumber x = new FpNumber(format, xSign, xExponent, xFraction);

    final long ySign     = random.nextLongRange(0, 1);
    final long yExponent = random.nextLongRange(minExponent, xExponent); // Should not exceed x's!
    final long yFraction = format.valueOfUnsigned(fraction.d).getFraction();
    final FpNumber y = new FpNumber(format, ySign, yExponent, yFraction);

    return new GeneratorResult<FpNumber>(true, new FpNumber[] {x, y});
  }
}
