/*
 * Copyright 2013-2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.iterator;

import java.util.Collection;
import java.util.Iterator;

/**
 * {@link CollectionIterator} implements a collection iterator.
 * 
 * @param <T> the item type.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class CollectionIterator<T> implements BoundedIterator<T> {
  /** The collection being iterator. */
  private final Collection<T> collection;

  /** The collection iterator. */
  private Iterator<T> iterator;
  /** The flag that reflects availability of the value. */
  private boolean hasValue;
  /** The current value. */
  private T value;

  /**
   * Constructs a collection iterator.
   * 
   * @param collection the collection to be iterated.
   */
  public CollectionIterator(final Collection<T> collection) {
    this.collection = collection;
  }

  @Override
  public void init() {
    iterator = collection.iterator();

    if (hasValue = iterator.hasNext()) {
      value = iterator.next();
    }
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public T value() {
    return value;
  }

  @Override
  public void next() {
    if (hasValue = iterator.hasNext()) {
      value = iterator.next();
    }
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public int size() {
    return collection.size();
  }

  @Override
  public CollectionIterator<T> clone() {
    throw new UnsupportedOperationException();
  }
}
