/*
 * Copyright 2014-2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.storage.internal;

import java.util.List;
import java.util.Map;

import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestDataProvider;

import ru.ispras.testbase.storage.DataConverter;
import ru.ispras.testbase.storage.StoredTestData;

public class RawDataConverter implements DataConverter {
  
  public String getName() {
    return "ru.ispras.testbase.RawDataConverter";
  }

  @SuppressWarnings("unchecked")
  public TestDataProvider convert(StoredTestData data, TestBaseQuery query) {
    if (data == null)
      throw new NullPointerException();

    if (query == null)
      throw new NullPointerException();

    final List<Map<String, String>> dataset = (List<Map<String, String>>) data.getData();
    return new RawDataProvider(dataset, query.getBindings());
  }
}
