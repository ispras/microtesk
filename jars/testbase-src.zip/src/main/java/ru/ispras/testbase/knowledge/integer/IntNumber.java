/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.integer;

/**
 * {@link IntNumber} implements an integer number of a given length (less than or equal to 64).
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class IntNumber {
  /** The format of the integer number. */
  private IntFormat format;

  /** The number. */
  private long value;

  /**
   * Constructs an integer number.
   * 
   * @param format the format.
   * @param value the number.
   */
  public IntNumber(final IntFormat format, long value) {
    this.format = format;
    this.value = value & format.getMask();
  }

  /**
   * Returns the format of the number.
   * 
   * @return the number format.
   */
  public IntFormat getFormat() {
    return format;
  }

  /**
   * Returns the number.
   * 
   * @return the number.
   */
  public long getValue() {
    return value;
  }

  /**
   * Returns the sign-extended value.
   * 
   * @return the sign-extended value.
   */
  public long getSignExtendedValue() {
    if (isPositive() || format.getLength() == Long.SIZE) {
      return value;
    }

    final int zeros = Long.numberOfLeadingZeros(value);
    final long mask = (1L << zeros) - 1;

    return value | (mask << (Long.SIZE - zeros));
  }

  /**
   * Sets the number.
   * 
   * @param value the number to be set.
   */
  public void setValue(long value) {
    this.value = value & format.getMask();
  }

  /**
   * Checks whether the number is zero.
   * 
   * @return {@code true} if the number is zero; {@code false} otherwise.
   */
  public boolean isZero() {
    return value == 0;
  }

  /**
   * Checks whether the number is positive.
   * 
   * @return {@code true} if the number is positive; {@code false} otherwise.
   */
  public boolean isPositive() {
    return (value & (1L << format.getLength() - 1)) == 0; 
  }

  /**
   * Checks whether the number is negative.
   * 
   * @return {@code true} if the number is negative; {@code false} otherwise.
   */
  public boolean isNegative() {
    return !isZero() && !isPositive();
  }

  @Override
  public boolean equals(Object o) {
    if (!(o instanceof IntNumber)) {
      return false;
    }

    final IntNumber r = (IntNumber) o;

    return value == r.value;
  }

  @Override
  public int hashCode() {
    return Long.valueOf(value).hashCode();
  }

  @Override
  public IntNumber clone() {
    return new IntNumber(format, value);
  }

  @Override
  public String toString() {
    return String.format("%x", value);
  }
}
