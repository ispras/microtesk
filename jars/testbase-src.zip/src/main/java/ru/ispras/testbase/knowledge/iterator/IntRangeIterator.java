/*
 * Copyright 2008-2015 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.iterator;

/**
 * {@link IntRangeIterator} implements an integer number iterator over given range.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class IntRangeIterator implements Iterator<Integer> {
  /** The lower bound. */
  private final int min;
  /** The upper bound. */
  private final int max;
  /** The increment value (step). */
  private final int inc;

  /** The current value. */
  private int value;

  /** Flag that reflects availability of the value. */
  private boolean hasValue;

  /**
   * Constructs an integer number range iterator.
   * 
   * @param min the lower bound.
   * @param max the upper bound.
   * @param inc the increment value (step).
   */
  public IntRangeIterator(final int min, final int max, final int inc) {
    if (min > max) {
      throw new IllegalArgumentException("min is greater than max");
    }

    if (inc <= 0) {
      throw new IllegalArgumentException("inc is non-positive");
    }

    this.min = min;
    this.max = max;
    this.inc = inc;
  }

  /**
   * Constructs an integer number range iterator with the increment value equal to one.
   * 
   * @param min the lower bound.
   * @param max the upper bound.
   */
  public IntRangeIterator(final int min, final int max) {
    this(min, max, 1);
  }

  /**
   * Constructs an integer number range iterator with the lower bound equal to zero and the
   * increment value equal to one.
   * 
   * @param max the upper bound.
   */
  public IntRangeIterator(final int max) {
    this(0, max, 1);
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  protected IntRangeIterator(final IntRangeIterator r) {
    min = r.min;
    max = r.max;
    inc = r.inc;

    value = r.value;
    hasValue = r.hasValue;
  }

  /**
   * Sets the current value.
   * 
   * @param value the value to set.
   */
  public void setValue(final int value) {
    if (value < min || value > max) {
      throw new IllegalArgumentException("The value is out of range");
    }

    this.value = value;
  }

  @Override
  public void init() {
    value = min;
    hasValue = true;
  }

  @Override
  public boolean hasValue() {
    return hasValue;
  }

  @Override
  public Integer value() {
    return value;
  }

  @Override
  public void next() {
    if (value > max - inc) {
      hasValue = false;
    } else {
      value += inc;
    }
  }

  @Override
  public void stop() {
    hasValue = false;
  }

  @Override
  public IntRangeIterator clone() {
    return new IntRangeIterator(this);
  }
}
