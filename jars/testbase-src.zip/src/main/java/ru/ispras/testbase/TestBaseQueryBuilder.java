/*
 * Copyright 2014-2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase;

import static ru.ispras.fortress.util.InvariantChecks.checkNotNull;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Collections;

import ru.ispras.fortress.expression.Node;

public final class TestBaseQueryBuilder {
  private Map<String, Node> bindings;
  private Map<String, String> context;
  private Map<String, Object> parameters;

  public TestBaseQueryBuilder() {
    this.bindings = Collections.emptyMap();
    this.context = Collections.emptyMap();
    this.parameters = Collections.emptyMap();
  }

  public TestBaseQuery build() {
    return new TestBaseQuery(
        optionalMap(bindings), optionalMap(context), optionalMap(parameters));
  }

  public void setBinding(String name, Node value) {
    checkNotNull(name);
    checkNotNull(value);

    bindings = updateMap(bindings, name, value);
  }

  public void setContextAttribute(String name, String value) {
    checkNotNull(name);
    checkNotNull(value);

    context = updateMap(context, name, value);
  }

  public void setParameter(String name, Object value) {
    checkNotNull(name);
    checkNotNull(value);

    parameters = updateMap(parameters, name, value);
  }

  private static <K, V> Map<K, V> optionalMap(Map<K, V> map) {
    if (map.isEmpty()) {
      return Collections.emptyMap();
    }

    return Collections.unmodifiableMap(new LinkedHashMap<K, V>(map));
  }

  private static <K, V> Map<K, V> updateMap(Map<K, V> map, K key, V value) {
    final Map<K, V> emap = (map.isEmpty()) ? new LinkedHashMap<K, V>() : map;
    emap.put(key, value);
    return emap;
  }
}
