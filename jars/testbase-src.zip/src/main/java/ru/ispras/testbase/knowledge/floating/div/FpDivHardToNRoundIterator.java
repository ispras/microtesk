/*
 * Copyright 2007-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.div;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;
import ru.ispras.testbase.knowledge.iterator.Iterator;

/**
 * {@link FpDivHardToNRoundIterator} implements an iterator of hard-to-round test cases for the
 * division operation operating in the round-to-nearest mode.
 * 
 * <p>The implementation is based on the following works of David Matula and Lee McFearin:</p>
 * 
 * <ul>
 * <li>D. Matula, L. McFearin. <i>Number Theoretic Foundations of Binary Floating Point Division
 * with Rounding</i>. Real Numbers and Computers, 2000.</li>
 * <li>D. Matula, L. McFearin. <i>Generation and Analysis of Hard to Round Cases for Binary Floating
 * Point Division</i>. Symposium on Computer Arithmetic, 2001.</li>
 * <li>D. Matula, L. McFearin. <i>Selecting a Well Distributed Hard Case Test Suite for IEEE
 * Standard Floating Point Division</i>. International Conference on Computer Design, 2001.</li>
 * <li>D. Matula, L. McFearin. <i>A p x p Bit Fraction Model of Binary Floating Point Division and
 * Extremal Rounding Cases</i>. Theoretical Computer Science, 2003.</li>
 * <li>D. Matula, L. McFearin. <i>A Formal Model and Efficient Traversal Algorithm for Generating
 * Testbenches for Verification of IEEE Standard Floating Point Division</i>. Conference on Design,
 * Automation and Test in Europe, 2006.</li>
 * <li>D. Matula, L. McFearin. <i>Generating a Benchmark Set of Extremal Rounding Boundary Instances
 * for IEEE Standard Floating Point Division</i>.
 * (<a href="http://engr.smu.edu/~matula/single/paper.ps">link</a>)</li>
 * </ul>
 * 
 * <p>The algorithm is as follows (2003):</p>
 * 
 * <pre>{@code
 * odd = 2i-1;
 * num_s / den_s = simplest_parent( (2^p - odd)/odd );
 * if (num_s is odd)
 *   num_i = 2^p - odd + num_s
 * else
 *   num_i = 2(2^p - odd) - num_s
 * print ( (num_i) / (2^p - odd) )
 * }</pre>
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class FpDivHardToNRoundIterator implements Iterator<GeneratorResult<FpNumber>> {

  /** Format of floating-point numbers. */
  private FpFormat format;

  /** Flag that reflects availability of the value. */
  private boolean hasValue;

  /** A temporal fraction. */
  private Fraction fraction = new Fraction();

  /** The current value. */
  private GeneratorResult<FpNumber> value;

  /**
   * Constructs a division hard-to-round iterator.
   * 
   * @param format the format.
   */
  public FpDivHardToNRoundIterator(final FpFormat format) {
    this.format = format;

    init();
  }

  /**
   * Constructs a copy of the iterator.
   * 
   * @param r the iterator to be copied.
   */
  private FpDivHardToNRoundIterator(final FpDivHardToNRoundIterator r) {
    format = r.format;
    hasValue = r.hasValue;
    fraction = r.fraction.clone();
    value = r.value.clone();
  }

  @Override
  public void init() {
    final long odd = 3;
    final long fractionTacitUnit = 1L << format.getPrecision();

    fraction.n = fractionTacitUnit - odd;
    fraction.d = odd;

    hasValue = true;
  }

  @Override
  public boolean hasValue() {
    if (!hasValue) {
      return false;
    }

    return hasValue = (fraction.d < (1L << ((format.getPrecision() + 1) >> 1)));
  }

  @Override
  public GeneratorResult<FpNumber> value() {
    if (value != null) {
      return value;
    }

    final Fraction r = new Fraction();

    final Fraction sp = new Fraction();
    final Fraction cp = new Fraction();

    //----------------------------------------------------------------------------------------------
    // The algorithm:
    //
    // odd = 2i-1;
    // num_s / den_s = simplest_parent( (2^p - odd)/odd );
    // if (num_s is odd)
    //   num_i = 2^p - odd + num_s
    // else
    //   num_i = 2(2^p - odd) - num_s
    // print ( (num_i) / (2^p - odd) )
    //----------------------------------------------------------------------------------------------

    fraction.parentPartition(sp, cp);

    r.d = fraction.n;
    r.n = (sp.n & 1L) == 1 ? fraction.n + sp.n : (fraction.n << 1) - sp.n;

    return value = new ResultAdapter(format, r).get();
  }

  @Override
  public void next() {
    if (!hasValue) {
      return;
    }

    value = null;

    fraction.n -= 2;
    fraction.d += 2;
  }

  @Override
  public void stop() {
    value = null;

    hasValue = false;
  }

  @Override
  public FpDivHardToNRoundIterator clone() {
    return new FpDivHardToNRoundIterator(this);
  }
}
