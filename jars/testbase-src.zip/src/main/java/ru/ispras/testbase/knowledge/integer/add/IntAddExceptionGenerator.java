/*
 * Copyright 2008-2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.integer.add;

import ru.ispras.fortress.randomizer.Randomizer;
import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.integer.IntExceptionGenerator;
import ru.ispras.testbase.knowledge.integer.IntFormat;
import ru.ispras.testbase.knowledge.integer.IntNumber;

/**
 * {@link IntAddExceptionGenerator} implements a random generator targeted at the integer addition
 * exceptions.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class IntAddExceptionGenerator extends IntExceptionGenerator {

  /** The random number generator. */
  private Randomizer random = Randomizer.get();

  /** The floating-point number format. */
  private IntFormat format;

  /**
   * Constructs a random generator targeted at the integer addition exceptions.
   * 
   * @param format the operand format.
   */
  public IntAddExceptionGenerator(final IntFormat format) {
    this.format = format;
  }

  //------------------------------------------------------------------------------------------------
  // Normal Behavior
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkNormal(final IntNumber[] operands) {
    return !checkOverflow(operands);
  }

  @Override
  public GeneratorResult<IntNumber> generateNormal(final IntNumber[] operands) {
    final IntNumber[] result = new IntNumber[] {operands[0], operands[1]};

    // If both of the operands are fixed, return them as a result.
    if (result[0] != null && result[1] != null) {
      return new GeneratorResult<IntNumber>(checkNormal(result), result);
    }

    // If both of the operands are free, assigns a random value to one of them.
    if (result[0] == null && result[1] == null) {
      final long value = random.nextLong() & format.getMask();
      result[random.nextInt() & 1] = new IntNumber(format, value);
    }

    final int i = result[0] != null ? 0 : 1;
    final int j = 1 - i;

    final IntNumber x = result[i];

    // The fixed operand.
    final long xValue = x.getSignExtendedValue();

    // The operand to be generated.
    long yValue;

    final long minValue = format.getMinValue();
    final long maxValue = format.getMaxValue();

    if (xValue >= 0) {
      yValue = random.nextLongRange(minValue, maxValue - xValue);
    } else {
      yValue = random.nextLongRange(minValue - xValue, maxValue);
    }

    result[j] = new IntNumber(format, yValue);
    return new GeneratorResult<IntNumber>(true, result);
  }

  //------------------------------------------------------------------------------------------------
  // Overflow Exception
  //------------------------------------------------------------------------------------------------

  @Override
  public boolean checkOverflow(final IntNumber[] operands) {
    final IntNumber x = operands[0];
    final IntNumber y = operands[1];

    final long xValue = x.getSignExtendedValue();
    final long yValue = y.getSignExtendedValue();

    if(xValue > 0 && yValue > 0) {
      return yValue > format.getMaxValue() - xValue;
    }

    if(xValue < 0 && yValue < 0) {
      return yValue < format.getMinValue() - xValue;
    }

    return false;
  }

  @Override
  public GeneratorResult<IntNumber> generateOverflow(final IntNumber[] operands) {
    final IntNumber[] result = new IntNumber[] {operands[0], operands[1]};

    // If both of the operands are fixed, return them as a result.
    if (result[0] != null && result[1] != null) {
      return new GeneratorResult<IntNumber>(checkNormal(result), result);
    }

    // If both of the operands are free, assigns a random value to one of them.
    if (result[0] == null && result[1] == null) {
      final long value = random.nextLong() & format.getMask();
      result[random.nextInt() & 1] = new IntNumber(format, value == 0 ? 1 : value);
    }

    final int i = result[0] != null ? 0 : 1;
    final int j = 1 - i;

    final IntNumber x = result[i];

    if (x.isZero()) {
      return new GeneratorResult<IntNumber>(false, result);
    }

    // The fixed operand.
    final long xValue = x.getSignExtendedValue();

    // The operand to be generated.
    long yValue;

    final long minValue = format.getMinValue();
    final long maxValue = format.getMaxValue();

    if(xValue > 0) {
      yValue = random.nextLongRange((maxValue - xValue) + 1, maxValue);
    } else {
      yValue = random.nextLongRange(minValue, (minValue - xValue) - 1);
    }

    result[j] = new IntNumber(format, yValue);
    return new GeneratorResult<IntNumber>(true, result);
  }
}
