/*
 * Copyright 2014-2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.stub;

import static ru.ispras.fortress.util.InvariantChecks.checkNotNull;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import ru.ispras.fortress.solver.SolverId;
import ru.ispras.testbase.TestBaseContext;
import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestBaseQueryResult;
import ru.ispras.testbase.TestBaseRegistry;
import ru.ispras.testbase.generator.DataGenerator;

public final class TestBase {
  private static TestBase instance = new TestBase();

  private static SolverId solverId = SolverId.Z3_TEXT;

  public static TestBase get() {
    return instance;
  }

  public static SolverId getSolverId() {
    return solverId;
  }

  public static void setSolverId(SolverId value) {
    checkNotNull(solverId);
    TestBase.solverId = value;
  }

  private final TestBaseRegistry registry;

  private TestBase() {
    this.registry = new TestBaseRegistry();

    final List<TdpBase> providers = Arrays.asList(
      new TdpImmRandom(),
      new TdpImmRange(),
      new TdpZero(),
      new TdpRandom(),
      new TdpRandomBiased(),
      new TdpIntAdd(),
      new TdpIntSub(),
      new TdpFpAdd(),
      new TdpFpSub(),
      new TdpConstraintIntOverflow()
    );

    for (final TdpBase provider : providers) {
      registry.registerGenerator(provider.getName(), provider);
    }
  }

  public TestBaseQueryResult executeQuery(final TestBaseQuery query) {
    checkNotNull(query);

    final String name = query.getContext().get(TestBaseContext.TESTCASE);
    final Collection<DataGenerator> generators = registry.getNamedGenerators(name);

    if (generators != null) {
      for (final DataGenerator generator : generators) {
        if (generator.isSuitable(query)) {
          try {
            return TestBaseQueryResult.success(generator.generate(query));
          } catch (Throwable e) {
            return TestBaseQueryResult.reportErrors(
                Collections.singletonList(e.getMessage()));
          }
        }
      }
    }

    return TestBaseQueryResult.reportErrors(
      Collections.<String>singletonList("No suitable test data generator is found."));
  }

  public TestBaseRegistry getRegistry() {
    return this.registry;
  }
}
