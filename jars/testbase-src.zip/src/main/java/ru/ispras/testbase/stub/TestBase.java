/*
 * Copyright 2014-2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.stub;

import static ru.ispras.fortress.util.InvariantChecks.checkNotNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestBaseQueryResult;

public final class TestBase {
  private final List<TdpBase> providers;

  public TestBase() {
    this.providers = Arrays.asList(
      new TdpImmRandom(),
      new TdpImmRange(),
      new TdpZero(),
      new TdpRandom(),
      new TdpRandomBiased(),
      new TdpIntAdd(),
      new TdpIntSub(),
      new TdpFpAdd(),
      new TdpFpSub(),
      new TdpConstraintIntOverflow()
    );
  }

  public TestBaseQueryResult executeQuery(TestBaseQuery query) {
    checkNotNull(query);

    for (TdpBase provider : providers) {
      if (provider.isSuitable(query)) {
        try {
          provider.initialize(query);
          return TestBaseQueryResult.success(provider);
        } catch (Throwable throwable) {
          return TestBaseQueryResult.reportErrors(
              Collections.singletonList(throwable.getMessage()));
        }
      }
    }

    return TestBaseQueryResult.reportErrors(
      Collections.<String>singletonList("No suitable test data generator is found."));
  }
}
