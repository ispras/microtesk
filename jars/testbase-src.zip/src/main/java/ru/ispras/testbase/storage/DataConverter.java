package ru.ispras.testbase.storage;

import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestDataProvider;

public interface DataConverter
{
    String getName();
    TestDataProvider convert(StoredTestData data, TestBaseQuery query);
}
