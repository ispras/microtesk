/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.stub;

import static ru.ispras.testbase.stub.Utils.extractUnknownImms;
import static ru.ispras.testbase.stub.Utils.getParameterAsInt;

import java.util.LinkedHashMap;
import java.util.Map;

import ru.ispras.fortress.expression.Node;
import ru.ispras.fortress.expression.NodeValue;
import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestData;

final class TdpImmRange extends TdpBase {
  public static final String NAME = "imm_range";

  public TdpImmRange() {
    super(NAME);
  }

  @Override
  protected TestData generateData(final TestBaseQuery query) {
    final int from = getParameterAsInt(query, "from");
    final int to = getParameterAsInt(query, "to");
    final int step = getParameterAsInt(query, "step");
    final Map<String, Node> unknownImms = extractUnknownImms(query);

    final Map<String, Node> outputData = new LinkedHashMap<String, Node>();

    final int delta = Math.abs(to - from);

    int index = 0;
    for (final Map.Entry<String, Node> e : unknownImms.entrySet()) {
      final int value = from + (delta == 0 ? 0 : index % delta);
      outputData.put(e.getKey(), NodeValue.newInteger(value));
      index += step;
    }

    return new TestData(outputData);
  }
}
