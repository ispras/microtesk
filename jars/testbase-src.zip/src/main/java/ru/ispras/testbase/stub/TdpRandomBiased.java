/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.stub;

import static ru.ispras.testbase.stub.Utils.checkContextAttribute;
import static ru.ispras.testbase.stub.Utils.extractUnknown;
import static ru.ispras.testbase.stub.Utils.getParameter;
import static ru.ispras.testbase.stub.Utils.getParameterAsInt;

import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import ru.ispras.fortress.data.Data;
import ru.ispras.fortress.data.DataType;
import ru.ispras.fortress.data.DataTypeId;
import ru.ispras.fortress.data.types.bitvector.BitVector;
import ru.ispras.fortress.expression.Node;
import ru.ispras.fortress.expression.NodeValue;
import ru.ispras.fortress.randomizer.Variate;
import ru.ispras.testbase.TestBaseContext;
import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestData;

final class TdpRandomBiased extends TdpBase {
  public static String NAME = "random_biased";
  public static int COUNT = 1;

  private int size = 0;
  private Variate<?> dist = null;
  
  private int iteration = 0;
  private TestData testData = null;

  @Override
  boolean isSuitable(final TestBaseQuery query) {
    return checkContextAttribute(query, TestBaseContext.TESTCASE, NAME);
  }

  @Override
  void initialize(final TestBaseQuery query) {
    iteration = 0;
    size = getParameterAsInt(query, "size");
    dist = (Variate<?>) getParameter(query, "dist"); 

    final Map<String, Node> unknowns = extractUnknown(query);
    final Map<String, Node> outputData = new LinkedHashMap<String, Node>();
    
    for (Map.Entry<String, Node> e : unknowns.entrySet()) {
      final Object randomValue = dist.value();

      final String name = e.getKey();
      final DataType type = e.getValue().getDataType();

      final Node value;
      if (DataTypeId.LOGIC_INTEGER == type.getTypeId()) {
        value = toInteger(randomValue);
      } else if (DataTypeId.UNKNOWN == type.getTypeId()) {
        value = toBitVector(randomValue, size);
      } else {
        throw new IllegalArgumentException(String.format(
          "The %s variable has unupported type: %s", name, type));
      }

      outputData.put(name, value);
    }

    testData = new TestData(outputData);
  }
  
  private static NodeValue toInteger(final Object value) {
    if (value instanceof Integer) {
      return NodeValue.newInteger((Integer) value);
    }

    if (value instanceof Long) {
      return new NodeValue(Data.newInteger((BigInteger) value));
    }

    if (value instanceof BigInteger) {
      return new NodeValue(Data.newInteger((Long) value));
    }

    throw new IllegalArgumentException(
        "Unsupported value type: " + value.getClass().getName());
  }

  private static NodeValue toBitVector(final Object value, final int size) {
    if (value instanceof Integer) {
      return NodeValue.newBitVector(BitVector.valueOf((Integer) value, size));
    }

    if (value instanceof Long) {
      return NodeValue.newBitVector(BitVector.valueOf((Long) value, size));
    }

    if (value instanceof BigInteger) {
      return NodeValue.newBitVector(BitVector.valueOf((BigInteger) value, size));
    }

    throw new IllegalArgumentException(
        "Unsupported value type: " + value.getClass().getName());
  }

  @Override
  public boolean hasNext() {
    return testData != null && iteration < COUNT;
  }

  @Override
  public TestData next() {
    if (!hasNext()) {
      throw new NoSuchElementException();
    }

    iteration++;
    return testData;
  }
}
