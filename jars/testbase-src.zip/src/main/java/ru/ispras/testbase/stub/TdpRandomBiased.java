/*
 * Copyright 2015 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.stub;

import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.Map;

import ru.ispras.fortress.data.DataType;
import ru.ispras.fortress.data.DataTypeId;
import ru.ispras.fortress.data.types.bitvector.BitVector;
import ru.ispras.fortress.expression.Node;
import ru.ispras.fortress.expression.NodeValue;
import ru.ispras.fortress.randomizer.Variate;
import ru.ispras.testbase.TestBaseQuery;
import ru.ispras.testbase.TestData;

final class TdpRandomBiased extends TdpBase {
  public static final String NAME = "random_biased";

  public TdpRandomBiased() {
    super(NAME);
  }

  @Override
  protected TestData generateData(final TestBaseQuery query) {
    final Variate<?> dist = (Variate<?>) Utils.getParameter(query, "dist"); 

    final Map<String, Node> unknowns = Utils.extractUnknown(query);
    final Map<String, Node> outputData = new LinkedHashMap<String, Node>();

    for (Map.Entry<String, Node> e : unknowns.entrySet()) {
      final Object randomValue = dist.value();

      final String name = e.getKey();
      final DataType type = e.getValue().getDataType();

      final Node value;
      if (DataTypeId.BIT_VECTOR == type.getTypeId()) {
        value = NodeValue.newBitVector(toBitVector(randomValue, type.getSize()));
      } else {
        throw new IllegalArgumentException(String.format(
          "The %s variable has unupported type: %s", name, type));
      }

      outputData.put(name, value);
    }

    return new TestData(outputData);
  }

  private static BitVector toBitVector(final Object value, final int size) {
    if (value instanceof Integer) {
      return BitVector.valueOf((Integer) value, size);
    }

    if (value instanceof Long) {
      return BitVector.valueOf((Long) value, size);
    }

    if (value instanceof BigInteger) {
      return BitVector.valueOf((BigInteger) value, size);
    }

    throw new IllegalArgumentException(
        "Unsupported value type: " + value.getClass().getName());
  }
}
