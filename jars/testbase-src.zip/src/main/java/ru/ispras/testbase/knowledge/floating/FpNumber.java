/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating;

/**
 * {@link FpNumber} represents a floating point number with an arbitrary precision (less or equal to
 * double).
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public final class FpNumber {
  /** The format of the floating-point number. */
  private FpFormat format;

  /** The sign of the floating-point number. */
  private long sign;
  /** The exponent of the floating-point number. */
  private long exponent;
  /** The fraction of the floating-point number. */
  private long fraction;

  /**
   * Constructs a floating-point number.
   * 
   * @param format the format.
   * @param sign the sign.
   * @param exponent the exponent.
   * @param fraction the fraction.
   */
  public FpNumber(final FpFormat format, long sign, long exponent, long fraction) {
    this.format = format;

    this.sign     = (sign     & format.getSignMask());
    this.exponent = (exponent & format.getExponentMask());
    this.fraction = (fraction & format.getFractionMask());
  }

  /**
   * Constructs a floating-point number.
   * 
   * @param format the format.
   * @param bits the bits representing the number.
   */
  public FpNumber(final FpFormat format, long bits) {
    this(format, format.getSign(bits), format.getExponent(bits), format.getFraction(bits));
  }

  /**
   * Returns the format of the floating-point number.
   *  
   * @return the floating-point number format.
   */
  public FpFormat getFormat() {
    return format;
  }

  /**
   * Returns the sign of the floating-point number.
   *  
   * @return the floating-point number sign.
   */
  public long getSign() {
    return sign;
  }

  /**
   * Returns the exponent of the floating-point number.
   *  
   * @return the floating-point number exponent.
   */
  public long getExponent() {
    return exponent;
  }

  /**
   * Returns the fraction of the floating-point number.
   *  
   * @return the floating-point number fraction.
   */
  public long getFraction() {
    return fraction;
  }

  /**
   * Sets the sign of the floating-point number.
   *  
   * @param sign the sign to be set.
   */
  public void setSign(long sign) {
    this.sign = sign & format.getSignMask();
  }

  /**
   * Sets the exponent of the floating-point number.
   *  
   * @param exponent the exponent to be set.
   */
  public void setExponent(long exponent) {
    this.exponent = exponent & format.getExponentMask();
  }

  /**
   * Sets the fraction of the floating-point number.
   *  
   * @param fraction the fraction to be set.
   */
  public void setFraction(long fraction) {
    this.fraction = fraction & format.getFractionMask();
  }

  /**
   * Returns the bits representing of the floating-point number.
   * 
   * @return the bits representing the floating-point number.
   */
  public long getBits() {
    return format.getBits(sign, exponent, fraction);
  }

  /**
   * Sets the bits representation of the floating-point number.
   *  
   * @param bits the bits to be set.
   */
  public void setBits(long bits) {
    this.sign     = format.getSign(bits)     & format.getSignMask();
    this.exponent = format.getExponent(bits) & format.getExponentMask();
    this.fraction = format.getFraction(bits) & format.getFractionMask();
  }

  /**
   * Checks whether the floating-point number is zero.
   * 
   * @return {@code true} if the number is zero; {@code false} otherwise.
   */
  public boolean isZero() {
    return exponent == 0 && fraction == 0;
  }

  /**
   * Checks whether the floating-point number is plus zero.
   * 
   * @return {@code true} if the number is plus zero; {@code false} otherwise.
   */
  public boolean isPlusZero() {
    return sign == 0 && isZero();
  }

  /**
   * Checks whether the floating-point number is minus zero.
   * 
   * @return {@code true} if the number is minus zero; {@code false} otherwise.
   */
  public boolean isMinusZero() {
    return sign == 1 && isZero();
  }

  /**
   * Checks whether the floating-point number is infinity.
   * 
   * @return {@code true} if the number is infinity; {@code false} otherwise.
   */
  public boolean isInfinity() {
    return exponent == format.getExponentMask() && fraction == 0;
  }

  /**
   * Checks whether the floating-point number is plus infinity.
   * 
   * @return {@code true} if the number is plus infinity; {@code false} otherwise.
   */
  public boolean isPlusInfinity() {
    return sign == 0 && isInfinity();
  }

  /**
   * Checks whether the floating-point number is minus infinity.
   * 
   * @return {@code true} if the number is minus infinity; {@code false} otherwise.
   */
  public boolean isMinusInfinity() {
    return sign == 1 && isInfinity();
  }

  /**
   * Checks whether the floating-point number is non-a-number (NaN).
   * 
   * @return {@code true} if the number is NaN; {@code false} otherwise.
   */
  public boolean isNaN() {
    return exponent == format.getExponentMask() && fraction != 0;
  }

  /**
   * Checks whether the floating-point number is normalized.
   * 
   * @return {@code true} if the value is normalized; {@code false} otherwise.
   */
  public boolean isNormalized() {
      return exponent <= format.getMaxNormalizedExponent()
          && exponent >= format.getMinNormalizedExponent();
  }

  @Override
  public boolean equals(final Object o) {
    if (!(o instanceof FpNumber)) {
      return false;
    }

    final FpNumber r = (FpNumber) o;

    return sign == r.sign && exponent == r.exponent && fraction == r.fraction;
  }

  @Override
  public int hashCode() {
    return Long.valueOf(getBits()).hashCode();
  }

  @Override
  public FpNumber clone() {
    return new FpNumber(format, sign, exponent, fraction);
  }

  @Override
  public String toString() {
    return String.format("%x", getBits());
  }
}
