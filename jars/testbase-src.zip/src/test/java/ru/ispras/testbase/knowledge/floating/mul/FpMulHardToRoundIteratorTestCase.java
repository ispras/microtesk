/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.mul;

import java.util.HashSet;
import java.util.Set;

import org.junit.Assert; 
import org.junit.Test;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;

/**
 * Unit tests for {@link FpMulHardToRoundterator}.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class FpMulHardToRoundIteratorTestCase {
  private void runTestMul(final FpFormat format,
      long minY, long maxY, int numY, int maxK, int maxT, final long[] boundaryCases) {

    final FpMulHardToDRoundIterator iterator =
        new FpMulHardToDRoundIterator(format, minY, maxY, numY, maxK, maxT);

    final Set<Integer> indices = new HashSet<>();

    while(iterator.hasValue()) {
      final GeneratorResult<FpNumber> result = iterator.value();
      Assert.assertEquals(true, result.status);
      Assert.assertTrue(result.operands.length == 2);

      final FpNumber x = result.operands[0];
      Assert.assertNotNull(x);
      final FpNumber y = result.operands[1];
      Assert.assertNotNull(y);

      System.out.format("%x * %x\n", x.getBits(), y.getBits());

      for (int i = 0; i < boundaryCases.length / 2; i++) {
        final long a = boundaryCases[2*i];
        final long b = boundaryCases[2*i + 1];
        
        if (a == x.getBits() && b == y.getBits()) {
          indices.add(i);
        }
      }

      iterator.next();
    }
    
    Assert.assertEquals(indices.size(), boundaryCases.length / 2);
  }

  @Test
  public void runTestMul() {
    // The boundary cases from the paper.
    final long[] boundaryCases = new long[] {
        /* 01 */ 0x4b000001, 0x4b000001,
        /* 02 */ 0x4b7ffffd, 0x4b000001,
        /* 03 */ 0x4b000003, 0x4b000001,
        /* 04 */ 0x4b3fffff, 0x4b000000,
        /* 05 */ 0x4b400002, 0x4b000000,
        /* 06 */ 0x4b555555, 0x4b000003,
        /* 07 */ 0x4b2aaaab, 0x4b000003,
        /* 08 */ 0x4b2aaaaa, 0x4b000003,
        /* 09 */ 0x4b555556, 0x4b000003
    };

    runTestMul(FpFormat.SINGLE, 8388609L, 8388611L, 2, 3, 1, boundaryCases);
  }
}
