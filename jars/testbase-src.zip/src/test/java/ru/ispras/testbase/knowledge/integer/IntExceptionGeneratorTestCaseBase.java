/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.integer;

import org.junit.Assert;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.integer.IntNumber;

/**
 * Unit tests for {@link IntExceptionGenerator}.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class IntExceptionGeneratorTestCaseBase {
  private static final int TEST_NUMBER = 100000;

  protected void runTest(final IntExceptionGenerator addGenerator) {
    final IntNumber[] nullOperands = new IntNumber[] {null, null};

    for (int i = 0; i < TEST_NUMBER; i++) {
      GeneratorResult<IntNumber> result = null;

      switch(i % 2) {
        case 0: // Normal.
          result = addGenerator.generateNormal(nullOperands);
          Assert.assertTrue(result.status);
          Assert.assertTrue(String.format("%s + %s", result.operands[0], result.operands[1]),
              addGenerator.checkNormal(result.operands));
          break;
        case 1: // Overflow.
          result = addGenerator.generateOverflow(nullOperands);
          Assert.assertTrue(result.status);
          Assert.assertTrue(String.format("%s + %s", result.operands[0], result.operands[1]),
              addGenerator.checkOverflow(result.operands));
          break;
        default:
          Assert.fail();
          break;
      }
    }
  }
}
