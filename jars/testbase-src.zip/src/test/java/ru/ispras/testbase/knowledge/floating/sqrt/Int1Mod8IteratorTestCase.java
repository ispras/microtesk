/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.sqrt;

import java.util.HashSet;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit tests for {@link Int1Mod8Iterator}.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class Int1Mod8IteratorTestCase {
  @Test
  public void runTest() {
    final Int1Mod8Iterator i = new Int1Mod8Iterator(17);

    final Set<Integer> spec = new HashSet<Integer>();
    final Set<Integer> impl = new HashSet<Integer>();

    spec.add(-15);
    spec.add(-7);
    spec.add(1);
    spec.add(9);
    spec.add(17);

    for(i.init(); i.hasValue(); i.next()) {
      impl.add(i.value());
    }

    Assert.assertEquals(String.format("k != 1 mod 8", spec, impl), spec, impl);
  }
}
