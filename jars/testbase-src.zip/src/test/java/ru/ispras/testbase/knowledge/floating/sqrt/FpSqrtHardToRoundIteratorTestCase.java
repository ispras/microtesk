/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.sqrt;

import java.util.HashSet;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpFormat;
import ru.ispras.testbase.knowledge.floating.FpNumber;

/**
 * Unit tests for {@link FpSqrtHardToRoundIterator}.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class FpSqrtHardToRoundIteratorTestCase {
  private void runTestSqrt(final FpFormat format, final long[] boundaryCases) {
    final int testCases = 50;
    final Set<Long> results = new HashSet<>();

    final FpSqrtHardToDRoundIterator iterator = new FpSqrtHardToDRoundIterator(format);

    for(int i = 0; i < testCases && iterator.hasValue(); i++) {
      final GeneratorResult<FpNumber> result = iterator.value();
      Assert.assertEquals(true, result.status);
      Assert.assertTrue(result.operands.length == 1);

      final FpNumber operand = result.operands[0];
      Assert.assertNotNull(operand);

      System.out.format("%x\n", operand.getBits());

      results.add(operand.getFraction());
      iterator.next();
    }

    // Check whether the generated test cases contain the cases described in the paper.
    for (int i = 0; i < boundaryCases.length; i++) {
      if (!results.contains(format.getFraction(boundaryCases[i]))) {
        Assert.fail(String.format("Number %x has not been generated", boundaryCases[i]));
      }
    }
  }

  @Test
  public void runTestSqrt() {
    // The boundary cases from the paper.
    final long[] boundaryCases = new long[] {
        /* 01 */ 0x56800002,
        /* 02 */ 0x577ffffe,
        /* 03 */ 0x56800004,
        /* 04 */ 0x577ffffc,
        /* 05 */ 0x56b64ad0,
        /* 06 */ 0x56da8747,
        /* 07 */ 0x5750e349,
        /* 08 */ 0x56800006,
        /* 09 */ 0x577ffffa,
        /* 10 */ 0x56a5eb16
    };

    runTestSqrt(FpFormat.SINGLE, boundaryCases);
  }
}
