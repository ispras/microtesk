/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating;

import org.junit.Assert;

import ru.ispras.testbase.knowledge.basis.GeneratorResult;
import ru.ispras.testbase.knowledge.floating.FpNumber;

/**
 * Unit tests for {@link FpExceptionGenerator}.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class FpExceptionGeneratorTestCaseBase {
  private static final int TEST_NUMBER = 10000;

  protected void runTest(final FpExceptionGenerator generator) {
    final FpNumber[] nullOperands = new FpNumber[] {null, null};

    for (int i = 0; i < TEST_NUMBER; i++) {
      GeneratorResult<FpNumber> result = null;
      FpNumber x, y;

      switch(i % 4) {
        case 0: // Normal.
          result = generator.generateNormal(nullOperands);
          x = result.operands[0];
          y = result.operands[1];

          Assert.assertTrue(result.status);
          Assert.assertTrue(String.format("Normal check failed: %s (%x:%x:%x) + %s (%x:%x:%x)",
              x, x.getSign(), x.getExponent(), x.getFraction(), 
              y, y.getSign(), y.getExponent(), y.getFraction()),
              generator.checkNormal(result.operands));
          break;
        case 1: // Overflow.
          result = generator.generateOverflow(nullOperands);
          x = result.operands[0];
          y = result.operands[1];

          Assert.assertTrue(result.status);
          Assert.assertTrue(String.format("Overflow check failed: %s (%x:%x:%x) + %s (%x:%x:%x)",
              x, x.getSign(), x.getExponent(), x.getFraction(), 
              y, y.getSign(), y.getExponent(), y.getFraction()),
              generator.checkOverflow(result.operands));
          break;
        case 2: // Underflow.
          result = generator.generateUnderflow(nullOperands);
          x = result.operands[0];
          y = result.operands[1];

          Assert.assertTrue(result.status);
          Assert.assertTrue(String.format("Underflow check failed: %s (%x:%x:%x) + %s (%x:%x:%x)",
              x, x.getSign(), x.getExponent(), x.getFraction(), 
              y, y.getSign(), y.getExponent(), y.getFraction()),
              generator.checkUnderflow(result.operands));
          break;
        case 3: // Inexact.
          result = generator.generateInexact(nullOperands);
          x = result.operands[0];
          y = result.operands[1];

          Assert.assertTrue(result.status);
          Assert.assertTrue(String.format("Inexact check failed: %s (%x:%x:%x) + %s (%x:%x:%x)",
              x, x.getSign(), x.getExponent(), x.getFraction(), 
              y, y.getSign(), y.getExponent(), y.getFraction()),
              generator.checkInexact(result.operands));
          break;
        default:
          Assert.fail();
          break;
      }
    }
  }
}
