/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.integer.sub;

import org.junit.Test;

import ru.ispras.testbase.knowledge.integer.IntExceptionGeneratorTestCaseBase;
import ru.ispras.testbase.knowledge.integer.IntFormat;

/**
 * Unit tests for {@link IntAddExceptionGenerator}.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class IntSubExceptionGeneratorTestCase extends IntExceptionGeneratorTestCaseBase {
  private void runTestSub(final IntFormat format) {
    runTest(new IntSubExceptionGenerator(format));
  }

  @Test
  public void runTestSub1() {
    runTestSub(IntFormat.INT1);
  }

  @Test
  public void runTestSub8() {
    runTestSub(IntFormat.INT8);
  }

  @Test
  public void runTestSub16() {
    runTestSub(IntFormat.INT16);
  }

  @Test
  public void runTestSub32() {
    runTestSub(IntFormat.INT32);
  }

  @Test
  public void runTestSub64() {
    runTestSub(IntFormat.INT64);
  }
}
