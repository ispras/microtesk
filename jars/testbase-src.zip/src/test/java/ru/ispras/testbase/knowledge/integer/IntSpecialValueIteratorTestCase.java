/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.integer;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit tests for {@link IntSpecialValueIterator}.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class IntSpecialValueIteratorTestCase {
  @Test
  public void runTest() {
    int oldCount = 1;
    int newCount = 1;

    for(int length = 1; length <= 64; length *= 2) {
      final IntFormat format = new IntFormat(length);
      final IntSpecialValueIterator iterator = new IntSpecialValueIterator(format);

      System.out.println("----------------------------------------------");
      System.out.format("Format: %s, mask=%x\n", format, format.getMask());
      System.out.println("----------------------------------------------");

      newCount = 0;
      for(iterator.init(); iterator.hasValue(); iterator.next()) {
        final IntNumber number = iterator.value();

        newCount++;
        System.out.println(number);
      }
      
      Assert.assertTrue(newCount >= oldCount);
      oldCount = newCount;
    }
  }
}
