/*
 * Copyright 2014 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.testbase.knowledge.floating.div;

import org.junit.Assert;
import org.junit.Test;

import ru.ispras.fortress.randomizer.Randomizer;

/**
 * Unit tests for {@link Fraction}.
 * 
 * @author <a href="mailto:kamkin@ispras.ru">Alexander Kamkin</a>
 */
public class FractionTestCase {

  /** The random number generator. */
  final Randomizer random = Randomizer.get();

  /**
   * Returns the greatest common divisor (GCD) of the fraction's numerator and denominator.
   * 
   * @param fraction the fraction.
   * @return the GCD.
   */
  private static long getGreatestCommonDivisor(final Fraction fraction) {
    int k;

    long n = fraction.n;
    long d = fraction.d;

    if (n == 0 || d == 0) {
      return n + d;
    }

    for(k = 0; (n & 1) == 0 && (d & 1) == 0; k++) {
      n >>>= 1;
      d >>>= 1;
    }

    if((n & 1) != 0) {
      long t = n;

      n = d;
      d = t;
    }

    while((n & 1) == 0) {
      n >>>= 1;
    }

    while(n != d) {
      if(n > d) {
        n -= d;
      } else {
        d -= (n = d - n);
      }

      while((n & 1) == 0) {
        n >>>= 1;
      }
    }

    return n << k;
  }

  private void runGcdTest(final Fraction fraction) {
    long impl = fraction.getGreatestCommonDivisor();

    // Self-checking.
    if (fraction.n != fraction.d) {
      long lpmi = new Fraction(fraction.d, fraction.n).getGreatestCommonDivisor();

      Assert.assertEquals("GCD self check", lpmi, impl);
    }

    // Checking against specification.
    long spec = getGreatestCommonDivisor(fraction);

    Assert.assertEquals("GCD spec check", spec, impl);
  }

  @Test
  public void runGcdTest() {
    runGcdTest(new Fraction(0, 0));
    runGcdTest(new Fraction(1, 1));
    runGcdTest(new Fraction(1, 2));
    runGcdTest(new Fraction(2, 2));
    runGcdTest(new Fraction(2, 3));

    final int testCases = 100;

    for (int i = 0; i < testCases; i++) {
      final long n = ((i + 1000) * random.nextLong()) >>> 1;
      final long d = ((i + 1000) * random.nextLong()) >>> 1;

      runGcdTest(new Fraction(n, d));
    }
  }
}
