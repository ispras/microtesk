/*
 * Copyright 2012-2014 ISP RAS (http://www.ispras.ru)
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package ru.ispras.fortress.data.types.bitvector;

import java.math.BigInteger;

import org.junit.Assert;
import org.junit.Test;

import static ru.ispras.fortress.data.types.bitvector.TestUtils.*;

public class BitVectorTestCase {
  @Test
  public void creationTests() {
    Header("Tests for the createEmpty and valueOf methods.");

    // ///////////////////////////////////////////////////////////////////////////////////
    // Tests for createEmpty(int bitSize)

    checkBitVector(BitVector.newEmpty(11), "00000000000");

    // ///////////////////////////////////////////////////////////////////////////////////
    // Tests for valueOf(final int value, final int bitSize)

    checkBitVector(BitVector.valueOf(1, 1), 1);
    checkBitVector(BitVector.valueOf(0, 1), "0");

    checkBitVector(BitVector.valueOf(-1, 32), -1);
    checkBitVector(BitVector.valueOf(-1, 7), "1111111");

    checkBitVector(BitVector.valueOf(0, 4), 0);
    checkBitVector(BitVector.valueOf(0, 33), 0);
    checkBitVector(BitVector.valueOf(-1, 35), -1);

    {
      final String binStr = "1110111";
      checkBitVector(BitVector.valueOf(Integer.valueOf(binStr, 2), binStr.length()), binStr);
    }

    {
      final String binStr = "1100101010011";
      checkBitVector(BitVector.valueOf(Integer.valueOf(binStr, 2), binStr.length()), binStr);
    }

    // ///////////////////////////////////////////////////////////////////////////////////
    // Tests for valueOf(final long value, final int bitSize)

    checkBitVector(BitVector.valueOf(0xFFFFL, 64), 0xFFFFL);
    checkBitVector(BitVector.valueOf(0xFFFF0000L, 64), 0xFFFF0000L);

    checkBitVector(BitVector.valueOf(0xFFFF0000FFFF0000L, 65), 0xFFFF0000FFFF0000L);

    // ///////////////////////////////////////////////////////////////////////////////////
    // Tests for valueOf(final String bs, final int bitSize) and valueOf(final String bs)

    checkBitVector(BitVector.valueOf("0101010011100110000"), "0101010011100110000");
    checkBitVector(BitVector.valueOf("1101010011100110001"), "1101010011100110001");

    checkBitVector(BitVector.valueOf("11111", 2, 8), "00011111");
    checkBitVector(BitVector.valueOf("11111", 2, 9), "000011111");

    checkBitVector(BitVector.valueOf("111011", 2, 8), "00111011");
    checkBitVector(BitVector.valueOf("11111111111011", 2, 9), "111111011");
  }

  // //////////////////////////////////////////////////////////////////////////////////
  // COPY CONSTRUCTOR, ASSIGN AND RESET TESTS
  // //////////////////////////////////////////////////////////////////////////////////

  @Test
  public void copyingTests() {
    // Some representative test data (with odd length).
    final String SAMPLE_35BIT = "101" + "10101010" + "10101010" + "10101010" + "10101010";

    Header("Copying Tests");

    // ////////////////////////////////////////////////////////
    // Test case 0: creates an empty data array and assigns data to it.

    final BitVector rd01 = BitVector.newEmpty(35);

    checkBitVector(rd01, 0);

    final BitVector rd02 = BitVector.valueOf(Long.valueOf(SAMPLE_35BIT, 2), 35);

    checkBitVector(rd02, SAMPLE_35BIT);

    rd01.assign(rd02);

    checkBitVector(rd01, SAMPLE_35BIT);

    checkBitVector(rd02, SAMPLE_35BIT);

    // We call reset to make sure we deal with a copy of the data.
    rd02.reset();

    checkBitVector(rd02, 0);

    checkBitVector(rd01, SAMPLE_35BIT);

    // In this test case, we call reset to make sure we deal with a copy of the data.
    rd01.reset();

    checkBitVector(rd01, 0);

    // ////////////////////////////////////////////////////////
    // Test case 1: the assign and reset methods

    final BitVector rd11 = BitVector.valueOf(Long.valueOf(SAMPLE_35BIT, 2), 35);
    final BitVector rd12 = BitVector.valueOf(Long.valueOf("11111111111111111", 2), 35);

    rd11.assign(rd12);

    checkBitVector(rd12, "00000000000000000011111111111111111");

    // We call reset to make sure we deal with a copy of the data.
    rd12.reset();

    checkBitVector(rd11, "00000000000000000011111111111111111");

    checkBitVector(rd12, 0);

    // In this test case, we call reset to make sure we deal with a copy of the data.
    rd11.reset();

    checkBitVector(rd11, 0);

    // ////////////////////////////////////////////////////////
    // Test case 2: the copy constructor

    final BitVector rd21 = BitVector.valueOf(Long.valueOf(SAMPLE_35BIT, 2), 35);
    final BitVector rd22 = BitVector.copyOf(rd21);

    checkBitVector(rd21, SAMPLE_35BIT);

    checkBitVector(rd22, SAMPLE_35BIT);

    // We call reset to make sure we deal with a copy of the data.
    rd21.reset();

    checkBitVector(rd21, 0);

    checkBitVector(rd22, SAMPLE_35BIT);

    // We call reset to make sure we deal with a copy of the data.
    rd22.reset();

    checkBitVector(rd21, 0);

    checkBitVector(rd22, 0);

    // ////////////////////////////////////////////////////////
    // Test case 3: assignment with truncation

    // NOTE: NO IMPLICIT CONVERSIONS ARE ALLOWED.
    // TO MAKE OPERATIONS IWTH DIFFERENT TYPES, WE NEED TO COERCE THEN EXPLICITLY.

    /*
     * final RawData rd31 = new RawDataStore(27);
     * 
     * checkRawData( rd31, 0 );
     * 
     * final RawData rd32 = new Int(Long.valueOf(SAMPLE_35BIT, 2), 35).getRawData();
     * 
     * checkRawData( rd32, SAMPLE_35BIT );
     * 
     * rd31.assign(rd32);
     * 
     * checkRawData( rd31, "010"+"10101010"+"10101010"+"10101010" );
     * 
     * checkRawData( rd32, SAMPLE_35BIT );
     */
  }

  // //////////////////////////////////////////////////////////////////////////////////
  // READING MAPPING TESTS
  // //////////////////////////////////////////////////////////////////////////////////

  @Test
  public void mappingReadingTests() {
    Header("Mapping Reading Tests");

    // Some representative test data (with odd length).
    final String SAMPLE_35BIT_BIN_STR = "101" + "10101010" + "10101010" + "10101010" + "10101010";



    Trace(BitVector.valueOf(0xFF, 32).toBinString());
    Trace(BitVector.valueOf(0xFF00FF00, 32).toBinString());

    checkBitVector(BitVector.newMapping(BitVector.valueOf(-1, 32), 0, 32), -1);

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 32), 0, 32), 0xFF00FF00);

    // NOT ALLOWED (ASSERTION)
    /*
     * checkRawData( BitVector.createMapping(BitVector.valueOf(-1, 32), 0, 0), "" );
     */

    // //////////////////////////////////////////////////////////
    // Test for multiple of 8 data arrays (no incomplete bytes).

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 32), 0, 8), 0x00);

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 32), 8, 8), 0xFF);

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 32), 16, 8), 0x00);

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 32), 24, 8), 0xFF);


    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 32), 4, 8), 0xF0);

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 32), 20, 8), 0xF0);

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 32), 4, 16), 0x0FF0);

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 32), 12, 16), 0xF00F);

    // //////////////////////////////////////////////////////////
    // Test for data arrays with an incomplete high byte (size is not multiple of 8)

    checkBitVector(BitVector.newMapping(BitVector.valueOf(-1L, 35), 0, 35), -1L);

    checkBitVector(BitVector.newMapping(
        BitVector.valueOf(Long.valueOf("11" + SAMPLE_35BIT_BIN_STR, 2), 35), 0, 35),
        SAMPLE_35BIT_BIN_STR);

    checkBitVector(
        BitVector.newMapping(BitVector.valueOf(Long.valueOf(SAMPLE_35BIT_BIN_STR, 2), 35), 27, 8),
        "101" + "10101");

    checkBitVector(
        BitVector.newMapping(BitVector.valueOf(Long.valueOf(SAMPLE_35BIT_BIN_STR, 2), 35), 24, 11),
        "101" + "10101010");

    checkBitVector(
        BitVector.newMapping(BitVector.valueOf(Long.valueOf(SAMPLE_35BIT_BIN_STR, 2), 35), 23, 11),
        "01" + "101010101");

    checkBitVector(BitVector.newMapping(
        BitVector.valueOf(Long.valueOf("11" + SAMPLE_35BIT_BIN_STR, 2), 35), 1, 5), "10101");

    checkBitVector(BitVector.newMapping(
        BitVector.valueOf(Long.valueOf("11" + SAMPLE_35BIT_BIN_STR, 2), 35), 2, 15), "0"
        + "10101010" + "101010");

    checkBitVector(BitVector.newMapping(
        BitVector.valueOf(Long.valueOf("11" + SAMPLE_35BIT_BIN_STR, 2), 35), 8, 4), "1010");

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0xFF00FF00, 29), 5, 23),
        "11110000000011111111000");

    checkBitVector(BitVector.newMapping(
        BitVector.valueOf(Long.valueOf("11" + SAMPLE_35BIT_BIN_STR, 2), 35), 25, 10), "101"
        + "1010101");

    checkBitVector(BitVector.newMapping(BitVector.valueOf(0x00FFFFFF, 32), 22, 10), "0000000011");
  }

  // //////////////////////////////////////////////////////////////////////////////////
  // WRITING MAPPING TESTS
  // //////////////////////////////////////////////////////////////////////////////////

  @Test
  public void mappingWritingTests() {
    Header("Mapping Writing Tests");

    // Some representative test data (with odd length).
    final String SAMPLE_35BIT_BIN_STR = "101" + "10101010" + "10101010" + "10101010" + "10101010";



    // ////////////////////////////////////////////////////////
    // Test Case 1: Mapping size equals source size.

    final BitVector rd01 = BitVector.valueOf(Long.valueOf(SAMPLE_35BIT_BIN_STR, 2), 35);

    checkBitVector(rd01, SAMPLE_35BIT_BIN_STR);

    final BitVector rd02 = BitVector.valueOf(0xF0F00F, 35);

    checkBitVector(rd02, 0xF0F00F);

    final BitVector rdm01 = BitVector.newMapping(rd01, 0, rd01.getBitSize());

    checkBitVector(rdm01, SAMPLE_35BIT_BIN_STR);

    rdm01.assign(rd02);

    checkBitVector(rd01, 0xF0F00F);

    checkBitVector(rd02, 0xF0F00F);

    checkBitVector(rdm01, 0xF0F00F);

    rd02.reset();

    checkBitVector(rd01, 0xF0F00F);

    checkBitVector(rd02, 0);

    checkBitVector(rdm01, 0xF0F00F);

    rdm01.reset();

    checkBitVector(rd01, 0);

    checkBitVector(rd02, 0);

    checkBitVector(rdm01, 0);

    // ////////////////////////////////////////////////////////
    // Test Case 2: Mapped region is located in the middle of the source data
    // array (the offset and the mapping length is multiple of 8).

    final BitVector rd11 = BitVector.valueOf(Long.valueOf(SAMPLE_35BIT_BIN_STR, 2), 35);

    checkBitVector(rd11, SAMPLE_35BIT_BIN_STR);

    final BitVector rd12 = BitVector.valueOf(0xFF, 8);

    checkBitVector(rd12, 0xFF);

    final BitVector rdm11 = BitVector.newMapping(rd11, 8, 8);

    checkBitVector(rdm11, "10101010");

    rdm11.assign(rd12);

    checkBitVector(rdm11, 0xFF);

    checkBitVector(rd11, "10110101010101010101111111110101010");

    // ////////////////////////////////////////////////////////
    // Test Case 3: Mapped region is located in the middle of the source data
    // array (the offset and the mapping length is multiple of 8).

    final BitVector rd31 = BitVector.valueOf(Long.valueOf(SAMPLE_35BIT_BIN_STR, 2), 35);

    checkBitVector(rd31, SAMPLE_35BIT_BIN_STR);

    final BitVector rd32 = BitVector.valueOf(0xFFFF, 11);

    checkBitVector(rd32, 0xFFFF);

    final BitVector rdm31 = BitVector.newMapping(rd31, 3, 11);

    checkBitVector(rdm31, "10101010101");

    rdm31.assign(rd32);

    checkBitVector(rd31, "10110101010101010101011111111111010");

    checkBitVector(rd32, "11111111111");

    checkBitVector(rdm31, 0xFFFF);

    rdm31.reset();

    checkBitVector(rd31, "10110101010101010101000000000000010");

    checkBitVector(rd32, "11111111111");

    checkBitVector(rdm31, 0);


    // ////////////////////////////////////////////////////////
    // Test Case 4: Mapped region is located in the middle of the source data
    // array (the offset is multiple of 8 and the mapping length is not multiple of 8).

    final BitVector rd41 = BitVector.valueOf(Long.valueOf(SAMPLE_35BIT_BIN_STR, 2), 35);

    checkBitVector(rd41, SAMPLE_35BIT_BIN_STR);

    final BitVector rd42 = BitVector.valueOf(0xFF, 5);

    checkBitVector(rd42, 0xFF);

    final BitVector rdm41 = BitVector.newMapping(rd41, 8, 5);

    checkBitVector(rdm41, "01010");

    rdm41.assign(rd42);

    checkBitVector(rd41, "10110101010101010101011111110101010");

    checkBitVector(rd42, "11111");

    checkBitVector(rdm41, "11111");

    /*
     * rdm31.reset();
     * 
     * checkRawData( rd31, "10110101010101010101000000000000010" );
     * 
     * checkRawData( rd32, "11111111111" );
     * 
     * checkRawData( rdm31, 0 );
     */

    // ////////////////////////////////////////////////////////
    // Test Case 5: Mapped region is located in the middle of the source data
    // array (the offset is multiple of 8 and the mapping length is not multiple of 8).

    final BitVector rd51 = BitVector.valueOf(Long.valueOf(SAMPLE_35BIT_BIN_STR, 2), 35);

    checkBitVector(rd51, SAMPLE_35BIT_BIN_STR);

    final BitVector rd52 = BitVector.valueOf(0, 5);

    checkBitVector(rd52, 0);

    final BitVector rdm51 = BitVector.newMapping(rd51, 8, 5);

    checkBitVector(rdm51, "01010");

    rdm51.assign(rd52);

    checkBitVector(rd51, "10110101010101010101010000010101010");

    checkBitVector(rd52, 0);

    checkBitVector(rdm51, 0);

    // ////////////////////////////////////////////////////////
    // Test Case 6: Mapped region is located in the middle of the source data
    // array (the offset is multiple of 8 and the mapping length is not multiple of 8).

    final BitVector rd61 = BitVector.valueOf(0, 35);
    Assert.assertTrue(BitVector.valueOf("0101010011100110000").toBinString()
        .equals("0101010011100110000"));

    Assert.assertTrue(BitVector.valueOf("0101010011100110000").toBinString()
        .equals("0101010011100110000"));

    Assert.assertTrue(BitVector.valueOf("11111", 2, 8).toBinString().equals("00011111"));

    Assert.assertTrue(BitVector.valueOf("111011", 2, 8).toBinString().equals("00111011"));

    Assert.assertTrue(BitVector.valueOf("11111111111011", 2, 8).toBinString().equals("11111011"));
    checkBitVector(rd61, 0);

    final BitVector rd62 = BitVector.valueOf(0xFF, 5);

    checkBitVector(rd62, 0xFF);

    final BitVector rdm61 = BitVector.newMapping(rd61, 1, 5);

    checkBitVector(rdm61, "00000");

    rdm61.assign(rd62);

    checkBitVector(rd61, "00000000000000000000000000000111110");

    checkBitVector(rd62, 0xFF);

    checkBitVector(rdm61, 0xFF);
  }

  @Test
  public void multiLayerMappingTests() {
    // TODO IMPLEMENT

  }

  @Test
  public void toIntTests() {
    // Size == 32
 
    checkBitVector(BitVector.valueOf(0, 32), "00000000000000000000000000000000");
    Assert.assertEquals(0, BitVector.valueOf(0, 32).intValue());

    checkBitVector(BitVector.valueOf(-1, 32), "11111111111111111111111111111111");
    Assert.assertEquals(-1, BitVector.valueOf(-1, 32).intValue());

    checkBitVector(BitVector.valueOf(Integer.MIN_VALUE, 32), "10000000000000000000000000000000");
    Assert.assertEquals(Integer.MIN_VALUE, BitVector.valueOf(Integer.MIN_VALUE,  32).intValue());

    checkBitVector(BitVector.valueOf(Integer.MAX_VALUE, 32), "01111111111111111111111111111111");
    Assert.assertEquals(Integer.MAX_VALUE, BitVector.valueOf(Integer.MAX_VALUE,  32).intValue());

    // Size < 32 (16)

    checkBitVector(BitVector.valueOf(0, 16), "0000000000000000");
    Assert.assertEquals(0, BitVector.valueOf(0, 16).intValue());

    checkBitVector(BitVector.valueOf(-1, 16), "1111111111111111");
    Assert.assertEquals(0xFFFF, BitVector.valueOf(-1, 16).intValue());
    
    // Size > 32 (36)

    checkBitVector(BitVector.valueOf(0,  36), "000000000000000000000000000000000000");
    Assert.assertEquals(0, BitVector.valueOf(0, 36).intValue());
    
    checkBitVector(BitVector.valueOf(-1, 36), "000011111111111111111111111111111111");
    Assert.assertEquals(-1, BitVector.valueOf(-1, 36).intValue());
  }

  @Test
  public void toLongTests() {
    checkLongConversion(0);
    checkLongConversion(1);
    checkLongConversion(-1);

    checkLongConversion(0x00000000000000FFL);
    checkLongConversion(0x000000000000FF00L);
    checkLongConversion(0x0000000000FF0000L);
    checkLongConversion(0x00000000FF000000L);
    checkLongConversion(0x000000FF00000000L);
    checkLongConversion(0x0000FF0000000000L);
    checkLongConversion(0x00FF000000000000L);
    checkLongConversion(0xFF00000000000000L);

    checkLongConversion(0x00000000000A0000L);
    checkLongConversion(0xFFFFFFFFFFF5FFFFL);
    checkLongConversion(0xFFFFFFFFFFF5FFFFL);

    checkLongConversion(0xDEADBEEF);
    checkLongConversion(0xDEADBEEF00000000L);
    checkLongConversion(0xDEADBEEFBAADF00DL);
  }

  private void checkLongConversion(long value) {
    final BitVector bv = BitVector.valueOf(value, 64);
    System.out.println(bv.toHexString() + " must be == " + Long.toHexString(bv.longValue()));
    Assert.assertEquals(value, bv.longValue());
  }

  @Test
  public void toBigIntegerTests() {
    for (int bitSize = 1; bitSize <= 32; ++bitSize) {
      System.out.println(bitSize + ":");
      checkBigIntegerConversion(-1, bitSize);
      checkBigIntegerConversion(0,  bitSize);
    }

    for (int bitSize = 33; bitSize <= 64; ++bitSize) {
      System.out.println(bitSize + ":");
      checkBigIntegerConversion(-1L, bitSize);
      checkBigIntegerConversion(0L,  bitSize);
    }

    final BitVector bv0 = BitVector.valueOf(BigInteger.valueOf(0), 32);
    Assert.assertEquals("00000000", bv0.toHexString());
    Assert.assertEquals(BigInteger.valueOf(0), bv0.bigIntegerValue());

    final BitVector bv1 = BitVector.valueOf(BigInteger.valueOf(-1), 32);
    Assert.assertEquals("FFFFFFFF", bv1.toHexString());
    Assert.assertEquals(BigInteger.valueOf(-1), bv1.bigIntegerValue());

    final BitVector bv11 = BitVector.valueOf(BigInteger.valueOf(-1), 64);
    Assert.assertEquals("FFFFFFFFFFFFFFFF", bv11.toHexString());
    Assert.assertEquals(BigInteger.valueOf(-1), bv11.bigIntegerValue());

    final BitVector bv12 = BitVector.valueOf(new BigInteger("FFFFFFFFFFFFFFFF", 16), 64);
    Assert.assertEquals("FFFFFFFFFFFFFFFF", bv12.toHexString());
    Assert.assertEquals(BigInteger.valueOf(-1), bv12.bigIntegerValue());

    // Truncating BigInteger (1 becomes the highest bit - sign extension)
    final BitVector bv110 = BitVector.valueOf(new BigInteger("DEADBEEF", 16), 16);
    Assert.assertEquals("BEEF", bv110.toHexString());
    Assert.assertEquals(BigInteger.valueOf(0xFFFFBEEF), bv110.bigIntegerValue());

    // Truncating BigInteger (0 becomes the highest bit - no sign extension)
    final BitVector bv111 = BitVector.valueOf(new BigInteger("DEAD7EEF", 16), 16);
    Assert.assertEquals("7EEF", bv111.toHexString());
    Assert.assertEquals(BigInteger.valueOf(0x7EEF), bv111.bigIntegerValue());

    final BitVector bv2 = BitVector.valueOf(BigInteger.valueOf(1), 32);
    Assert.assertEquals("00000001", bv2.toHexString());
    Assert.assertEquals(BigInteger.valueOf(1), bv2.bigIntegerValue());
    
    final BitVector bv3 = BitVector.valueOf(BigInteger.valueOf(Integer.MAX_VALUE), 32);
    Assert.assertEquals("7FFFFFFF", bv3.toHexString());
    Assert.assertEquals(BigInteger.valueOf(Integer.MAX_VALUE), bv3.bigIntegerValue());

    final BitVector bv4 = BitVector.valueOf(BigInteger.valueOf(Integer.MIN_VALUE), 32);
    Assert.assertEquals("80000000", bv4.toHexString());
    Assert.assertEquals(BigInteger.valueOf(Integer.MIN_VALUE), bv4.bigIntegerValue());
    
    final BitVector bv5 = BitVector.valueOf(BigInteger.valueOf(Long.MAX_VALUE), Long.SIZE);
    Assert.assertEquals("7FFFFFFFFFFFFFFF", bv5.toHexString());
    Assert.assertEquals(BigInteger.valueOf(Long.MAX_VALUE), bv5.bigIntegerValue());
    
    final BitVector bv6 = BitVector.valueOf(BigInteger.valueOf(Long.MIN_VALUE), Long.SIZE);
    Assert.assertEquals("8000000000000000", bv6.toHexString());
    Assert.assertEquals(BigInteger.valueOf(Long.MIN_VALUE), bv6.bigIntegerValue());
  }
  
  private void checkBigIntegerConversion(int value, int bitSize) {
    final BitVector bv = BitVector.valueOf(value, bitSize);
    final BigInteger bi = BigInteger.valueOf(value);

    System.out.println(bv.toBinString());
    System.out.println(bi.toString(2));

    Assert.assertEquals(bi, bv.bigIntegerValue());
  }

  private void checkBigIntegerConversion(long value, int bitSize) {
    final BitVector bv = BitVector.valueOf(value, bitSize);
    final BigInteger bi = BigInteger.valueOf(value);

    System.out.println(bv.toBinString());
    System.out.println(bi.toString(2));

    Assert.assertEquals(bi, bv.bigIntegerValue());
  }

  @Test
  public void toByteArrayTests() {
    final byte[] byte_array = new byte[] {1, 2, 3, 4};
    
    final BitVector bv = BitVector.valueOf(byte_array, 32);
    System.out.println(bv.toHexString());

    for (int i = 0; i < byte_array.length; i++) {
      Assert.assertTrue(byte_array[i] == bv.getByte(i));
    }

    final byte[] bv_byte_array = bv.toByteArray();
    System.out.println(BitVector.valueOf(bv_byte_array, 32).toHexString());

    for (int i = 0; i < byte_array.length; i++) {
      Assert.assertTrue(byte_array[i] == bv_byte_array[i]);
    }

    // TODO: MORE COMPLEX TESTS!!!
  }

  @Test
  public void toStringTests() {
    Assert.assertEquals("FFFF", BitVector.valueOf("FFFF", 16, 16).toHexString());
    Assert.assertEquals("1111111111111111", BitVector.valueOf("FFFF", 16, 16).toBinString());
    Assert.assertEquals("1111111111111111", BitVector.valueOf("FFFF", 16, 16).toString());

    Assert.assertEquals("0000FFFF", BitVector.valueOf("FFFF", 16, 32).toHexString());
    Assert.assertEquals("00000000000000001111111111111111", BitVector.valueOf("FFFF", 16, 32).toBinString());

    Assert.assertEquals("DEADBEEF", BitVector.valueOf(0xDEADBEEF, 32).toHexString());
  }

  @Test
  public void compareTo() {
    checkComparison(BitVector.valueOf("00000001"), BitVector.valueOf("10000000"), -1);
    checkComparison(BitVector.valueOf("10000000"), BitVector.valueOf("00000001"), 1);
    checkComparison(BitVector.valueOf("10000000"), BitVector.valueOf("10000000"), 0);
  }

  @Test
  public void bitExtractionTest() {
    boolean value = true;
    final BitVector bv = BitVector.valueOf("01010101010101010101");
    for (int i = 0; i < bv.getBitSize(); ++i) {
      Assert.assertTrue("Bit extracted doesn't match expected", value == bv.getBit(i));
      value = !value;
    }
  }

  @Test
  public void bitSetTest() {
    testSetBit(BitVector.valueOf("111"), 1, true);
    testSetBit(BitVector.valueOf("111"), 1, false);

    testSetBit(BitVector.valueOf("100100111"), 1, true);
    testSetBit(BitVector.valueOf("100100111"), 1, false);
    testSetBit(BitVector.valueOf("100100111"), 8, true);
    testSetBit(BitVector.valueOf("100100111"), 8, false);

    testSetBit(BitVector.valueOf(0xFFFFFFFF, 32), 0, true);
    testSetBit(BitVector.valueOf(0xFFFFFFFF, 32), 0, false);
    testSetBit(BitVector.valueOf(0xFFFFFFFF, 32), 31, true);
    testSetBit(BitVector.valueOf(0xFFFFFFFF, 32), 31, false);
    testSetBit(BitVector.valueOf(0xFFFFFFFF, 32), 20, true);
    testSetBit(BitVector.valueOf(0xFFFFFFFF, 32), 20, false);

    testSetBit(BitVector.valueOf(0x0, 32), 10, true);
    testSetBit(BitVector.valueOf(0xDEADBEEF, 32), 10, false);

    testSetBit(BitVector.valueOf("111"));
    testSetBit(BitVector.valueOf("100100111"));
    testSetBit(BitVector.valueOf("01010101010101010101"));
    testSetBit(BitVector.valueOf(0xFFFFFFFF, 32));
    testSetBit(BitVector.valueOf(0x0, 32));
    testSetBit(BitVector.valueOf(0xDEADBEEF, 32));
  }

  private static void testSetBit(final BitVector bv, final int index, final boolean value) {
    //System.out.println(bv);
    bv.setBit(index, value);
    //System.out.println(bv);
    Assert.assertEquals(value, bv.getBit(index));
  }

  private static void testSetBit(final BitVector bv) {
    final BitVector expected = BitVectorMath.not(bv.copy());

    final BitVector actual = bv.copy();
    for (int i = 0; i < bv.getBitSize(); ++i) {
      actual.setBit(i, !actual.getBit(i));
    }

    //System.out.println("~ " + bv + " : " + expected + " : " + actual);
    Assert.assertEquals(expected, actual);
  }
}
